package com.lxzh.talent.modular.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import java.util.Date;
import java.time.LocalDate;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.TableLogic;
import com.baomidou.mybatisplus.annotation.TableField;
import java.io.Serializable;

import com.lxzh.talent.core.pojo.base.entity.BasicEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * <p>
 * 人才信息-培养研究生情况表
 * </p>
 *
 * @author wr
 * @since 2022-10-18
 */
@Data
@EqualsAndHashCode(callSuper = false)
@TableName("talent_graduate_student")
@ApiModel(value="TalentGraduateStudent对象", description="人才信息-培养研究生情况表")
public class TalentGraduateStudent extends BasicEntity {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "id")
    @TableId("id")
    private Long id;

    @ApiModelProperty(value = "人才信息id")
    @TableField("talent_id")
    private Long talentId;

    @ApiModelProperty(value = "开始日期")
    @TableField("start_date")
    private LocalDate startDate;

    @ApiModelProperty(value = "终止日期")
    @TableField("end_date")
    private LocalDate endDate;

    @ApiModelProperty(value = "培养研究生数量")
    @TableField("count")
    private Integer count;

    @ApiModelProperty(value = "研究方向")
    @TableField("research_direction")
    private String researchDirection;

    @ApiModelProperty(value = "排序")
    @TableField("sort")
    private Integer sort;
}
