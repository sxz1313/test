package com.lxzh.talent.modular.enums;

import com.lxzh.talent.core.exception.enums.abs.AbstractBaseExceptionEnum;

/**
 * <p>
 * 人才申请异常枚举类
 * </p>
 *
 * @author wr
 * @since 2022-10-19
 */
public enum TalentApplyExceptionEnum implements AbstractBaseExceptionEnum {


    NO_PERMISSION_MODIFY_DATA_EXCEPTION(1000, "没有权限修改"),
    TALENT_CUSTOMER_NOT_FOUND_EXCEPTION(1000, "没有找到用户"),
    COMPANY_NOT_PASS_ADD_TALENT_EXCEPTION(1000, "企业未审核通过，不能添加人才信息"),
    TALENT_MOBILE_EXIST_EXCEPTION(1000, "手机号已存在"),
    TALENT_ID_NUMBER_EXIST_EXCEPTION(1000, "身份证号已存在"),
    TALENT_DATA_NOT_FOUND_EXCEPTION(1001, "没有找到人才信息数据"),
    TALENT_APPLY_WAIT_AUDIT_CAN_NOT_MODFIY_EXCEPTION(1001, "人才信息待审核，不能修改"),
    TALENT_APPLY_WAIT_AUDIT_DATA_NOT_FOUND_EXCEPTION(1001, "没有找到待审核的人才信息数据"),
    TALENT_APPLY_COMMIT_COMPANY_DATA_NOT_FOUND_EXCEPTION(1001, "请填写单位信息"),
    TALENT_APPLY_COMMIT_NAME_DATA_NOT_FOUND_EXCEPTION(1001, "请填写人员基本信息"),
    TALENT_APPLY_COMMIT_EDUCATION_DATA_NOT_FOUND_EXCEPTION(1001, "请填写学历及学位 [从高中（中专)起]信息"),
    TALENT_APPLY_COMMIT_PROFESSIONAL_TECHNICAL_DATA_NOT_FOUND_EXCEPTION(1001, "请填写取得专业技术职称、职（执）业资格情况信息"),
    TALENT_APPLY_COMMIT_WORK_EXPERIENCE_DATA_NOT_FOUND_EXCEPTION(1001, "请填写个人工作经历信息"),
    TALENT_APPLY_COMMIT_POLITICAL_DATA_NOT_FOUND_EXCEPTION(1001, "请填写政治面貌（党派）情况信息"),
    TALENT_APPLY_COMMIT_FAMILY_MEMBER_DATA_NOT_FOUND_EXCEPTION(1001, "请填写家庭成员及主要社会关系信息"),
    TALENT_ALREADY_EXIT_CLUB_EXCEPTION(1001, "已退会，请勿重新操作"),
    ;

    TalentApplyExceptionEnum(int code, String message) {
        this.code = code;
        this.message = message;
    }

    private Integer code;

    private String message;

    @Override
    public Integer getCode() {
        return code;
    }

    @Override
    public String getMessage() {
        return message;
    }
}
