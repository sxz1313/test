package com.lxzh.talent.modular.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.lxzh.talent.modular.entity.BasicData;

/**
 * basic_data Mapper 接口
 *
 * @author wsn
 * @date 2022/10/18 11:00
 */
public interface BasicDataMapper extends BaseMapper<BasicData> {

}