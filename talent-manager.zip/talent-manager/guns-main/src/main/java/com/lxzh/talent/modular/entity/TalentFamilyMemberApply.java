package com.lxzh.talent.modular.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import java.util.Date;
import java.time.LocalDate;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.TableLogic;
import com.baomidou.mybatisplus.annotation.TableField;
import java.io.Serializable;

import com.lxzh.talent.core.pojo.base.entity.BasicEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * <p>
 * 人才信息-家庭成员及主要社会关系申请表
 * </p>
 *
 * @author wr
 * @since 2022-10-18
 */
@Data
@EqualsAndHashCode(callSuper = false)
@TableName("talent_family_member_apply")
@ApiModel(value="TalentFamilyMemberApply对象", description="人才信息-家庭成员及主要社会关系申请表")
public class TalentFamilyMemberApply extends BasicEntity {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "id")
    @TableId("id")
    private Long id;

    @ApiModelProperty(value = "人才信息申请id")
    @TableField("talent_apply_id")
    private Long talentApplyId;

    @ApiModelProperty(value = "姓名")
    @TableField("name")
    private String name;

    @ApiModelProperty(value = "与本人关系")
    @TableField("relationship")
    private String relationship;

    @ApiModelProperty(value = "出生日期")
    @TableField("birthday")
    private String birthday;

    @ApiModelProperty(value = "政治面貌")
    @TableField("politics_status")
    private String politicsStatus;

    @ApiModelProperty(value = "工作单位及职务")
    @TableField("ocupertino")
    private String ocupertino;

    @ApiModelProperty(value = "排序")
    @TableField("sort")
    private Integer sort;
}
