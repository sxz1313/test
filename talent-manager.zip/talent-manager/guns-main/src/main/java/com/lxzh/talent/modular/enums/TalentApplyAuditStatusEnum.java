package com.lxzh.talent.modular.enums;


/**
 * <p>
 * 人才基本信息-申请状态枚举类
 * </p>
 *
 * @author wr
 * @since 2022-10-18
 */
public enum TalentApplyAuditStatusEnum {

    WAIT_COMMIT(1,"草稿"),
    WAIT_AUDIT(2,"待审核"),
    PASS(3,"已通过"),
    REJECT(4,"未通过")
    ;

    private Integer value;
    private String desc;

    TalentApplyAuditStatusEnum(Integer value, String desc) {
        this.value = value;
        this.desc = desc;
    }

    public Integer getValue() {
        return this.value;
    }

    public String getDesc() {
        return desc;
    }

    @Override
    public String toString() {
        return this.desc;
    }
}
