package com.lxzh.talent.modular.mapper;

import com.lxzh.talent.modular.entity.TalentHonor;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 人才信息-荣誉称号（奖励）情况表 Mapper 接口
 * </p>
 *
 * @author wr
 * @since 2022-10-18
 */
public interface TalentHonorMapper extends BaseMapper<TalentHonor> {

}
