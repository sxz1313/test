package com.lxzh.talent.modular.entity;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.lxzh.talent.core.pojo.base.entity.BasicEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.*;

import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * <p>
 * 订单表
 * </p>
 *
 * @author wr
 * @since 2022-09-28
 */
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
@EqualsAndHashCode(callSuper = false)
@TableName("payment_order")
@ApiModel(value="Order对象", description="订单表")
public class Order extends BasicEntity {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "订单id")
    @TableId("id")
    private Long id;

    @ApiModelProperty(value = "订单编号")
    @TableField("order_number")
    private String orderNumber;

    @ApiModelProperty(value = "课程ID")
    @TableField("course_id")
    private Long courseId;

    @ApiModelProperty(value = "课程名称")
    @TableField("course_name")
    private String courseName;

    @ApiModelProperty(value = "课程图片")
    @TableField("course_pic")
    private String coursePic;

    @ApiModelProperty(value = "买家ID")
    @TableField("buyer_id")
    private Long buyerId;

    @ApiModelProperty(value = "省code")
    @TableField("customer_province_code")
    private String customerProvinceCode;

    @ApiModelProperty(value = "市code")
    @TableField("customer_city_code")
    private String customerCityCode;

    @ApiModelProperty(value = "毕业学校")
    @TableField("customer_school")
    private String customerSchool;

    @ApiModelProperty(value = "姓名")
    @TableField("customer_name")
    private String customerName;

    @ApiModelProperty(value = "手机号")
    @TableField("customer_phone")
    private String customerPhone;

    @ApiModelProperty(value = "邮箱")
    @TableField("customer_email")
    private String customerEmail;

    @ApiModelProperty(value = "学历")
    @TableField("customer_education")
    private String customerEducation;

    @ApiModelProperty(value = "备注")
    @TableField("remark")
    private String remark;

    @ApiModelProperty(value = "应付金额")
    @TableField("total_pay")
    private BigDecimal totalPay;

    @ApiModelProperty(value = "实际支付金额")
    @TableField("real_pay")
    private BigDecimal realPay;

    @ApiModelProperty(value = "订单状态 1、待支付 2、已支付 3、已取消")
    @TableField("status")
    private Integer status;

    @ApiModelProperty(value = "支付方式 1、微信")
    @TableField("payment_type")
    private Integer paymentType;

    @ApiModelProperty(value = "付款时间")
    @TableField("pay_time")
    private LocalDateTime payTime;

    @ApiModelProperty(value = "过期时间")
    @TableField("expire_time")
    private LocalDateTime expireTime;

    @ApiModelProperty(value = "取消时间")
    @TableField("cancel_time")
    private LocalDateTime cancelTime;

    @ApiModelProperty(value = "取消原因")
    @TableField("cancel_reason")
    private String cancelReason;
}
