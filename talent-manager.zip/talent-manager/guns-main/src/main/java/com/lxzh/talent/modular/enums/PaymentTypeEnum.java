package com.lxzh.talent.modular.enums;

/**
 * <p>
 * 支付方式枚举类
 * </p>
 *
 * @author wr
 * @since 2022-09-28
 */
public enum PaymentTypeEnum {

    WEIXIN(1, "微信支付");

    private Integer value;
    private String desc;

    PaymentTypeEnum(Integer value, String desc) {
        this.value = value;
        this.desc = desc;
    }

    public Integer getValue() {
        return this.value;
    }

    public String getDesc() {
        return desc;
    }

    @Override
    public String toString() {
        return this.desc;
    }

}