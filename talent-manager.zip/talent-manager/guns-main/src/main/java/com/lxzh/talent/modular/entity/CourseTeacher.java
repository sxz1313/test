package com.lxzh.talent.modular.entity;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.lxzh.talent.core.pojo.base.entity.BasicEntity;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 课程教师信息表
 *
 * @author wsn
 * @date 2022/09/28 11:28
 */
@Data
@EqualsAndHashCode(callSuper = true)
@TableName("cr_course_teacher")
public class CourseTeacher extends BasicEntity {

    /**
     * 主键
     */
    @TableId("id")
    private Long id;

    /**
     * 课程id
     */
    @TableField("course_id")
    private Long courseId;

    /**
     * 老师姓名
     */
    @TableField("name")
    private String name;

    /**
     * 头像图片文件id
     */
    @TableField("img_file_id")
    private Long imgFileId;

    /**
     * 简介
     */
    @TableField("introduction")
    private String introduction;

    /**
     * 详细介绍
     */
    @TableField("introduce")
    private String introduce;
}
