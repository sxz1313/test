package com.lxzh.talent.modular.entity;

import cn.hutool.core.convert.Convert;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.lxzh.talent.core.pojo.base.entity.BasicEntity;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * basic_data
 *
 * @author wsn
 * @date 2022/10/18 11:00
 */
@Data
@EqualsAndHashCode(callSuper = true)
@TableName("basic_data")
public class BasicData extends BasicEntity {

    /**
     * 主键id
     */
    @TableId("id")
    private Long id;

    /**
     * 名称
     */
    @TableField("name")
    private String name;

    /**
     * 类型
     */
    @TableField("type")
    private String type;

    /**
     * 父级id
     */
    @TableField("parent_id")
    private Long parentId;

    /**
     * 排序号
     */
    @TableField("sort")
    private Integer sort;

    /**
     * 备注
     */
    @TableField("remark")
    private String remark;

    @TableField(exist = false)
    private boolean hasSubs;

    public String getIdStr() {
        return Convert.toStr(id);
    }
}
