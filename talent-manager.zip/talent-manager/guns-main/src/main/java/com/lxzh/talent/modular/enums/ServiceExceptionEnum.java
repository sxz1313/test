package com.lxzh.talent.modular.enums;

import com.lxzh.talent.core.exception.enums.abs.AbstractBaseExceptionEnum;

public enum ServiceExceptionEnum implements AbstractBaseExceptionEnum {

    /**
     * 手机验证码不正确
     */
    PHONE_CODE_IS_NOT_TRUE(1008,"手机验证码不正确!"),
    /**
     * 推荐码
     */
    RECOMMENDCODE_RELOAD_FAIL(1020,"推荐码加载失败!"),

    /**
     * 商品分类
     */
    GOOD_KIND_NAME(1009,"分类名称已存在！"),

    CUSTOMER_ACCOUNT_HAS_EXISTS(1011,"账号已存在!"),

    CUSTOMER_ACCOUNT_NOTHAS_EXISTS(1012,"账号不存在!"),

    CUSTOMER_PHONE_HAS_EXISTS(1013,"用户手机号已存在！"),

    CUSTOMER_NOT_EXISTS(1014,"客户不存在！"),

    YH_PHONE_HAS_EXISTS(1015,"手机号已存在！"),
    ;



    private String message;
    private Integer code;

    ServiceExceptionEnum(int code, String message) {
        this.code = code;
        this.message = message;
    }

    @Override
    public Integer getCode() {
        return code;
    }
    public void setCode(int code) {
        this.code = code;
    }

    @Override
    public String getMessage() {
        return message;
    }
    public void setMessage(String message) {
        this.message = message;
    }
}
