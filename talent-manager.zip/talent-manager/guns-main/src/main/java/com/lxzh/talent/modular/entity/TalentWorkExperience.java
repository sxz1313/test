package com.lxzh.talent.modular.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import java.util.Date;
import java.time.LocalDate;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.TableLogic;
import com.baomidou.mybatisplus.annotation.TableField;
import java.io.Serializable;

import com.lxzh.talent.core.pojo.base.entity.BasicEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * <p>
 * 人才信息-个人工作经历表
 * </p>
 *
 * @author wr
 * @since 2022-10-18
 */
@Data
@EqualsAndHashCode(callSuper = false)
@TableName("talent_work_experience")
@ApiModel(value="TalentWorkExperience对象", description="人才信息-个人工作经历表")
public class TalentWorkExperience extends BasicEntity {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "id")
    @TableId("id")
    private Long id;

    @ApiModelProperty(value = "人才信息id")
    @TableField("talent_id")
    private Long talentId;

    @ApiModelProperty(value = "起始日期")
    @TableField("start_date")
    private String startDate;

    @ApiModelProperty(value = "终止日期")
    @TableField("end_date")
    private String endDate;

    @ApiModelProperty(value = "单位名称")
    @TableField("company_name")
    private String companyName;

    @ApiModelProperty(value = "部门职务")
    @TableField("position")
    private String position;

    @ApiModelProperty(value = "主要职责")
    @TableField("major_duty")
    private String majorDuty;

    @ApiModelProperty(value = "主管姓名")
    @TableField("supervisor_name")
    private String supervisorName;

    @ApiModelProperty(value = "排序")
    @TableField("sort")
    private Integer sort;
}
