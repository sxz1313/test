package com.lxzh.talent.modular.enums;

/**
 * <p>
 * 退款订单状态枚举类
 * </p>
 *
 * @author wr
 * @since 2022-09-15
 */
public enum RefundOrderStatusEnum {

    WAIT_REFUND(1, "待退款"),
    DOING_REFUND(2, "退款中"),
    FINISH_REFUND(3, "退款完成"),
    ERROR(4, "退款失败");

    private Integer value;
    private String desc;

    RefundOrderStatusEnum(Integer value, String desc) {
        this.value = value;
        this.desc = desc;
    }

    public Integer getValue() {
        return this.value;
    }

    public String getDesc() {
        return desc;
    }

    @Override
    public String toString() {
        return this.desc;
    }

}
