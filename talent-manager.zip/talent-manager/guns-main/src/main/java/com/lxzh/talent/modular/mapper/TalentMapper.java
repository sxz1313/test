package com.lxzh.talent.modular.mapper;

import com.lxzh.talent.modular.entity.Talent;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 人才基本信息表 Mapper 接口
 * </p>
 *
 * @author wr
 * @since 2022-10-18
 */
public interface TalentMapper extends BaseMapper<Talent> {

}
