package com.lxzh.talent.modular.enums;

import lombok.Getter;

/**
 * @author: wsn
 */
@Getter
public enum CompanyStatusEnum {
    EXAMINE(0, "待审核"),
    ADOPT(1, "审核通过"),
    PASS(2, "审核不通过"),
    ;

    private final Integer code;

    private final String message;

    CompanyStatusEnum(Integer code, String message) {
        this.code = code;
        this.message = message;
    }

    public static CompanyStatusEnum getEnumByCode(Integer code) {
        for (CompanyStatusEnum value : values()) {
            if (value.getCode().equals(code)) {
                return value;
            }
        }
        return null;
    }

    public static CompanyStatusEnum getEnumByMsg(String msg) {
        for (CompanyStatusEnum value : values()) {
            if (value.getMessage().equals(msg)) {
                return value;
            }
        }
        return null;
    }
}
