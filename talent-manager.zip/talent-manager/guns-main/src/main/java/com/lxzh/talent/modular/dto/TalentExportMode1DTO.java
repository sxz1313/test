package com.lxzh.talent.modular.dto;

import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.annotation.write.style.ColumnWidth;
import lombok.Data;

/**
 * <p>
 * 人才库信息下载模板
 * </p>
 *
 * @author wr
 * @since 2022-10-25
 */
@Data
public class TalentExportMode1DTO {

    @ExcelProperty(value = {"单位信息"})
    @ColumnWidth(40)
    private String companyName;

    @ExcelProperty(value = {"姓名"})
    @ColumnWidth(20)
    private String name;

    @ExcelProperty(value = {"学历"})
    @ColumnWidth(20)
    private String educationLevelLabel;

    @ExcelProperty(value = {"性别"})
    @ColumnWidth(20)
    private String sexLabel;

    @ExcelProperty(value = {"身份证号"})
    @ColumnWidth(20)
    private String idNumber;

    @ExcelProperty(value = {"移动电话"})
    @ColumnWidth(20)
    private String mobile;

    @ExcelProperty(value = {"电子信箱"})
    @ColumnWidth(20)
    private String email;

    @ExcelProperty(value = {"民族"})
    @ColumnWidth(20)
    private String nationLabel;

//    @DateTimeFormat("yyyy-MM-dd")
    @ExcelProperty(value = {"出生日期"})
    @ColumnWidth(20)
    private String birthday;

    @ExcelProperty(value = {"出生地"})
    @ColumnWidth(30)
    private String birthPlace;

    @ExcelProperty(value = {"曾用名"})
    @ColumnWidth(20)
    private String usedName;

    @ExcelProperty(value = {"外文姓名"})
    @ColumnWidth(20)
    private String foreignName;

    @ExcelProperty(value = {"国籍"})
    @ColumnWidth(20)
    private String nationalityLabel;

    @ExcelProperty(value = {"籍贯"})
    @ColumnWidth(30)
    private String nativePlace;

    @ExcelProperty(value = {"户籍所在地"})
    @ColumnWidth(30)
    private String domicilePlace;

    @ExcelProperty(value = {"健康状况"})
    @ColumnWidth(20)
    private String healthConditionLabel;

    @ExcelProperty(value = {"婚姻状况"})
    @ColumnWidth(20)
    private String marriageStatusLabel;

    @ExcelProperty(value = {"职业"})
    @ColumnWidth(40)
    private String jobLabel;

    @ExcelProperty(value = {"职位"})
    @ColumnWidth(40)
    private String positionLabel;

    @ExcelProperty(value = {"职位级别"})
    @ColumnWidth(40)
    private String positionLevelLabel;

    @ExcelProperty(value = {"执业资格"})
    @ColumnWidth(40)
    private String mipaLabel;

    @ExcelProperty(value = {"专业技术职务"})
    @ColumnWidth(40)
    private String professionalTechnicalPostLabel;

    @ExcelProperty(value = {"专业技术岗位"})
    @ColumnWidth(40)
    private String professionalPositionLabel;

    @ExcelProperty(value = {"专业类别"})
    @ColumnWidth(40)
    private String professionalCategoryLabel;

    @ExcelProperty(value = {"个人专业特长"})
    @ColumnWidth(40)
    private String personalMajor;

    @ExcelProperty(value = {"个人爱好"})
    @ColumnWidth(40)
    private String personalPreference;

    @ExcelProperty(value = {"其他有效身份证件（军官证、护照）"})
    @ColumnWidth(40)
    private String otherIdentificationLabel;

    @ExcelProperty(value = {"证件号码"})
    @ColumnWidth(20)
    private String identificationNumber;

    @ExcelProperty(value = {"用工形式"})
    @ColumnWidth(40)
    private String employmentFormLabel;

    @ExcelProperty(value = {"联系地址"})
    @ColumnWidth(60)
    private String contactAddress;

    @ExcelProperty(value = {"邮政编码"})
    @ColumnWidth(20)
    private String postalCode;

    @ExcelProperty(value = {"固定电话"})
    @ColumnWidth(20)
    private String telephone;

    @ExcelProperty(value = {"人才属性"})
    @ColumnWidth(40)
    private String talentPropertyLabel;


    @ExcelProperty(value = {"学历及学位信息"})
    @ColumnWidth(60)
    private String talentEducation;

    @ExcelProperty(value = {"专业技术职称、职（执）业资格情况"})
    @ColumnWidth(60)
    private String talentProfessionalTechnical;

    @ExcelProperty(value = {"个人工作经历"})
    @ColumnWidth(60)
    private String talentWorkExperience;

    @ExcelProperty(value = {"政治面貌（党派）情况"})
    @ColumnWidth(60)
    private String talentPolitical;

    @ExcelProperty(value = {"年度考核情况"})
    @ColumnWidth(60)
    private String talentAnnualCheck;

    @ExcelProperty(value = {"荣誉称号（奖励）情况"})
    @ColumnWidth(60)
    private String talentHonor;

    @ExcelProperty(value = {"荣获专家称号情况"})
    @ColumnWidth(60)
    private String talentExpert;

    @ExcelProperty(value = {"惩戒(处分)情况"})
    @ColumnWidth(60)
    private String talentPunishment;

    @ExcelProperty(value = {"语言能力"})
    @ColumnWidth(60)
    private String talentLanguage;

    @ExcelProperty(value = {"培训教育情况"})
    @ColumnWidth(60)
    private String talentTrain;

    @ExcelProperty(value = {"主要论文及著作情况"})
    @ColumnWidth(60)
    private String talentPublication;

    @ExcelProperty(value = {"获得科研成果情况"})
    @ColumnWidth(60)
    private String talentAchievement;

    @ExcelProperty(value = {"获得专利情况"})
    @ColumnWidth(60)
    private String talentPatent;

    @ExcelProperty(value = {"参加学术团体情况"})
    @ColumnWidth(60)
    private String talentAcademy;

    @ExcelProperty(value = {"培养研究生情况"})
    @ColumnWidth(60)
    private String talentGraduateStudent;

    @ExcelProperty(value = {"家庭成员及主要社会关系"})
    @ColumnWidth(60)
    private String talentFamilyMember;
}
