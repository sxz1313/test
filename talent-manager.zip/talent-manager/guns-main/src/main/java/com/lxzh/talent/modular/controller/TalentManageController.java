package com.lxzh.talent.modular.controller;


import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.lxzh.talent.core.annotion.Permission;
import com.lxzh.talent.core.factory.PageFactory;
import com.lxzh.talent.core.pojo.page.PageResult;
import com.lxzh.talent.modular.entity.Talent;
import com.lxzh.talent.modular.enums.TalentStatusEnum;
import com.lxzh.talent.modular.param.TalentApplyQueryParam;
import com.lxzh.talent.modular.response.DCResponse;
import com.lxzh.talent.modular.service.*;
import com.lxzh.talent.modular.vo.*;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletResponse;
import java.util.List;

/**
 * <p>
 * 管理后台-人才库相关接口
 * </p>
 *
 * @author wr
 * @since 2022-10-18
 */
@Api(value = "/talent-manage", tags = {"管理后台-人才库相关接口"})
@RestController
@RequestMapping("/talent-manage")
public class TalentManageController {
    @Autowired
    private ITalentService talentService;
    @Autowired
    private ITalentDetailService talentDetailService;
    @Autowired
    private ITalentEducationService talentEducationService;
    @Autowired
    private ITalentProfessionalTechnicalService talentProfessionalTechnicalService;
    @Autowired
    private ITalentWorkExperienceService talentWorkExperienceService;
    @Autowired
    private ITalentPoliticalService talentPoliticalService;
    @Autowired
    private ITalentAnnualCheckService talentAnnualCheckService;
    @Autowired
    private ITalentHonorService talentHonorService;
    @Autowired
    private ITalentExpertService talentExpertService;
    @Autowired
    private ITalentPunishmentService talentPunishmentService;
    @Autowired
    private ITalentLanguageService talentLanguageService;
    @Autowired
    private ITalentTrainService talentTrainService;
    @Autowired
    private ITalentPublicationService talentPublicationService;
    @Autowired
    private ITalentAchievementService talentAchievementService;
    @Autowired
    private ITalentPatentService talentPatentService;
    @Autowired
    private ITalentAcademyService talentAcademyService;
    @Autowired
    private ITalentGraduateStudentService talentGraduateStudentService;
    @Autowired
    private ITalentFamilyMemberService talentFamilyMemberService;

    /**
     * 获取人才信息列表
     *
     * @param param
     * @return
     */
    @ApiOperation(value = "获取人才信息列表", notes = "获取人才信息列表")
    @PostMapping("/page")
    public DCResponse<PageResult<TalentApplyListVO>> findTalentApplyPage(@RequestBody TalentApplyQueryParam param) {
        Page<Talent> page = PageFactory.createPage(param);
        param.setStatus(TalentStatusEnum.NORMAL.getValue());
        return DCResponse.success(talentService.findTalentPage(page, param));
    }

    /**
     * 获取退会的人才信息列表
     *
     * @param param
     * @return
     */
    @ApiOperation(value = "获取退会的人才信息列表", notes = "获取退会的人才信息列表")
    @PostMapping("/exit-club-page")
    public DCResponse<PageResult<TalentApplyListVO>> findTalentExitClubPage(@RequestBody TalentApplyQueryParam param) {
        Page<Talent> page = PageFactory.createPage(param);
        param.setStatus(TalentStatusEnum.EXIT_CLUB.getValue());
        return DCResponse.success(talentService.findTalentPage(page, param));
    }

    /**
     * 退会
     *
     * @param id
     * @return
     */
    @ApiOperation(value = "退会", notes = "退会")
    @PostMapping("exit-club/{id}")
    @Permission
    public DCResponse<Boolean> exitClub(@PathVariable("id") Long id) {
        return DCResponse.success(talentService.exitClubById(id));
    }

    /**
     * 获取人才信息
     *
     * @param id
     * @return
     */
    @ApiOperation(value = "获取人才信息", notes = "获取人才信息")
    @GetMapping("/find-talent/{id}")
    @Permission
    public DCResponse<TalentApplyVO> findTalent(@PathVariable("id") Long id) {
        return DCResponse.success(talentService.findTalentById(id));
    }

    /**
     * 批量导出人才信息
     */
    @ApiOperation(value = "批量导出人才信息", notes = "批量导出人才信息")
    @PostMapping("batch-export")
    @Permission
    public void batchExport(@RequestBody TalentApplyQueryParam param, HttpServletResponse response) {
//        talentService.batchExport(response, TalentStatusEnum.NORMAL.getValue());
        param.setStatus(TalentStatusEnum.NORMAL.getValue());
        talentService.batchExportList(response, param);
    }

    /**
     * 批量导出退会人才信息
     */
    @ApiOperation(value = "批量导出退会人才信息", notes = "批量导出退会人才信息")
    @PostMapping("exit-club-batch-export")
    @Permission
    public void exitClubBatchExport(@RequestBody TalentApplyQueryParam param, HttpServletResponse response) {
//        talentService.batchExport(response, TalentStatusEnum.EXIT_CLUB.getValue());
        param.setStatus(TalentStatusEnum.EXIT_CLUB.getValue());
        talentService.batchExportList(response, param);
    }

    /**
     * 获取人才单位信息
     *
     * @param talentId
     * @return
     */
    @ApiOperation(value = "获取人才单位信息", notes = "获取人才单位信息")
    @PostMapping("/find-talent-company-apply/{talentId}")
    @Permission
    public DCResponse<TalentCompanyApplyVO> findTalentCompanyApply(@PathVariable("talentId") Long talentId) {
        return DCResponse.success(talentService.findTalentCompany(talentId));
    }

    /**
     * 获取人才基本信息
     *
     * @param talentId
     * @return
     */
    @ApiOperation(value = "获取人才基本信息", notes = "获取人才基本信息")
    @PostMapping("/find-talent-detail-apply/{talentId}")
    @Permission
    public DCResponse<TalentDetailApplyVO> findTalentDetailApply(@PathVariable("talentId") Long talentId) {
        return DCResponse.success(talentService.findTalentDetail(talentId));
    }

    /**
     * 获取学历及学位
     *
     * @param talentId
     * @return
     */
    @ApiOperation(value = "获取学历及学位", notes = "获取学历及学位")
    @PostMapping("/find-talent-education-apply/{talentId}")
    @Permission
    public DCResponse<List<TalentEducationApplyVO>> findTalentEducationApply(@PathVariable("talentId") Long talentId) {
        return DCResponse.success(talentEducationService.findTalentEducationList(talentId));
    }

    /**
     * 获取专业技术职称、职（执）业资格情况
     *
     * @param talentId
     * @return
     */
    @ApiOperation(value = "获取专业技术职称、职（执）业资格情况", notes = "获取专业技术职称、职（执）业资格情况")
    @PostMapping("/find-talent-professional-technical-apply/{talentId}")
    @Permission
    public DCResponse<List<TalentProfessionalTechnicalApplyVO>> findTalentProfessionalTechnicalApply(@PathVariable("talentId") Long talentId) {
        return DCResponse.success(talentProfessionalTechnicalService.findTalentProfessionalTechnicalList(talentId));
    }

    /**
     * 获取个人工作经历
     *
     * @param talentId
     * @return
     */
    @ApiOperation(value = "获取个人工作经历", notes = "获取个人工作经历")
    @PostMapping("/find-talent-work-experience-apply/{talentId}")
    @Permission
    public DCResponse<List<TalentWorkExperienceApplyVO>> findTalentWorkExperienceApply(@PathVariable("talentId") Long talentId) {
        return DCResponse.success(talentWorkExperienceService.findTalentWorkExperienceList(talentId));
    }

    /**
     * 获取政治面貌（党派）情况
     *
     * @param talentId
     * @return
     */
    @ApiOperation(value = "获取政治面貌（党派）情况", notes = "获取政治面貌（党派）情况")
    @PostMapping("/find-talent-political-apply/{talentId}")
    @Permission
    public DCResponse<List<TalentPoliticalApplyVO>> findTalentPoliticalApply(@PathVariable("talentId") Long talentId) {
        return DCResponse.success(talentPoliticalService.findTalentPoliticalList(talentId));
    }

    /**
     * 获取年度考核情况
     *
     * @param talentId
     * @return
     */
    @ApiOperation(value = "获取年度考核情况", notes = "获取年度考核情况")
    @PostMapping("/find-talent-annual-check-apply/{talentId}")
    @Permission
    public DCResponse<List<TalentAnnualCheckApplyVO>> findTalentAnnualCheckApply(@PathVariable("talentId") Long talentId) {
        return DCResponse.success(talentAnnualCheckService.findTalentAnnualCheckList(talentId));
    }

    /**
     * 获取荣誉称号（奖励）情况
     *
     * @param talentId
     * @return
     */
    @ApiOperation(value = "获取荣誉称号（奖励）情况", notes = "获取荣誉称号（奖励）情况")
    @PostMapping("/find-talent-honor-apply/{talentId}")
    @Permission
    public DCResponse<List<TalentHonorApplyVO>> findTalentHonorApply(@PathVariable("talentId") Long talentId) {
        return DCResponse.success(talentHonorService.findTalentHonorList(talentId));
    }

    /**
     * 获取荣获专家称号情况
     *
     * @param talentId
     * @return
     */
    @ApiOperation(value = "获取荣获专家称号情况", notes = "获取荣获专家称号情况")
    @PostMapping("/find-talent-expert-apply/{talentId}")
    @Permission
    public DCResponse<List<TalentExpertApplyVO>> findTalentExpertApply(@PathVariable("talentId") Long talentId) {
        return DCResponse.success(talentExpertService.findTalentExpertList(talentId));
    }

    /**
     * 获取惩戒(处分)情况
     *
     * @param talentId
     * @return
     */
    @ApiOperation(value = "获取惩戒(处分)情况", notes = "获取惩戒(处分)情况")
    @PostMapping("/find-talent-punishment-apply/{talentId}")
    @Permission
    public DCResponse<List<TalentPunishmentApplyVO>> findTalentPunishmentApply(@PathVariable("talentId") Long talentId) {
        return DCResponse.success(talentPunishmentService.findTalentPunishmentList(talentId));
    }

    /**
     * 获取语言能力
     *
     * @param talentId
     * @return
     */
    @ApiOperation(value = "获取语言能力", notes = "获取语言能力")
    @PostMapping("/find-talent-language-apply/{talentId}")
    @Permission
    public DCResponse<List<TalentLanguageApplyVO>> findTalentLanguageApply(@PathVariable("talentId") Long talentId) {
        return DCResponse.success(talentLanguageService.findTalentLanguageList(talentId));
    }

    /**
     * 获取培训教育情况
     *
     * @param talentId
     * @return
     */
    @ApiOperation(value = "获取培训教育情况", notes = "获取培训教育情况")
    @PostMapping("/find-talent-train-apply/{talentId}")
    @Permission
    public DCResponse<List<TalentTrainApplyVO>> findTalentTrainApply(@PathVariable("talentId") Long talentId) {
        return DCResponse.success(talentTrainService.findTalentTrainList(talentId));
    }

    /**
     * 获取主要论文及著作情况
     *
     * @param talentId
     * @return
     */
    @ApiOperation(value = "获取主要论文及著作情况", notes = "获取主要论文及著作情况")
    @PostMapping("/find-talent-publication-apply/{talentId}")
    @Permission
    public DCResponse<List<TalentPublicationApplyVO>> findTalentPublicationApply(@PathVariable("talentId") Long talentId) {
        return DCResponse.success(talentPublicationService.findTalentPublicationList(talentId));
    }

    /**
     * 获取科研成果情况
     *
     * @param talentId
     * @return
     */
    @ApiOperation(value = "获取科研成果情况", notes = "获取科研成果情况")
    @PostMapping("/find-talent-achievement-apply/{talentId}")
    @Permission
    public DCResponse<List<TalentAchievementApplyVO>> findTalentAchievementApply(@PathVariable("talentId") Long talentId) {
        return DCResponse.success(talentAchievementService.findTalentAchievementList(talentId));
    }

    /**
     * 获取专利情况
     *
     * @param talentId
     * @return
     */
    @ApiOperation(value = "获取专利情况", notes = "获取专利情况")
    @PostMapping("/find-talent-patent-apply/{talentId}")
    @Permission
    public DCResponse<List<TalentPatentApplyVO>> findTalentPatentApply(@PathVariable("talentId") Long talentId) {
        return DCResponse.success(talentPatentService.findTalentPatentList(talentId));
    }

    /**
     * 获取参加学术团体情况
     *
     * @param talentId
     * @return
     */
    @ApiOperation(value = "获取参加学术团体情况", notes = "获取参加学术团体情况")
    @PostMapping("/find-talent-academy-apply/{talentId}")
    @Permission
    public DCResponse<List<TalentAcademyApplyVO>> findTalentAcademyApply(@PathVariable("talentId") Long talentId) {
        return DCResponse.success(talentAcademyService.findTalentAcademyList(talentId));
    }

    /**
     * 获取培养研究生情况
     *
     * @param talentId
     * @return
     */
    @ApiOperation(value = "获取培养研究生情况", notes = "获取培养研究生情况")
    @PostMapping("/find-talent-graduate-student-apply/{talentId}")
    @Permission
    public DCResponse<List<TalentGraduateStudentApplyVO>> findTalentGraduateStudentApply(@PathVariable("talentId") Long talentId) {
        return DCResponse.success(talentGraduateStudentService.findTalentGraduateStudentList(talentId));
    }

    /**
     * 获取家庭成员及主要社会关系
     *
     * @param talentId
     * @return
     */
    @ApiOperation(value = "获取家庭成员及主要社会关系", notes = "获取家庭成员及主要社会关系")
    @PostMapping("/find-talent-family-member-apply/{talentId}")
    @Permission
    public DCResponse<List<TalentFamilyMemberApplyVO>> findTalentFamilyMemberApply(@PathVariable("talentId") Long talentId) {
        return DCResponse.success(talentFamilyMemberService.findTalentFamilyMemberList(talentId));
    }








    /*************************************************test**************************************************/

//    /**
//     * 批量导出人才信息test
//     */
//    @ApiOperation(value = "批量导出人才信息test", notes = "批量导出人才信息test")
//    @GetMapping("batch-export/test")
//    public void batchExportTest(HttpServletResponse response) {
//        TalentApplyQueryParam param = new TalentApplyQueryParam();
//        param.setStatus(TalentStatusEnum.NORMAL.getValue());
//        param.setEducationLevelList(CollUtil.newArrayList("135","136","137","138"));
//        talentService.batchExportList(response, param);
//    }
//
//    /**
//     * 批量导出人才信息test
//     */
//    @ApiOperation(value = "批量导出人才all信息test", notes = "批量导出人才all信息test")
//    @GetMapping("batch-export-all/test")
//    public void batchExportAllTest(HttpServletResponse response) {
//        TalentApplyQueryParam param = new TalentApplyQueryParam();
//        param.setStatus(TalentStatusEnum.NORMAL.getValue());
//        talentService.batchExportList(response, param);
//    }
//
//    /**
//     * 批量导出人才信息test
//     */
//    @ApiOperation(value = "批量导出人才degree信息test", notes = "批量导出人才degree信息test")
//    @GetMapping("batch-export-degree/test")
//    public void batchExportDegreeTest(HttpServletResponse response) {
//        TalentApplyQueryParam param = new TalentApplyQueryParam();
//        param.setStatus(TalentStatusEnum.NORMAL.getValue());
//        param.setDegreeValues("144,145");
//        talentService.batchExportList(response, param);
//    }
//
//    /**
//     * 批量导出人才信息test
//     */
//    @ApiOperation(value = "批量导出人才honour信息test", notes = "批量导出人才honour信息test")
//    @GetMapping("batch-export-honour/test")
//    public void batchExportHonourTest(HttpServletResponse response) {
//        TalentApplyQueryParam param = new TalentApplyQueryParam();
//        param.setStatus(TalentStatusEnum.NORMAL.getValue());
//        param.setExpertHonorName("333");
//        talentService.batchExportList(response, param);
//    }


    /*************************************************test**************************************************/
}
