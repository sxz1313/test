package com.lxzh.talent.modular.mapper;

import com.lxzh.talent.modular.entity.TalentAnnualCheckApply;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 人才信息-年度考核情况(填写近五年情况)申请表 Mapper 接口
 * </p>
 *
 * @author wr
 * @since 2022-10-18
 */
public interface TalentAnnualCheckApplyMapper extends BaseMapper<TalentAnnualCheckApply> {

}
