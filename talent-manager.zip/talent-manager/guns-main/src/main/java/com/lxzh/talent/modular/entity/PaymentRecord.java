package com.lxzh.talent.modular.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.lxzh.talent.core.pojo.base.entity.BasicEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.math.BigDecimal;

/**
 * <p>
 * 订单支付记录表
 * </p>
 *
 * @author wr
 * @since 2022-09-28
 */
@Data
@EqualsAndHashCode(callSuper = false)
@TableName("payment_record")
@ApiModel(value="PaymentRecord对象", description="订单支付记录表")
public class PaymentRecord extends BasicEntity {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "id")
    @TableId(value = "id", type = IdType.AUTO)
    private Long id;

    @ApiModelProperty(value = "订单id")
    @TableField("order_id")
    private Long orderId;

    @ApiModelProperty(value = "付款人id")
    @TableField("user_id")
    private Long userId;

    @ApiModelProperty(value = "支付方式 1、微信")
    @TableField("payment_type")
    private Integer paymentType;

    @ApiModelProperty(value = "支付金额")
    @TableField("total_amount")
    private BigDecimal totalAmount;

    @ApiModelProperty(value = "状态 1-待付款，2-支付中，3-支付完成，4-支付失败")
    @TableField("status")
    private Integer status;

    @ApiModelProperty(value = "交易流水号")
    @TableField("out_trade_no")
    private String outTradeNo;
}
