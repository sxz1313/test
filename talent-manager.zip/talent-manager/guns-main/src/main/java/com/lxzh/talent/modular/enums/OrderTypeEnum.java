package com.lxzh.talent.modular.enums;

import java.util.Arrays;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

/**
 * <p>
 * 订单类型枚举类
 * </p>
 *
 * @author wr
 * @since 2022-09-15
 */
public enum OrderTypeEnum {

    BID_ORDER(1, "报名订单"),
    DEPOSIT_ORDER(2, "保证金订单");

    private Integer value;
    private String desc;

    OrderTypeEnum(Integer value, String desc) {
        this.value = value;
        this.desc = desc;
    }

    public Integer getValue() {
        return this.value;
    }

    public String getDesc() {
        return desc;
    }

    @Override
    public String toString() {
        return this.desc;
    }

    public static OrderTypeEnum getOrderTypeEnum(Integer code) {
        if (Objects.isNull(code)) {
            return null;
        }
        Map<Integer, OrderTypeEnum> templateEnumMap = Arrays.stream(OrderTypeEnum.values()).collect(Collectors.toMap(OrderTypeEnum::getValue, o -> o));
        return templateEnumMap.get(code);
    }

}
