package com.lxzh.talent.modular.controller;


import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.lxzh.talent.core.factory.PageFactory;
import com.lxzh.talent.core.pojo.page.PageResult;
import com.lxzh.talent.modular.entity.TalentApply;
import com.lxzh.talent.modular.param.*;
import com.lxzh.talent.modular.response.DCResponse;
import com.lxzh.talent.modular.service.*;
import com.lxzh.talent.modular.utils.UniqueOrderGenerate;
import com.lxzh.talent.modular.utils.UserKit;
import com.lxzh.talent.modular.vo.*;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

/**
 * <p>
 * 人才信息申请 前端控制器
 * </p>
 *
 * @author wr
 * @since 2022-10-18
 */
@Api(value = "/talent-apply", tags = {"人才信息申请维护接口"})
@RestController
@RequestMapping("/talent-apply")
public class TalentApplyController {
    @Autowired
    private ITalentApplyService talentApplyService;
    @Autowired
    private ITalentDetailApplyService talentDetailApplyService;
    @Autowired
    private ITalentEducationApplyService talentEducationApplyService;
    @Autowired
    private ITalentProfessionalTechnicalApplyService talentProfessionalTechnicalApplyService;
    @Autowired
    private ITalentWorkExperienceApplyService talentWorkExperienceApplyService;
    @Autowired
    private ITalentPoliticalApplyService talentPoliticalApplyService;
    @Autowired
    private ITalentAnnualCheckApplyService talentAnnualCheckApplyService;
    @Autowired
    private ITalentHonorApplyService talentHonorApplyService;
    @Autowired
    private ITalentExpertApplyService talentExpertApplyService;
    @Autowired
    private ITalentPunishmentApplyService talentPunishmentApplyService;
    @Autowired
    private ITalentLanguageApplyService talentLanguageApplyService;
    @Autowired
    private ITalentTrainApplyService talentTrainApplyService;
    @Autowired
    private ITalentPublicationApplyService talentPublicationApplyService;
    @Autowired
    private ITalentAchievementApplyService talentAchievementApplyService;
    @Autowired
    private ITalentPatentApplyService talentPatentApplyService;
    @Autowired
    private ITalentAcademyApplyService talentAcademyApplyService;
    @Autowired
    private ITalentGraduateStudentApplyService talentGraduateStudentApplyService;
    @Autowired
    private ITalentFamilyMemberApplyService talentFamilyMemberApplyService;

    /**
     * 生成人才基本信息申请Id
     *
     * @return
     */
    @ApiOperation(value = "生成人才基本信息申请Id", notes = "生成人才基本信息申请Id")
    @GetMapping("/generate-talent-apply-id")
    public DCResponse<Long> generateTalentApplyId() {
        return DCResponse.success(UniqueOrderGenerate.generateId());
    }

    /**
     * 获取人才信息列表
     *
     * @param param
     * @return
     */
    @ApiOperation(value = "获取人才信息列表", notes = "获取人才信息列表")
    @PostMapping("/page")
    public DCResponse<PageResult<TalentApplyListVO>> findTalentApplyPage(@RequestBody TalentApplyQueryParam param) {
        Page<TalentApply> page = PageFactory.createPage(param);
        param.setUserId(UserKit.getUserId());
        param.setManageQuery(false);
        return DCResponse.success(talentApplyService.findTalentApplyPage(page, param));
    }

    /**
     * 获取人才信息
     *
     * @param id
     * @return
     */
    @ApiOperation(value = "获取人才信息", notes = "获取人才信息")
    @GetMapping("/find-talent-apply/{id}")
    public DCResponse<TalentApplyVO> findTalentApply(@PathVariable("id") Long id) {
        return DCResponse.success(talentApplyService.findTalentApplyById(id));
    }

    /**
     * 获取人才单位信息
     *
     * @param talentApplyId
     * @return
     */
    @ApiOperation(value = "获取人才单位信息", notes = "获取人才单位信息")
    @PostMapping("/find-talent-company-apply/{talentApplyId}")
    public DCResponse<TalentCompanyApplyVO> findTalentCompanyApply(@PathVariable("talentApplyId") Long talentApplyId) {
        return DCResponse.success(talentApplyService.findTalentCompanyApply(talentApplyId));
    }

    /**
     * 保存人才单位信息
     *
     * @param param
     * @return
     */
    @ApiOperation(value = "保存人才单位信息", notes = "保存人才单位信息")
    @PostMapping("/save-talent-company-apply")
    public DCResponse<Boolean> saveTalentCompanyApply(@RequestBody TalentCompanyApplyParam param) {
        Boolean flag = talentApplyService.checkHasUpdateData(param);
        if (flag) {
            return DCResponse.success(flag);
        }
        param.setUserId(UserKit.getUserId());
        param.setIgnoreUpdateJson(false);
        param.setIgnoreCheckValid(false);
        return DCResponse.success(talentApplyService.saveTalentCompanyApply(param));
    }

    /**
     * 获取人才基本信息
     *
     * @param talentApplyId
     * @return
     */
    @ApiOperation(value = "获取人才基本信息", notes = "获取人才基本信息")
    @PostMapping("/find-talent-detail-apply/{talentApplyId}")
    public DCResponse<TalentDetailApplyVO> findTalentDetailApply(@PathVariable("talentApplyId") Long talentApplyId) {
        return DCResponse.success(talentApplyService.findTalentDetailApply(talentApplyId));
    }

    /**
     * 保存人才基本信息
     *
     * @param param
     * @return
     */
    @ApiOperation(value = "保存人才基本信息", notes = "保存人才基本信息")
    @PostMapping("/save-talent-apply")
    public DCResponse<Boolean> saveTalentApply(@RequestBody TalentDetailApplyParam param) {
        Boolean flag = talentApplyService.checkHasUpdateData(param);
        if (flag) {
            return DCResponse.success(flag);
        }
        param.setUserId(UserKit.getUserId());
        param.setIgnoreUpdateJson(false);
        param.setIgnoreCheckValid(false);
        return DCResponse.success(talentApplyService.saveTalentApply(param));
    }

    /**
     * 获取学历及学位
     *
     * @param talentApplyId
     * @return
     */
    @ApiOperation(value = "获取学历及学位", notes = "获取学历及学位")
    @PostMapping("/find-talent-education-apply/{talentApplyId}")
    public DCResponse<List<TalentEducationApplyVO>> findTalentEducationApply(@PathVariable("talentApplyId") Long talentApplyId) {
        return DCResponse.success(talentEducationApplyService.findTalentEducationApplyList(talentApplyId));
    }

    /**
     * 保存学历及学位
     *
     * @param param
     * @return
     */
    @ApiOperation(value = "保存学历及学位", notes = "保存学历及学位")
    @PostMapping("/save-talent-education-apply")
    public DCResponse<Boolean> saveTalentEducationApply(@RequestBody TalentEducationApplyParam param) {
        Boolean flag = talentApplyService.checkHasUpdateData(param);
        if (flag) {
            return DCResponse.success(flag);
        }
        param.setUserId(UserKit.getUserId());
        param.setIgnoreUpdateJson(false);
        param.setIgnoreCheckValid(false);
        return DCResponse.success(talentEducationApplyService.saveTalentEducationApply(param));
    }

    /**
     * 获取专业技术职称、职（执）业资格情况
     *
     * @param talentApplyId
     * @return
     */
    @ApiOperation(value = "获取专业技术职称、职（执）业资格情况", notes = "获取专业技术职称、职（执）业资格情况")
    @PostMapping("/find-talent-professional-technical-apply/{talentApplyId}")
    public DCResponse<List<TalentProfessionalTechnicalApplyVO>> findTalentProfessionalTechnicalApply(@PathVariable("talentApplyId") Long talentApplyId) {
        return DCResponse.success(talentProfessionalTechnicalApplyService.findTalentProfessionalTechnicalApplyList(talentApplyId));
    }

    /**
     * 保存专业技术职称、职（执）业资格情况
     *
     * @param param
     * @return
     */
    @ApiOperation(value = "保存专业技术职称、职（执）业资格情况", notes = "保存专业技术职称、职（执）业资格情况")
    @PostMapping("/save-talent-professional-technical-apply")
    public DCResponse<Boolean> saveTalentProfessionalTechnicalApply(@RequestBody TalentProfessionalTechnicalApplyParam param) {
        Boolean flag = talentApplyService.checkHasUpdateData(param);
        if (flag) {
            return DCResponse.success(flag);
        }
        param.setUserId(UserKit.getUserId());
        param.setIgnoreUpdateJson(false);
        param.setIgnoreCheckValid(false);
        return DCResponse.success(talentProfessionalTechnicalApplyService.saveTalentProfessionalTechnicalApply(param));
    }

    /**
     * 获取个人工作经历
     *
     * @param talentApplyId
     * @return
     */
    @ApiOperation(value = "获取个人工作经历", notes = "获取个人工作经历")
    @PostMapping("/find-talent-work-experience-apply/{talentApplyId}")
    public DCResponse<List<TalentWorkExperienceApplyVO>> findTalentWorkExperienceApply(@PathVariable("talentApplyId") Long talentApplyId) {
        return DCResponse.success(talentWorkExperienceApplyService.findTalentWorkExperienceApplyList(talentApplyId));
    }

    /**
     * 保存个人工作经历
     *
     * @param param
     * @return
     */
    @ApiOperation(value = "保存个人工作经历", notes = "保存个人工作经历")
    @PostMapping("/save-talent-work-experience-apply")
    public DCResponse<Boolean> saveTalentWorkExperienceApply(@RequestBody TalentWorkExperienceApplyParam param) {
        Boolean flag = talentApplyService.checkHasUpdateData(param);
        if (flag) {
            return DCResponse.success(flag);
        }
        param.setUserId(UserKit.getUserId());
        param.setIgnoreUpdateJson(false);
        param.setIgnoreCheckValid(false);
        return DCResponse.success(talentWorkExperienceApplyService.saveTalentWorkExperienceApply(param));
    }

    /**
     * 获取政治面貌（党派）情况
     *
     * @param talentApplyId
     * @return
     */
    @ApiOperation(value = "获取政治面貌（党派）情况", notes = "获取政治面貌（党派）情况")
    @PostMapping("/find-talent-political-apply/{talentApplyId}")
    public DCResponse<List<TalentPoliticalApplyVO>> findTalentPoliticalApply(@PathVariable("talentApplyId") Long talentApplyId) {
        return DCResponse.success(talentPoliticalApplyService.findTalentPoliticalApplyList(talentApplyId));
    }

    /**
     * 保存政治面貌（党派）情况
     *
     * @param param
     * @return
     */
    @ApiOperation(value = "保存政治面貌（党派）情况", notes = "保存政治面貌（党派）情况")
    @PostMapping("/save-talent-political-apply")
    public DCResponse<Boolean> saveTalentPoliticalApply(@RequestBody TalentPoliticalApplyParam param) {
        Boolean flag = talentApplyService.checkHasUpdateData(param);
        if (flag) {
            return DCResponse.success(flag);
        }
        param.setUserId(UserKit.getUserId());
        param.setIgnoreUpdateJson(false);
        param.setIgnoreCheckValid(false);
        return DCResponse.success(talentPoliticalApplyService.saveTalentPoliticalApply(param));
    }

    /**
     * 获取年度考核情况
     *
     * @param talentApplyId
     * @return
     */
    @ApiOperation(value = "获取年度考核情况", notes = "获取年度考核情况")
    @PostMapping("/find-talent-annual-check-apply/{talentApplyId}")
    public DCResponse<List<TalentAnnualCheckApplyVO>> findTalentAnnualCheckApply(@PathVariable("talentApplyId") Long talentApplyId) {
        return DCResponse.success(talentAnnualCheckApplyService.findTalentAnnualCheckApplyList(talentApplyId));
    }

    /**
     * 保存年度考核情况
     *
     * @param param
     * @return
     */
    @ApiOperation(value = "保存年度考核情况", notes = "保存年度考核情况")
    @PostMapping("/save-talent-annual-check-apply")
    public DCResponse<Boolean> saveTalentAnnualCheckApply(@RequestBody TalentAnnualCheckApplyParam param) {
        Boolean flag = talentApplyService.checkHasUpdateData(param);
        if (flag) {
            return DCResponse.success(flag);
        }
        param.setUserId(UserKit.getUserId());
        param.setIgnoreUpdateJson(false);
        param.setIgnoreCheckValid(false);
        return DCResponse.success(talentAnnualCheckApplyService.saveTalentAnnualCheckApply(param));
    }

    /**
     * 获取荣誉称号（奖励）情况
     *
     * @param talentApplyId
     * @return
     */
    @ApiOperation(value = "获取荣誉称号（奖励）情况", notes = "获取荣誉称号（奖励）情况")
    @PostMapping("/find-talent-honor-apply/{talentApplyId}")
    public DCResponse<List<TalentHonorApplyVO>> findTalentHonorApply(@PathVariable("talentApplyId") Long talentApplyId) {
        return DCResponse.success(talentHonorApplyService.findTalentHonorApplyList(talentApplyId));
    }

    /**
     * 保存荣誉称号（奖励）情况
     *
     * @param param
     * @return
     */
    @ApiOperation(value = "保存荣誉称号（奖励）情况", notes = "保存荣誉称号（奖励）情况")
    @PostMapping("/save-talent-honor-apply")
    public DCResponse<Boolean> saveTalentHonorApply(@RequestBody TalentHonorApplyParam param) {
        Boolean flag = talentApplyService.checkHasUpdateData(param);
        if (flag) {
            return DCResponse.success(flag);
        }
        param.setUserId(UserKit.getUserId());
        param.setIgnoreUpdateJson(false);
        param.setIgnoreCheckValid(false);
        return DCResponse.success(talentHonorApplyService.saveTalentHonorApply(param));
    }

    /**
     * 获取荣获专家称号情况
     *
     * @param talentApplyId
     * @return
     */
    @ApiOperation(value = "获取荣获专家称号情况", notes = "获取荣获专家称号情况")
    @PostMapping("/find-talent-expert-apply/{talentApplyId}")
    public DCResponse<List<TalentExpertApplyVO>> findTalentExpertApply(@PathVariable("talentApplyId") Long talentApplyId) {
        return DCResponse.success(talentExpertApplyService.findTalentExpertApplyList(talentApplyId));
    }

    /**
     * 保存荣获专家称号情况
     *
     * @param param
     * @return
     */
    @ApiOperation(value = "保存荣获专家称号情况", notes = "保存荣获专家称号情况")
    @PostMapping("/save-talent-expert-apply")
    public DCResponse<Boolean> saveTalentExpertApply(@RequestBody TalentExpertApplyParam param) {
        Boolean flag = talentApplyService.checkHasUpdateData(param);
        if (flag) {
            return DCResponse.success(flag);
        }
        param.setUserId(UserKit.getUserId());
        param.setIgnoreUpdateJson(false);
        param.setIgnoreCheckValid(false);
        return DCResponse.success(talentExpertApplyService.saveTalentExpertApply(param));
    }

    /**
     * 获取惩戒(处分)情况
     *
     * @param talentApplyId
     * @return
     */
    @ApiOperation(value = "获取惩戒(处分)情况", notes = "获取惩戒(处分)情况")
    @PostMapping("/find-talent-punishment-apply/{talentApplyId}")
    public DCResponse<List<TalentPunishmentApplyVO>> findTalentPunishmentApply(@PathVariable("talentApplyId") Long talentApplyId) {
        return DCResponse.success(talentPunishmentApplyService.findTalentPunishmentApplyList(talentApplyId));
    }

    /**
     * 保存惩戒(处分)情况
     *
     * @param param
     * @return
     */
    @ApiOperation(value = "保存惩戒(处分)情况", notes = "保存惩戒(处分)情况")
    @PostMapping("/save-talent-punishment-apply")
    public DCResponse<Boolean> saveTalentPunishmentApply(@RequestBody TalentPunishmentApplyParam param) {
        Boolean flag = talentApplyService.checkHasUpdateData(param);
        if (flag) {
            return DCResponse.success(flag);
        }
        param.setUserId(UserKit.getUserId());
        param.setIgnoreUpdateJson(false);
        param.setIgnoreCheckValid(false);
        return DCResponse.success(talentPunishmentApplyService.saveTalentPunishmentApply(param));
    }

    /**
     * 获取语言能力
     *
     * @param talentApplyId
     * @return
     */
    @ApiOperation(value = "获取语言能力", notes = "获取语言能力")
    @PostMapping("/find-talent-language-apply/{talentApplyId}")
    public DCResponse<List<TalentLanguageApplyVO>> findTalentLanguageApply(@PathVariable("talentApplyId") Long talentApplyId) {
        return DCResponse.success(talentLanguageApplyService.findTalentLanguageApplyList(talentApplyId));
    }


    /**
     * 保存语言能力
     *
     * @param param
     * @return
     */
    @ApiOperation(value = "保存语言能力", notes = "保存语言能力")
    @PostMapping("/save-talent-language-apply")
    public DCResponse<Boolean> saveTalentLanguageApply(@RequestBody TalentLanguageApplyParam param) {
        Boolean flag = talentApplyService.checkHasUpdateData(param);
        if (flag) {
            return DCResponse.success(flag);
        }
        param.setUserId(UserKit.getUserId());
        param.setIgnoreUpdateJson(false);
        param.setIgnoreCheckValid(false);
        return DCResponse.success(talentLanguageApplyService.saveTalentLanguageApply(param));
    }

    /**
     * 获取培训教育情况
     *
     * @param talentApplyId
     * @return
     */
    @ApiOperation(value = "获取培训教育情况", notes = "获取培训教育情况")
    @PostMapping("/find-talent-train-apply/{talentApplyId}")
    public DCResponse<List<TalentTrainApplyVO>> findTalentTrainApply(@PathVariable("talentApplyId") Long talentApplyId) {
        return DCResponse.success(talentTrainApplyService.findTalentTrainApplyList(talentApplyId));
    }

    /**
     * 保存培训教育情况
     *
     * @param param
     * @return
     */
    @ApiOperation(value = "保存培训教育情况", notes = "保存培训教育情况")
    @PostMapping("/save-talent-train-apply")
    public DCResponse<Boolean> saveTalentTrainApply(@RequestBody TalentTrainApplyParam param) {
        Boolean flag = talentApplyService.checkHasUpdateData(param);
        if (flag) {
            return DCResponse.success(flag);
        }
        param.setUserId(UserKit.getUserId());
        param.setIgnoreUpdateJson(false);
        param.setIgnoreCheckValid(false);
        return DCResponse.success(talentTrainApplyService.saveTalentTrainApply(param));
    }

    /**
     * 获取主要论文及著作情况
     *
     * @param talentApplyId
     * @return
     */
    @ApiOperation(value = "获取主要论文及著作情况", notes = "获取主要论文及著作情况")
    @PostMapping("/find-talent-publication-apply/{talentApplyId}")
    public DCResponse<List<TalentPublicationApplyVO>> findTalentPublicationApply(@PathVariable("talentApplyId") Long talentApplyId) {
        return DCResponse.success(talentPublicationApplyService.findTalentPublicationApplyList(talentApplyId));
    }

    /**
     * 保存主要论文及著作情况
     *
     * @param param
     * @return
     */
    @ApiOperation(value = "保存主要论文及著作情况", notes = "保存主要论文及著作情况")
    @PostMapping("/save-talent-publication-apply")
    public DCResponse<Boolean> saveTalentPublicationApply(@RequestBody TalentPublicationApplyParam param) {
        Boolean flag = talentApplyService.checkHasUpdateData(param);
        if (flag) {
            return DCResponse.success(flag);
        }
        param.setUserId(UserKit.getUserId());
        param.setIgnoreUpdateJson(false);
        param.setIgnoreCheckValid(false);
        return DCResponse.success(talentPublicationApplyService.saveTalentPublicationApply(param));
    }

    /**
     * 获取科研成果情况
     *
     * @param talentApplyId
     * @return
     */
    @ApiOperation(value = "获取科研成果情况", notes = "获取科研成果情况")
    @PostMapping("/find-talent-achievement-apply/{talentApplyId}")
    public DCResponse<List<TalentAchievementApplyVO>> findTalentAchievementApply(@PathVariable("talentApplyId") Long talentApplyId) {
        return DCResponse.success(talentAchievementApplyService.findTalentAchievementApplyList(talentApplyId));
    }

    /**
     * 保存科研成果情况
     *
     * @param param
     * @return
     */
    @ApiOperation(value = "保存科研成果情况", notes = "保存科研成果情况")
    @PostMapping("/save-talent-achievement-apply")
    public DCResponse<Boolean> saveTalentAchievementApply(@RequestBody TalentAchievementApplyParam param) {
        Boolean flag = talentApplyService.checkHasUpdateData(param);
        if (flag) {
            return DCResponse.success(flag);
        }
        param.setUserId(UserKit.getUserId());
        param.setIgnoreUpdateJson(false);
        param.setIgnoreCheckValid(false);
        return DCResponse.success(talentAchievementApplyService.saveTalentAchievementApply(param));
    }

    /**
     * 获取专利情况
     *
     * @param talentApplyId
     * @return
     */
    @ApiOperation(value = "获取专利情况", notes = "获取专利情况")
    @PostMapping("/find-talent-patent-apply/{talentApplyId}")
    public DCResponse<List<TalentPatentApplyVO>> findTalentPatentApply(@PathVariable("talentApplyId") Long talentApplyId) {
        return DCResponse.success(talentPatentApplyService.findTalentPatentApplyList(talentApplyId));
    }

    /**
     * 保存获得专利情况
     *
     * @param param
     * @return
     */
    @ApiOperation(value = "保存获得专利情况", notes = "保存获得专利情况")
    @PostMapping("/save-talent-patent-apply")
    public DCResponse<Boolean> saveTalentPatentApply(@RequestBody TalentPatentApplyParam param) {
        Boolean flag = talentApplyService.checkHasUpdateData(param);
        if (flag) {
            return DCResponse.success(flag);
        }
        param.setUserId(UserKit.getUserId());
        param.setIgnoreUpdateJson(false);
        param.setIgnoreCheckValid(false);
        return DCResponse.success(talentPatentApplyService.saveTalentPatentApply(param));
    }

    /**
     * 获取参加学术团体情况
     *
     * @param talentApplyId
     * @return
     */
    @ApiOperation(value = "获取参加学术团体情况", notes = "获取参加学术团体情况")
    @PostMapping("/find-talent-academy-apply/{talentApplyId}")
    public DCResponse<List<TalentAcademyApplyVO>> findTalentAcademyApply(@PathVariable("talentApplyId") Long talentApplyId) {
        return DCResponse.success(talentAcademyApplyService.findTalentAcademyApplyList(talentApplyId));
    }

    /**
     * 保存参加学术团体情况
     *
     * @param param
     * @return
     */
    @ApiOperation(value = "保存参加学术团体情况", notes = "保存参加学术团体情况")
    @PostMapping("/save-talent-academy-apply")
    public DCResponse<Boolean> saveTalentAcademyApply(@RequestBody TalentAcademyApplyParam param) {
        Boolean flag = talentApplyService.checkHasUpdateData(param);
        if (flag) {
            return DCResponse.success(flag);
        }
        param.setUserId(UserKit.getUserId());
        param.setIgnoreUpdateJson(false);
        param.setIgnoreCheckValid(false);
        return DCResponse.success(talentAcademyApplyService.saveTalentAcademyApply(param));
    }

    /**
     * 获取培养研究生情况
     *
     * @param talentApplyId
     * @return
     */
    @ApiOperation(value = "获取培养研究生情况", notes = "获取培养研究生情况")
    @PostMapping("/find-talent-graduate-student-apply/{talentApplyId}")
    public DCResponse<List<TalentGraduateStudentApplyVO>> findTalentGraduateStudentApply(@PathVariable("talentApplyId") Long talentApplyId) {
        return DCResponse.success(talentGraduateStudentApplyService.findTalentGraduateStudentApplyList(talentApplyId));
    }

    /**
     * 保存培养研究生情况
     *
     * @param param
     * @return
     */
    @ApiOperation(value = "保存培养研究生情况", notes = "保存培养研究生情况")
    @PostMapping("/save-talent-graduate-student-apply")
    public DCResponse<Boolean> saveTalentGraduateStudentApply(@RequestBody TalentGraduateStudentApplyParam param) {
        Boolean flag = talentApplyService.checkHasUpdateData(param);
        if (flag) {
            return DCResponse.success(flag);
        }
        param.setUserId(UserKit.getUserId());
        param.setIgnoreUpdateJson(false);
        param.setIgnoreCheckValid(false);
        return DCResponse.success(talentGraduateStudentApplyService.saveTalentGraduateStudentApply(param));
    }

    /**
     * 获取家庭成员及主要社会关系
     *
     * @param talentApplyId
     * @return
     */
    @ApiOperation(value = "获取家庭成员及主要社会关系", notes = "获取家庭成员及主要社会关系")
    @PostMapping("/find-talent-family-member-apply/{talentApplyId}")
    public DCResponse<List<TalentFamilyMemberApplyVO>> findTalentFamilyMemberApply(@PathVariable("talentApplyId") Long talentApplyId) {
        return DCResponse.success(talentFamilyMemberApplyService.findTalentFamilyMemberApplyList(talentApplyId));
    }

    /**
     * 保存家庭成员及主要社会关系
     *
     * @param param
     * @return
     */
    @ApiOperation(value = "保存家庭成员及主要社会关系", notes = "保存家庭成员及主要社会关系")
    @PostMapping("/save-talent-family-member-apply")
    public DCResponse<Boolean> saveTalentFamilyMemberApply(@RequestBody TalentFamilyMemberApplyParam param) {
//        Boolean flag = talentApplyService.checkHasUpdateData(param);
//        if (flag) {
//            return DCResponse.success(flag);
//        }
        param.setUserId(UserKit.getUserId());
        param.setIgnoreUpdateJson(false);
        param.setIgnoreCheckValid(false);
        param.setCommitFlag(true);
        return DCResponse.success(talentFamilyMemberApplyService.saveTalentFamilyMemberApply(param));
    }
}
