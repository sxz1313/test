package com.lxzh.talent.modular.controller;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.lxzh.talent.core.annotion.Permission;
import com.lxzh.talent.core.factory.PageFactory;
import com.lxzh.talent.core.pojo.page.PageResult;
import com.lxzh.talent.modular.entity.Company;
import com.lxzh.talent.modular.param.CompanyExamineParam;
import com.lxzh.talent.modular.param.CompanyParam;
import com.lxzh.talent.modular.response.DCResponse;
import com.lxzh.talent.modular.service.CompanyService;
import com.lxzh.talent.modular.vo.CompanyVO;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * @author: wsn
 */
@Api(tags = {"企业管理相关"})
@RestController
@RequestMapping("/v1/company")
public class CompanyController {

    @Autowired
    private CompanyService companyService;

    @GetMapping("/pageList")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "query", name = "pageSize", value = "页数", dataType = "Integer"),
            @ApiImplicitParam(paramType = "query", name = "pageNo", value = "页码", dataType = "Integer"),
            @ApiImplicitParam(paramType = "query", name = "name", value = "单位名称", dataType = "String"),
            @ApiImplicitParam(paramType = "query", name = "contactUser", value = "联系人", dataType = "String"),
            @ApiImplicitParam(paramType = "query", name = "qType", value = "查询类型 1-企业审核 2-企业台账", dataType = "Integer")
    })
    @ApiOperation("分页")
    public DCResponse<PageResult<CompanyVO>> pageList(@RequestParam(value = "name", required = false) String name,
                                                      @RequestParam(value = "contactUser", required = false) String contactUser,
                                                      @RequestParam("qType") Integer qType) {
        Page<Company> page = PageFactory.defaultPage();
        return DCResponse.success(companyService.pageList(page, name, contactUser, qType));
    }

    @ApiOperation("新增")
    @PostMapping("/save")
    @Permission
    public DCResponse<CompanyVO> save(@Validated @RequestBody CompanyParam param) {
        return DCResponse.success(companyService.saveOrUpdate(param));
    }

    @ApiOperation("编辑")
    @PostMapping("/update")
    @Permission
    public DCResponse<CompanyVO> update(@Validated @RequestBody CompanyParam param) {
        return DCResponse.success(companyService.saveOrUpdate(param));
    }

    @ApiOperation("详情")
    @GetMapping("/{id}")
    @Permission
    public DCResponse<CompanyVO> info(@PathVariable("id") Long id) {
        return DCResponse.success(companyService.info(id));
    }

    @ApiOperation("删除")
    @DeleteMapping("/del/{id}")
    @Permission
    public DCResponse del(@PathVariable("id") Long id) {
        return DCResponse.success(companyService.del(id));
    }

    @GetMapping("/queryByName")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "query", name = "name", value = "单位名称", dataType = "String")
    })
    @ApiOperation("根据公司名称搜索")
    public DCResponse<List<CompanyVO>> queryByName(@RequestParam(value = "name", required = false) String name) {
        return DCResponse.success(companyService.queryByName(name));
    }

    @ApiOperation("审核")
    @PostMapping("/examine")
    @Permission
    public DCResponse examine(@RequestBody CompanyExamineParam param) {
        companyService.examine(param);
        return DCResponse.success("操作成功");
    }

    @GetMapping("/queryByNameNoToken")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "query", name = "name", value = "单位名称", dataType = "String")
    })
    @ApiOperation("根据公司名称搜索不带token")
    public DCResponse<List<CompanyVO>> queryByNameNoToken(@RequestParam(value = "name", required = false) String name) {
        return DCResponse.success(companyService.queryByName(name));
    }

    @ApiOperation("新增不带token")
    @PostMapping("/saveNoToken")
    public DCResponse<CompanyVO> saveNoToken(@Validated @RequestBody CompanyParam param) {
        return DCResponse.success(companyService.saveOrUpdate(param));
    }

    @ApiOperation("根据企业id获取详情")
    @GetMapping("/info/{id}")
    public DCResponse<CompanyVO> getInfoById(@PathVariable("id") Long id) {
        return DCResponse.success(companyService.info(id));
    }
}
