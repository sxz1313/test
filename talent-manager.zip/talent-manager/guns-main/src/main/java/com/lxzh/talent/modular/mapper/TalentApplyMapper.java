package com.lxzh.talent.modular.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.lxzh.talent.modular.entity.TalentApply;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * <p>
 * 人才基本信息申请表 Mapper 接口
 * </p>
 *
 * @author wr
 * @since 2022-10-18
 */
public interface TalentApplyMapper extends BaseMapper<TalentApply> {

    List<Long> findFullSourceIdsById(@Param("id") Long id);
}
