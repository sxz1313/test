package com.lxzh.talent.modular.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import java.util.Date;
import java.time.LocalDate;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.TableLogic;
import com.baomidou.mybatisplus.annotation.TableField;
import java.io.Serializable;

import com.lxzh.talent.core.pojo.base.entity.BasicEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * <p>
 * 人才信息-参加学术团体情况表
 * </p>
 *
 * @author wr
 * @since 2022-10-18
 */
@Data
@EqualsAndHashCode(callSuper = false)
@TableName("talent_academy")
@ApiModel(value="TalentAcademy对象", description="人才信息-参加学术团体情况表")
public class TalentAcademy extends BasicEntity {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "id")
    @TableId("id")
    private Long id;

    @ApiModelProperty(value = "人才信息id")
    @TableField("talent_id")
    private Long talentId;

    @ApiModelProperty(value = "开始日期")
    @TableField("start_date")
    private LocalDate startDate;

    @ApiModelProperty(value = "终止日期")
    @TableField("end_date")
    private LocalDate endDate;

    @ApiModelProperty(value = "学术团体名称")
    @TableField("name")
    private String name;

    @ApiModelProperty(value = "学术团体层次")
    @TableField("academy_level")
    private String academyLevel;

    @ApiModelProperty(value = "担任职务")
    @TableField("position")
    private String position;

    @ApiModelProperty(value = "排序")
    @TableField("sort")
    private Integer sort;
}
