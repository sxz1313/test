package com.lxzh.talent.modular.controller;


import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.lxzh.talent.core.annotion.Permission;
import com.lxzh.talent.core.factory.PageFactory;
import com.lxzh.talent.core.pojo.page.PageResult;
import com.lxzh.talent.modular.entity.TalentApply;
import com.lxzh.talent.modular.enums.TalentApplyAuditStatusEnum;
import com.lxzh.talent.modular.param.TalentApplyAuditParam;
import com.lxzh.talent.modular.param.TalentApplyQueryParam;
import com.lxzh.talent.modular.response.DCResponse;
import com.lxzh.talent.modular.service.*;
import com.lxzh.talent.modular.utils.UserKit;
import com.lxzh.talent.modular.vo.*;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

/**
 * <p>
 * 管理后台-人才审核相关接口
 * </p>
 *
 * @author wr
 * @since 2022-10-18
 */
@Api(value = "/talent-apply-manage", tags = {"管理后台-人才审核相关接口"})
@RestController
@RequestMapping("/talent-apply-manage")
public class TalentApplyManageController {
    @Autowired
    private ITalentApplyService talentApplyService;
    @Autowired
    private ITalentDetailApplyService talentDetailApplyService;
    @Autowired
    private ITalentEducationApplyService talentEducationApplyService;
    @Autowired
    private ITalentProfessionalTechnicalApplyService talentProfessionalTechnicalApplyService;
    @Autowired
    private ITalentWorkExperienceApplyService talentWorkExperienceApplyService;
    @Autowired
    private ITalentPoliticalApplyService talentPoliticalApplyService;
    @Autowired
    private ITalentAnnualCheckApplyService talentAnnualCheckApplyService;
    @Autowired
    private ITalentHonorApplyService talentHonorApplyService;
    @Autowired
    private ITalentExpertApplyService talentExpertApplyService;
    @Autowired
    private ITalentPunishmentApplyService talentPunishmentApplyService;
    @Autowired
    private ITalentLanguageApplyService talentLanguageApplyService;
    @Autowired
    private ITalentTrainApplyService talentTrainApplyService;
    @Autowired
    private ITalentPublicationApplyService talentPublicationApplyService;
    @Autowired
    private ITalentAchievementApplyService talentAchievementApplyService;
    @Autowired
    private ITalentPatentApplyService talentPatentApplyService;
    @Autowired
    private ITalentAcademyApplyService talentAcademyApplyService;
    @Autowired
    private ITalentGraduateStudentApplyService talentGraduateStudentApplyService;
    @Autowired
    private ITalentFamilyMemberApplyService talentFamilyMemberApplyService;


    /**
     * 获取人才信息列表
     *
     * @param param
     * @return
     */
    @ApiOperation(value = "获取人才信息列表", notes = "获取人才信息列表")
    @PostMapping("/page")
    public DCResponse<PageResult<TalentApplyListVO>> findTalentApplyPage(@RequestBody TalentApplyQueryParam param) {
        Page<TalentApply> page = PageFactory.createPage(param);
        param.setManageQuery(true);
        param.setAuditStatus(TalentApplyAuditStatusEnum.WAIT_AUDIT.getValue());
        return DCResponse.success(talentApplyService.findTalentApplyPage(page, param));
    }

    /**
     * 获取人才信息
     *
     * @param id
     * @return
     */
    @ApiOperation(value = "获取人才信息", notes = "获取人才信息")
    @GetMapping("/find-talent-apply/{id}")
    public DCResponse<TalentApplyVO> findTalentApply(@PathVariable("id") Long id) {
        return DCResponse.success(talentApplyService.findTalentApplyById(id));
    }

    /**
     * 审核人才信息
     *
     * @param param
     * @return
     */
    @ApiOperation(value = "审核人才信息", notes = "审核人才信息")
    @PostMapping("/audit-talent-apply")
    @Permission
    public DCResponse<Boolean> auditTalentApply(@RequestBody @Valid TalentApplyAuditParam param) {
        param.setAuditUser(UserKit.getUserId());
        return DCResponse.success(talentApplyService.auditTalentApply(param));
    }

    /**
     * 获取人才单位信息
     *
     * @param talentApplyId
     * @return
     */
    @ApiOperation(value = "获取人才单位信息", notes = "获取人才单位信息")
    @PostMapping("/find-talent-company-apply/{talentApplyId}")
    public DCResponse<TalentCompanyApplyVO> findTalentCompanyApply(@PathVariable("talentApplyId") Long talentApplyId) {
        return DCResponse.success(talentApplyService.findTalentCompanyApply(talentApplyId));
    }

    /**
     * 获取人才基本信息
     *
     * @param talentApplyId
     * @return
     */
    @ApiOperation(value = "获取人才基本信息", notes = "获取人才基本信息")
    @PostMapping("/find-talent-detail-apply/{talentApplyId}")
    public DCResponse<TalentDetailApplyVO> findTalentDetailApply(@PathVariable("talentApplyId") Long talentApplyId) {
        return DCResponse.success(talentApplyService.findTalentDetailApply(talentApplyId));
    }

    /**
     * 获取学历及学位
     *
     * @param talentApplyId
     * @return
     */
    @ApiOperation(value = "获取学历及学位", notes = "获取学历及学位")
    @PostMapping("/find-talent-education-apply/{talentApplyId}")
    public DCResponse<List<TalentEducationApplyVO>> findTalentEducationApply(@PathVariable("talentApplyId") Long talentApplyId) {
        return DCResponse.success(talentEducationApplyService.findTalentEducationApplyList(talentApplyId));
    }

    /**
     * 获取专业技术职称、职（执）业资格情况
     *
     * @param talentApplyId
     * @return
     */
    @ApiOperation(value = "获取专业技术职称、职（执）业资格情况", notes = "获取专业技术职称、职（执）业资格情况")
    @PostMapping("/find-talent-professional-technical-apply/{talentApplyId}")
    public DCResponse<List<TalentProfessionalTechnicalApplyVO>> findTalentProfessionalTechnicalApply(@PathVariable("talentApplyId") Long talentApplyId) {
        return DCResponse.success(talentProfessionalTechnicalApplyService.findTalentProfessionalTechnicalApplyList(talentApplyId));
    }

    /**
     * 获取个人工作经历
     *
     * @param talentApplyId
     * @return
     */
    @ApiOperation(value = "获取个人工作经历", notes = "获取个人工作经历")
    @PostMapping("/find-talent-work-experience-apply/{talentApplyId}")
    public DCResponse<List<TalentWorkExperienceApplyVO>> findTalentWorkExperienceApply(@PathVariable("talentApplyId") Long talentApplyId) {
        return DCResponse.success(talentWorkExperienceApplyService.findTalentWorkExperienceApplyList(talentApplyId));
    }

    /**
     * 获取政治面貌（党派）情况
     *
     * @param talentApplyId
     * @return
     */
    @ApiOperation(value = "获取政治面貌（党派）情况", notes = "获取政治面貌（党派）情况")
    @PostMapping("/find-talent-political-apply/{talentApplyId}")
    public DCResponse<List<TalentPoliticalApplyVO>> findTalentPoliticalApply(@PathVariable("talentApplyId") Long talentApplyId) {
        return DCResponse.success(talentPoliticalApplyService.findTalentPoliticalApplyList(talentApplyId));
    }

    /**
     * 获取年度考核情况
     *
     * @param talentApplyId
     * @return
     */
    @ApiOperation(value = "获取年度考核情况", notes = "获取年度考核情况")
    @PostMapping("/find-talent-annual-check-apply/{talentApplyId}")
    public DCResponse<List<TalentAnnualCheckApplyVO>> findTalentAnnualCheckApply(@PathVariable("talentApplyId") Long talentApplyId) {
        return DCResponse.success(talentAnnualCheckApplyService.findTalentAnnualCheckApplyList(talentApplyId));
    }

    /**
     * 获取荣誉称号（奖励）情况
     *
     * @param talentApplyId
     * @return
     */
    @ApiOperation(value = "获取荣誉称号（奖励）情况", notes = "获取荣誉称号（奖励）情况")
    @PostMapping("/find-talent-honor-apply/{talentApplyId}")
    public DCResponse<List<TalentHonorApplyVO>> findTalentHonorApply(@PathVariable("talentApplyId") Long talentApplyId) {
        return DCResponse.success(talentHonorApplyService.findTalentHonorApplyList(talentApplyId));
    }

    /**
     * 获取荣获专家称号情况
     *
     * @param talentApplyId
     * @return
     */
    @ApiOperation(value = "获取荣获专家称号情况", notes = "获取荣获专家称号情况")
    @PostMapping("/find-talent-expert-apply/{talentApplyId}")
    public DCResponse<List<TalentExpertApplyVO>> findTalentExpertApply(@PathVariable("talentApplyId") Long talentApplyId) {
        return DCResponse.success(talentExpertApplyService.findTalentExpertApplyList(talentApplyId));
    }

    /**
     * 获取惩戒(处分)情况
     *
     * @param talentApplyId
     * @return
     */
    @ApiOperation(value = "获取惩戒(处分)情况", notes = "获取惩戒(处分)情况")
    @PostMapping("/find-talent-punishment-apply/{talentApplyId}")
    public DCResponse<List<TalentPunishmentApplyVO>> findTalentPunishmentApply(@PathVariable("talentApplyId") Long talentApplyId) {
        return DCResponse.success(talentPunishmentApplyService.findTalentPunishmentApplyList(talentApplyId));
    }

    /**
     * 获取语言能力
     *
     * @param talentApplyId
     * @return
     */
    @ApiOperation(value = "获取语言能力", notes = "获取语言能力")
    @PostMapping("/find-talent-language-apply/{talentApplyId}")
    public DCResponse<List<TalentLanguageApplyVO>> findTalentLanguageApply(@PathVariable("talentApplyId") Long talentApplyId) {
        return DCResponse.success(talentLanguageApplyService.findTalentLanguageApplyList(talentApplyId));
    }

    /**
     * 获取培训教育情况
     *
     * @param talentApplyId
     * @return
     */
    @ApiOperation(value = "获取培训教育情况", notes = "获取培训教育情况")
    @PostMapping("/find-talent-train-apply/{talentApplyId}")
    public DCResponse<List<TalentTrainApplyVO>> findTalentTrainApply(@PathVariable("talentApplyId") Long talentApplyId) {
        return DCResponse.success(talentTrainApplyService.findTalentTrainApplyList(talentApplyId));
    }

    /**
     * 获取主要论文及著作情况
     *
     * @param talentApplyId
     * @return
     */
    @ApiOperation(value = "获取主要论文及著作情况", notes = "获取主要论文及著作情况")
    @PostMapping("/find-talent-publication-apply/{talentApplyId}")
    public DCResponse<List<TalentPublicationApplyVO>> findTalentPublicationApply(@PathVariable("talentApplyId") Long talentApplyId) {
        return DCResponse.success(talentPublicationApplyService.findTalentPublicationApplyList(talentApplyId));
    }

    /**
     * 获取科研成果情况
     *
     * @param talentApplyId
     * @return
     */
    @ApiOperation(value = "获取科研成果情况", notes = "获取科研成果情况")
    @PostMapping("/find-talent-achievement-apply/{talentApplyId}")
    public DCResponse<List<TalentAchievementApplyVO>> findTalentAchievementApply(@PathVariable("talentApplyId") Long talentApplyId) {
        return DCResponse.success(talentAchievementApplyService.findTalentAchievementApplyList(talentApplyId));
    }

    /**
     * 获取专利情况
     *
     * @param talentApplyId
     * @return
     */
    @ApiOperation(value = "获取专利情况", notes = "获取专利情况")
    @PostMapping("/find-talent-patent-apply/{talentApplyId}")
    public DCResponse<List<TalentPatentApplyVO>> findTalentPatentApply(@PathVariable("talentApplyId") Long talentApplyId) {
        return DCResponse.success(talentPatentApplyService.findTalentPatentApplyList(talentApplyId));
    }

    /**
     * 获取参加学术团体情况
     *
     * @param talentApplyId
     * @return
     */
    @ApiOperation(value = "获取参加学术团体情况", notes = "获取参加学术团体情况")
    @PostMapping("/find-talent-academy-apply/{talentApplyId}")
    public DCResponse<List<TalentAcademyApplyVO>> findTalentAcademyApply(@PathVariable("talentApplyId") Long talentApplyId) {
        return DCResponse.success(talentAcademyApplyService.findTalentAcademyApplyList(talentApplyId));
    }

    /**
     * 获取培养研究生情况
     *
     * @param talentApplyId
     * @return
     */
    @ApiOperation(value = "获取培养研究生情况", notes = "获取培养研究生情况")
    @PostMapping("/find-talent-graduate-student-apply/{talentApplyId}")
    public DCResponse<List<TalentGraduateStudentApplyVO>> findTalentGraduateStudentApply(@PathVariable("talentApplyId") Long talentApplyId) {
        return DCResponse.success(talentGraduateStudentApplyService.findTalentGraduateStudentApplyList(talentApplyId));
    }

    /**
     * 获取家庭成员及主要社会关系
     *
     * @param talentApplyId
     * @return
     */
    @ApiOperation(value = "获取家庭成员及主要社会关系", notes = "获取家庭成员及主要社会关系")
    @PostMapping("/find-talent-family-member-apply/{talentApplyId}")
    public DCResponse<List<TalentFamilyMemberApplyVO>> findTalentFamilyMemberApply(@PathVariable("talentApplyId") Long talentApplyId) {
        return DCResponse.success(talentFamilyMemberApplyService.findTalentFamilyMemberApplyList(talentApplyId));
    }
}
