package com.lxzh.talent.modular.enums;

import lombok.Getter;

import java.util.Arrays;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;


/**
 * <p>
 *
 * </p>
 *
 * @author baiwandong
 * @since 2021-12-30
 */
@Getter
public enum TimeUtilsEnum {

    TimeUtils1(1, "今天"),
    TimeUtils2(2, "昨天"),
    TimeUtils3(3, "本周"),
    TimeUtils4(4, "本月"),
    TimeUtils5(5, "半年内"),
    TimeUtils6(6, "上个月");

    private final Integer code;

    private final String message;

    TimeUtilsEnum(Integer code, String message) {
        this.code = code;
        this.message = message;
    }

    public static TimeUtilsEnum getEnumByCode(Integer code) {
        if (Objects.nonNull(code)) {
            for (TimeUtilsEnum value : values()) {
                if (value.getCode().equals(code)) {
                    return value;
                }
            }
        }
        return null;
    }

    public static Map<Integer, String> getEnumMap() {
        Map<Integer, String> map = Arrays.stream(values()).collect(Collectors.toMap(TimeUtilsEnum::getCode, TimeUtilsEnum::getMessage));
        return map;
    }

    public static TimeUtilsEnum getEnumByMsg(String msg) {
        for (TimeUtilsEnum value : values()) {
            if (value.getMessage().equals(msg)) {
                return value;
            }
        }
        return null;
    }
}
