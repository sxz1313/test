package com.lxzh.talent.modular.mapper;

import com.lxzh.talent.modular.entity.TalentDetailApply;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 人才详细信息申请表 Mapper 接口
 * </p>
 *
 * @author wr
 * @since 2022-10-18
 */
public interface TalentDetailApplyMapper extends BaseMapper<TalentDetailApply> {

}
