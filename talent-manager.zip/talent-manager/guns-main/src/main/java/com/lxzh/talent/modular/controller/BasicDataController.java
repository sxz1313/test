package com.lxzh.talent.modular.controller;

import com.lxzh.talent.modular.entity.BasicData;
import com.lxzh.talent.modular.response.DCResponse;
import com.lxzh.talent.modular.service.BasicDataService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * @author: wsn
 */
@Api(tags = {"基础数据相关"})
@RestController
@RequestMapping("/v1/basic-data")
public class BasicDataController {
    @Autowired
    private BasicDataService basicDataService;

    @GetMapping("/queryByType")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "query", name = "type", value = "类型", dataType = "String"),
            @ApiImplicitParam(paramType = "query", name = "id", value = "id", dataType = "Long")
    })
    @ApiOperation("根据类型搜索")
    public DCResponse<List<BasicData>> queryByType(@RequestParam(value = "type", required = false) String type,
                                                   @RequestParam(value = "id", required = false) Long id) {
        return DCResponse.success(basicDataService.queryByType(type, id));
    }
}
