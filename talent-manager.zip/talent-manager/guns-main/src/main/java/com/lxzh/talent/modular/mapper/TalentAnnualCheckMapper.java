package com.lxzh.talent.modular.mapper;

import com.lxzh.talent.modular.entity.TalentAnnualCheck;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 人才信息-年度考核情况(填写近五年情况)表 Mapper 接口
 * </p>
 *
 * @author wr
 * @since 2022-10-18
 */
public interface TalentAnnualCheckMapper extends BaseMapper<TalentAnnualCheck> {

}
