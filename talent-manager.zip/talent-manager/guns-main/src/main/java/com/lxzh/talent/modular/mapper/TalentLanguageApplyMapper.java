package com.lxzh.talent.modular.mapper;

import com.lxzh.talent.modular.entity.TalentLanguageApply;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 人才信息-语言能力申请表 Mapper 接口
 * </p>
 *
 * @author wr
 * @since 2022-10-18
 */
public interface TalentLanguageApplyMapper extends BaseMapper<TalentLanguageApply> {

}
