package com.lxzh.talent.modular.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.lxzh.talent.modular.entity.CourseTeacher;

/**
 * 课程教师信息表 Mapper 接口
 *
 * @author wsn
 * @date 2022/09/28 11:28
 */
public interface CourseTeacherMapper extends BaseMapper<CourseTeacher> {
}