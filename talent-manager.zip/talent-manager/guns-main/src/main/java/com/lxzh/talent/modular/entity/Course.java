package com.lxzh.talent.modular.entity;

import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.lxzh.talent.core.pojo.base.entity.BasicEntity;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.math.BigDecimal;
import java.util.Date;

/**
 * 课程信息表
 *
 * @author wsn
 * @date 2022/09/28 11:28
 */
@Data
@EqualsAndHashCode(callSuper = true)
@TableName("cr_course")
public class Course extends BasicEntity {

    /**
     * 主键
     */
    @TableId("id")
    private Long id;

    /**
     * 课程名称
     */
    @TableField("name")
    private String name;

    /**
     * 开课开始时间
     */
    @TableField("start_time")
    private Date startTime;

    /**
     * 开课结束时间
     */
    @TableField("end_time")
    private Date endTime;

    /**
     * 价格
     */
    @TableField("price")
    private BigDecimal price;

    /**
     * 排序号
     */
    @TableField("sort")
    private Integer sort;

    /**
     * 图片文件id
     */
    @TableField("img_file_id")
    private Long imgFileId;

    /**
     * 课程介绍
     */
    @TableField("introduce")
    private String introduce;

    /**
     * 课程简介
     */
    @TableField("introduction")
    private String introduction;

    /**
     * 授课老师
     */
    @TableField(value = "teacher_names", fill = FieldFill.UPDATE)
    private String teacherNames;

    /**
     * 发布时间
     */
    @TableField("push_time")
    private Date pushTime;

    /**
     * 发布人
     */
    @TableField("push_user")
    private Long pushUser;
}
