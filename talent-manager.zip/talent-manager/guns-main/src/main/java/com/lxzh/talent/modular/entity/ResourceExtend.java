package com.lxzh.talent.modular.entity;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.List;


/**
 * Resource生成数据实体类
 *
 * @author wr
 * @since 2022-01-17
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class ResourceExtend implements Serializable {

    private Long id;

    /**
     * 名称
     */
    private String name;

    /**
     * 编码
     */
    private String code;

    /**
     * 菜单类型（字典 0目录 1菜单 2按钮）
     */
    private Integer type;

    /**
     * 打开方式（字典 0无 1组件 2内链 3外链）
     */
    private Integer openType;

    private Integer sort;

    private List<String> opreateList;

    private List<ResourceExtend> children;

    public ResourceExtend(String name) {
        this.name = name;
    }

    public ResourceExtend(String name, Integer type, Integer openType, Integer sort) {
        this.name = name;
        this.code = name;
        this.type = type;
        this.openType = openType;
        this.sort = sort;
    }
}
