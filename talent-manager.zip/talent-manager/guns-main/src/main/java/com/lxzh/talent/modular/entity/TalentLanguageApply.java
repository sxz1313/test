package com.lxzh.talent.modular.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import java.util.Date;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.TableLogic;
import com.baomidou.mybatisplus.annotation.TableField;
import java.io.Serializable;

import com.lxzh.talent.core.pojo.base.entity.BasicEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * <p>
 * 人才信息-语言能力申请表
 * </p>
 *
 * @author wr
 * @since 2022-10-18
 */
@Data
@EqualsAndHashCode(callSuper = false)
@TableName("talent_language_apply")
@ApiModel(value="TalentLanguageApply对象", description="人才信息-语言能力申请表")
public class TalentLanguageApply extends BasicEntity {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "id")
    @TableId("id")
    private Long id;

    @ApiModelProperty(value = "人才信息申请id")
    @TableField("talent_apply_id")
    private Long talentApplyId;

    @ApiModelProperty(value = "语种")
    @TableField("language")
    private String language;

    @ApiModelProperty(value = "掌握语种水平的级别")
    @TableField("language_level")
    private String languageLevel;

    @ApiModelProperty(value = "口语熟练程度")
    @TableField("speak_proficiency")
    private String speakProficiency;

    @ApiModelProperty(value = "排序")
    @TableField("sort")
    private Integer sort;
}
