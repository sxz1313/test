package com.lxzh.talent.modular.enums;

/**
 * <p>
 * 人才基本信息-来源类型枚举类
 * </p>
 *
 * @author wr
 * @since 2022-10-18
 */
public enum TalentApplySourceTypeEnum {

    PERSON(1,"个人"),
    COMPANY(2,"企业"),
    OTHER_COPY(3,"从其他数据源复制过来的"),
    DRAFT(4,"待审核草稿")
    ;

    private Integer value;
    private String desc;

    TalentApplySourceTypeEnum(Integer value, String desc) {
        this.value = value;
        this.desc = desc;
    }

    public Integer getValue() {
        return this.value;
    }

    public String getDesc() {
        return desc;
    }

    @Override
    public String toString() {
        return this.desc;
    }
}
