package com.lxzh.talent.modular.enums;

import com.lxzh.talent.core.exception.enums.abs.AbstractBaseExceptionEnum;

/**
 * <p>
 * 订单状态枚举类
 * </p>
 *
 * @author wr
 * @since 2022-09-28
 */
public enum OaOrderExceptionEnum implements AbstractBaseExceptionEnum {


    COURSE_NOT_EXIST_EXCEPTION(1000, "课程不存在"),
    USER_NOT_EXIST_EXCEPTION(1000, "用户不存在"),
    ORDER_NOT_EXIST_EXCEPTION(1000, "订单不存在"),
    ORDER_INVOICE_NOT_PAY_EXCEPTION(1000, "没有收到收据"),
    ORDER_DATA_NOF_FOUND(1001, "没有找到报名数据"),
    ORDER_TYPE_NOT_FOUND_EXCEPTION(1000, "暂不支持此类型的订单下单"),

    ;

    OaOrderExceptionEnum(int code, String message) {
        this.code = code;
        this.message = message;
    }

    private Integer code;

    private String message;

    @Override
    public Integer getCode() {
        return code;
    }

    @Override
    public String getMessage() {
        return message;
    }
}
