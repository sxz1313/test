package com.lxzh.talent.modular.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import java.util.Date;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.TableLogic;
import com.baomidou.mybatisplus.annotation.TableField;
import java.io.Serializable;

import com.lxzh.talent.core.pojo.base.entity.BasicEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * <p>
 * 人才基本信息表
 * </p>
 *
 * @author wr
 * @since 2022-10-18
 */
@Data
@EqualsAndHashCode(callSuper = false)
@TableName("talent")
@ApiModel(value="Talent对象", description="人才基本信息表")
public class Talent extends BasicEntity {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "id")
    @TableId("id")
    private Long id;

    @ApiModelProperty(value = "用户id")
    @TableField("user_id")
    private Long userId;

    @ApiModelProperty(value = "姓名")
    @TableField("name")
    private String name;

    @ApiModelProperty(value = "单位id")
    @TableField("company_id")
    private Long companyId;

    @ApiModelProperty(value = "性别")
    @TableField("sex")
    private String sex;

    @ApiModelProperty(value = "照片")
    @TableField("picture")
    private String picture;

    @ApiModelProperty(value = "身份证号")
    @TableField("id_number")
    private String idNumber;

    @ApiModelProperty(value = "移动电话")
    @TableField("mobile")
    private String mobile;

    @ApiModelProperty(value = "电子信箱")
    @TableField("email")
    private String email;

    @ApiModelProperty(value = "学历层次")
    @TableField("education_level")
    private String educationLevel;

    @ApiModelProperty(value = "人才详细信息json")
    @TableField("talent_json")
    private String talentJson;

    @ApiModelProperty(value = "来源类型（0-个人 1-企业）")
    @TableField("source_type")
    private Integer sourceType;

    @ApiModelProperty(value = "来源id")
    @TableField("source_id")
    private Long sourceId;

    @ApiModelProperty(value = "状态（字典 0-正常 1-已退会）")
    @TableField("status")
    private Integer status;
}
