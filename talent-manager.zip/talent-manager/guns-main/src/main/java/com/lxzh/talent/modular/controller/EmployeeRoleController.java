package com.lxzh.talent.modular.controller;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.lxzh.talent.core.annotion.Permission;
import com.lxzh.talent.core.factory.PageFactory;
import com.lxzh.talent.core.pojo.page.PageResult;
import com.lxzh.talent.modular.response.DCResponse;
import com.lxzh.talent.modular.service.EmployeeService;
import com.lxzh.talent.modular.utils.UserKit;
import com.lxzh.talent.modular.vo.EmployeeVO;
import com.lxzh.talent.sys.modular.auth.service.AuthService;
import com.lxzh.talent.sys.modular.role.entity.SysRole;
import com.lxzh.talent.sys.modular.role.service.SysRoleService;
import com.lxzh.talent.sys.modular.user.entity.SysUser;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.List;

/**
 * @author wsn
 */
@Api(tags = {"员工与角色"})
@RestController
@RequestMapping("/v1/employee-role")
public class EmployeeRoleController {

    @Autowired
    private EmployeeService employeeService;
    @Autowired
    private SysRoleService sysRoleService;
    @Resource
    private AuthService authService;

    @ApiOperation(value = "获取用户列表", notes = "获取用户列表")
    @GetMapping("/employeePage")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "pageSize", value = "页数", dataType = "Integer"),
            @ApiImplicitParam(name = "pageNo", value = "页码", dataType = "Integer"),
            @ApiImplicitParam(paramType = "员工姓名", name = "name", value = "员工姓名", dataType = "String"),
            @ApiImplicitParam(paramType = "手机号", name = "phone", value = "手机号", dataType = "String")
    })
    public DCResponse<PageResult<EmployeeVO>> employeePage(@RequestParam(value = "name") String name, @RequestParam(value = "phone") String phone) {
        Page<SysUser> page = PageFactory.defaultPage();
        return DCResponse.success(employeeService.employeePage(page, name, phone));
    }

    /**
     * 新增员工
     *
     * @return
     */
    @PostMapping("/addEmployee")
    @ApiOperation(value = "新增员工", notes = "新增员工")
    @Permission
    public DCResponse addEmployee(@RequestBody EmployeeVO employeeVO) {
        employeeService.addEmployee(employeeVO);
        return DCResponse.success("操作成功!");
    }

    /**
     * 编辑员工
     *
     * @return
     */
    @PostMapping("/editEmployee")
    @ApiOperation(value = "编辑员工", notes = "编辑员工")
    @Permission
    public DCResponse editEmployee(@RequestBody EmployeeVO employeeVO) {
        employeeService.editEmployee(employeeVO);
        return DCResponse.success("操作成功!");
    }

    /**
     * 启用/停用员工账号
     *
     * @param id
     * @return
     */
    @ApiOperation(value = "启用/停用员工账号", notes = "启用/停用员工账号")
    @GetMapping("/startOrStopUse")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "员工id", name = "id", value = "员工id", dataType = "Long"),
            @ApiImplicitParam(paramType = "status(状态0-正常,1-停用)", name = "status", value = "status(状态0-正常,1-停用)", dataType = "Integer")
    })
    @Permission
    public DCResponse startOrStopUse(@RequestParam(value = "id") Long id, @RequestParam(value = "status") Integer status) {
        employeeService.startOrStopUse(id, status);
        return DCResponse.success("操作成功");
    }

//    @Permission
    @ApiOperation(value = "员工明细")
    @ResponseBody
    @GetMapping("/info/{id}")
    public DCResponse<EmployeeVO> info(@PathVariable("id") Long id) {
        return DCResponse.success(employeeService.showInfoVO(id));
    }

    /**
     * 删除用户
     *
     * @param id
     * @return
     */
    @ApiOperation(value = "删除用户", notes = "删除用户")
    @DeleteMapping("/deleteOne/{id}")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "员工id", name = "id", value = "员工id", dataType = "Long")
    })
    @Permission
    public DCResponse deleteOne(@PathVariable("id") Long id) {
        employeeService.deleteEmployee(id);
        return DCResponse.success("操作成功");
    }

    @ApiOperation(value = "获取角色列表", notes = "获取角色列表")
    @GetMapping("/getRoleList")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "角色名称", name = "name", value = "角色名称", dataType = "String")
    })
    public DCResponse<List<SysRole>> getRoleList(@RequestParam(value = "name") String name) {
        return DCResponse.success(sysRoleService.getRoleList(name));
    }

    /**
     * 重置密码
     *
     * @param id
     * @return
     */
    @ApiOperation(value = "重置密码", notes = "重置密码")
    @GetMapping("/resetPassword")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "员工id", name = "id", value = "员工id", dataType = "Long")
    })
    @Permission
    public DCResponse resetPassword(@RequestParam(value = "id") Long id) {
        employeeService.resetPassword(id);
        return DCResponse.success("操作成功");
    }

    /**
     *修改密码
     * @return
     */
    @ApiOperation(value = "修改密码", notes = "修改密码")
    @GetMapping("/modifyPassword")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "旧密码",name = "oldPassword", value = "旧密码", dataType = "Long"),
            @ApiImplicitParam(paramType = "新密码",name = "newPassword", value = "新密码", dataType = "String")
    })
    public DCResponse modifyPassword(@RequestParam(value = "oldPassword") String oldPassword,@RequestParam(value = "newPassword") String newPassword){
        Long userId = UserKit.getLoginUser().getId();
        if(authService.modifyPassword(oldPassword,newPassword,userId)){
            return DCResponse.success("操作成功");
        }
        return DCResponse.error(500,"操作失败！");
    }
}
