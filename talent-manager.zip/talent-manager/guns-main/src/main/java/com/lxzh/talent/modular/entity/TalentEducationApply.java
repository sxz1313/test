package com.lxzh.talent.modular.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import java.util.Date;
import java.time.LocalDate;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.TableLogic;
import com.baomidou.mybatisplus.annotation.TableField;
import java.io.Serializable;

import com.lxzh.talent.core.pojo.base.entity.BasicEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * <p>
 * 人才信息-学历及学位申请表
 * </p>
 *
 * @author wr
 * @since 2022-10-18
 */
@Data
@EqualsAndHashCode(callSuper = false)
@TableName("talent_education_apply")
@ApiModel(value="TalentEducationApply对象", description="人才信息-学历及学位申请表")
public class TalentEducationApply extends BasicEntity {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "id")
    @TableId("id")
    private Long id;

    @ApiModelProperty(value = "人才信息申请id")
    @TableField("talent_apply_id")
    private Long talentApplyId;

    @ApiModelProperty(value = "开始日期")
    @TableField("start_date")
    private String startDate;

    @ApiModelProperty(value = "终止日期")
    @TableField("end_date")
    private String endDate;

    @ApiModelProperty(value = "学校名称")
    @TableField("school_name")
    private String schoolName;

    @ApiModelProperty(value = "所学专业")
    @TableField("major")
    private String major;

    @ApiModelProperty(value = "学历层次")
    @TableField("education_level")
    private String educationLevel;

    @ApiModelProperty(value = "学历证书编号")
    @TableField("education_certificate_no")
    private String educationCertificateNo;

    @ApiModelProperty(value = "学位")
    @TableField("degree")
    private String degree;

    @ApiModelProperty(value = "学位证书编号")
    @TableField("degree_certificate_no")
    private String degreeCertificateNo;

    @ApiModelProperty(value = "排序")
    @TableField("sort")
    private Integer sort;
}
