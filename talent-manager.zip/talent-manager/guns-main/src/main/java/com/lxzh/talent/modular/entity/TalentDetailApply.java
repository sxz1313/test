package com.lxzh.talent.modular.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import java.util.Date;
import java.time.LocalDate;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.TableLogic;
import com.baomidou.mybatisplus.annotation.TableField;
import java.io.Serializable;

import com.lxzh.talent.core.pojo.base.entity.BasicEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * <p>
 * 人才详细信息申请表
 * </p>
 *
 * @author wr
 * @since 2022-10-18
 */
@Data
@EqualsAndHashCode(callSuper = false)
@TableName("talent_detail_apply")
@ApiModel(value="TalentDetailApply对象", description="人才详细信息申请表")
public class TalentDetailApply extends BasicEntity {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "id")
    @TableId("id")
    private Long id;

    @ApiModelProperty(value = "人才信息申请id")
    @TableField("talent_apply_id")
    private Long talentApplyId;

    @ApiModelProperty(value = "民族")
    @TableField("nation")
    private String nation;

    @ApiModelProperty(value = "出生日期")
    @TableField("birthday")
    private String birthday;

    @ApiModelProperty(value = "出生地")
    @TableField("birth_place")
    private String birthPlace;

    @ApiModelProperty(value = "曾用名")
    @TableField("used_name")
    private String usedName;

    @ApiModelProperty(value = "外文姓名")
    @TableField("foreign_name")
    private String foreignName;

    @ApiModelProperty(value = "国籍")
    @TableField("nationality")
    private String nationality;

    @ApiModelProperty(value = "籍贯-省code")
    @TableField("native_place_province_code")
    private String nativePlaceProvinceCode;

    @ApiModelProperty(value = "籍贯-市code")
    @TableField("native_place_city_code")
    private String nativePlaceCityCode;

    @ApiModelProperty(value = "籍贯-区code")
    @TableField("native_place_area_code")
    private String nativePlaceAreaCode;

    @ApiModelProperty(value = "户籍所在地-省code")
    @TableField("domicile_place_province_code")
    private String domicilePlaceProvinceCode;

    @ApiModelProperty(value = "户籍所在地-市code")
    @TableField("domicile_place_city_code")
    private String domicilePlaceCityCode;

    @ApiModelProperty(value = "户籍所在地-区code")
    @TableField("domicile_place_area_code")
    private String domicilePlaceAreaCode;

    @ApiModelProperty(value = "健康状况")
    @TableField("health_condition")
    private String healthCondition;

    @ApiModelProperty(value = "婚姻状况")
    @TableField("marriage_status")
    private String marriageStatus;

    @ApiModelProperty(value = "职业")
    @TableField("job")
    private String job;

    @ApiModelProperty(value = "职位")
    @TableField("position")
    private String position;

    @ApiModelProperty(value = "职位级别")
    @TableField("position_level")
    private String positionLevel;

    @ApiModelProperty(value = "执业资格")
    @TableField("mipa")
    private String mipa;

    @ApiModelProperty(value = "专业技术职务")
    @TableField("professional_technical_post")
    private String professionalTechnicalPost;

    @ApiModelProperty(value = "专业技术岗位")
    @TableField("professional_position")
    private String professionalPosition;

    @ApiModelProperty(value = "专业类别")
    @TableField("professional_category")
    private String professionalCategory;

    @ApiModelProperty(value = "个人专业特长")
    @TableField("personal_major")
    private String personalMajor;

    @ApiModelProperty(value = "个人爱好")
    @TableField("personal_preference")
    private String personalPreference;

    @ApiModelProperty(value = "其他有效身份证件（军官证、护照）")
    @TableField("other_identification")
    private String otherIdentification;

    @ApiModelProperty(value = "证件号码")
    @TableField("identification_number")
    private String identificationNumber;

    @ApiModelProperty(value = "用工形式")
    @TableField("employment_form")
    private String employmentForm;

    @ApiModelProperty(value = "联系地址-省code")
    @TableField("contact_province_code")
    private String contactProvinceCode;

    @ApiModelProperty(value = "联系地址-市code")
    @TableField("contact_city_code")
    private String contactCityCode;

    @ApiModelProperty(value = "联系地址-区code")
    @TableField("contact_area_code")
    private String contactAreaCode;

    @ApiModelProperty(value = "联系地址")
    @TableField("contact_address")
    private String contactAddress;

    @ApiModelProperty(value = "邮政编码")
    @TableField("postal_code")
    private String postalCode;

    @ApiModelProperty(value = "固定电话")
    @TableField("telephone")
    private String telephone;

    @ApiModelProperty(value = "电子简历文件")
    @TableField("resume_file")
    private Long resumeFile;

    @ApiModelProperty(value = "人才属性")
    @TableField("talent_property")
    private String talentProperty;

    @ApiModelProperty(value = "名校优生")
    @TableField("elite_student")
    private String eliteStudent;
}
