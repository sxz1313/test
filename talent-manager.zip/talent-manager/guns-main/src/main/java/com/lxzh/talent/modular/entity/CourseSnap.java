package com.lxzh.talent.modular.entity;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.lxzh.talent.core.pojo.base.entity.BasicEntity;
import lombok.*;
import lombok.experimental.Accessors;

/**
 * 课程快照信息
 *
 * @author wsn
 * @date 2022/09/28 11:28
 */
@Data
@EqualsAndHashCode(callSuper = true)
@TableName("cr_course_snap")
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Accessors(chain = true)
public class CourseSnap extends BasicEntity {

    /**
     * 主键id
     */
    @TableId("id")
    private Long id;

    /**
     * 订单编号
     */
    @TableField("order_no")
    private String orderNo;

    /**
     * 课程id
     */
    @TableField("course_id")
    private Long courseId;

    /**
     * 课程数量
     */
    @TableField("course_num")
    private Integer courseNum;

    /**
     * 快照信息
     */
    @TableField("snap")
    private String snap;
}
