package com.lxzh.talent.modular.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.lxzh.talent.modular.entity.Customer;

/**
 * 客户信息表 Mapper 接口
 *
 * @author wsn
 * @date 2022/10/17 09:29
 */
public interface CustomerMapper extends BaseMapper<Customer> {
}