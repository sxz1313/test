package com.lxzh.talent.modular.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import java.util.Date;
import java.time.LocalDate;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.TableLogic;
import com.baomidou.mybatisplus.annotation.TableField;
import java.io.Serializable;

import com.lxzh.talent.core.pojo.base.entity.BasicEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * <p>
 * 人才信息-政治面貌（党派）情况申请表
 * </p>
 *
 * @author wr
 * @since 2022-10-18
 */
@Data
@EqualsAndHashCode(callSuper = false)
@TableName("talent_political_apply")
@ApiModel(value="TalentPoliticalApply对象", description="人才信息-政治面貌（党派）情况申请表")
public class TalentPoliticalApply extends BasicEntity {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "id")
    @TableId("id")
    private Long id;

    @ApiModelProperty(value = "人才信息申请id")
    @TableField("talent_apply_id")
    private Long talentApplyId;

    @ApiModelProperty(value = "政治面貌(党派)")
    @TableField("name")
    private String name;

    @ApiModelProperty(value = "参加组织日期")
    @TableField("join_date")
    private LocalDate joinDate;

    @ApiModelProperty(value = "介绍人")
    @TableField("introducer")
    private String introducer;

    @ApiModelProperty(value = "转正日期")
    @TableField("positive_date")
    private LocalDate positiveDate;

    @ApiModelProperty(value = "退出(除名）时间")
    @TableField("exit_date")
    private LocalDate exitDate;

    @ApiModelProperty(value = "退出(除名）原因")
    @TableField("exit_reason")
    private String exitReason;

    @ApiModelProperty(value = "排序")
    @TableField("sort")
    private Integer sort;
}
