package com.lxzh.talent.modular.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import java.util.Date;
import java.time.LocalDate;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.TableLogic;
import com.baomidou.mybatisplus.annotation.TableField;
import java.io.Serializable;

import com.lxzh.talent.core.pojo.base.entity.BasicEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * <p>
 * 人才信息-惩戒(处分)情况表
 * </p>
 *
 * @author wr
 * @since 2022-10-18
 */
@Data
@EqualsAndHashCode(callSuper = false)
@TableName("talent_punishment")
@ApiModel(value="TalentPunishment对象", description="人才信息-惩戒(处分)情况表")
public class TalentPunishment extends BasicEntity {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "id")
    @TableId("id")
    private Long id;

    @ApiModelProperty(value = "人才信息id")
    @TableField("talent_id")
    private Long talentId;

    @ApiModelProperty(value = "惩戒(处分)批准日期")
    @TableField("approval_date")
    private LocalDate approvalDate;

    @ApiModelProperty(value = "惩戒(处分)批准机关名称")
    @TableField("agency_name")
    private String agencyName;

    @ApiModelProperty(value = "惩戒(处分)名称")
    @TableField("name")
    private String name;

    @ApiModelProperty(value = "惩戒(处分)原因")
    @TableField("reason")
    private String reason;

    @ApiModelProperty(value = "惩戒(处分)撤消日期")
    @TableField("cancel_date")
    private LocalDate cancelDate;

    @ApiModelProperty(value = "排序")
    @TableField("sort")
    private Integer sort;
}
