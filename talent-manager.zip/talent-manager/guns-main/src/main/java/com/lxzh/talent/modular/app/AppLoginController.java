//package com.lxzh.oafilemanager.security.modular.app;
//
//import ServiceException;
//import ServiceExceptionEnum;
//import DCResponse;
//import AuthLoginService;
//import KaptchaCodeUtil;
//import SysLoginUser;
//import AppLoginVO;
//import SysUserLoginParam;
//import io.swagger.annotations.Api;
//import io.swagger.annotations.ApiImplicitParam;
//import io.swagger.annotations.ApiImplicitParams;
//import io.swagger.annotations.ApiOperation;
//import lombok.extern.slf4j.Slf4j;
//import org.apache.commons.lang3.StringUtils;
//import org.springframework.web.bind.annotation.*;
//import javax.annotation.Resource;
//
///**
// * @author baiwandong
// */
//@Slf4j
//@RestController
//@RequestMapping("/app/auth")
//@Api(value = "/app/auth", tags = {"app登陆"})
//public class AppLoginController {
//    @Resource
//    private AuthLoginService authService;
//
//    @PostMapping("/login")
//    @ApiOperation(value = "账号密码登录", notes = "账号密码登录")
//    public DCResponse<AppLoginVO> auth(@RequestBody SysUserLoginParam param) {
//        AppLoginVO appLoginVO = new AppLoginVO();
//        if(StringUtils.isNotBlank(param.getUuid()) && StringUtils.isNotBlank(param.getCode())){
//            if(!KaptchaCodeUtil.checkCode(param.getUuid(),param.getCode())){
//                throw new ServiceException(500,"验证码错误！");
//            }
//        }
//
//        SysLoginUser sysLoginUser = authService.login(param.getAccount(),param.getPassword(),param.getLoginPortType());
//        //更新openId
//        appLoginVO.setToken(sysLoginUser.getToken());
//        appLoginVO.setHeadImgUrl(sysLoginUser.getAvatar());
//        appLoginVO.setNickname(sysLoginUser.getName());
//        return DCResponse.success(appLoginVO);
//    }
//
//    @PostMapping("/loginByMessage")
//    @ApiOperation(value = "客户手机短信登录", notes = "客户手机短信登录")
//    public DCResponse<AppLoginVO> loginByMessage(@RequestBody SysUserLoginParam param) {
//        AppLoginVO appLoginVO = new AppLoginVO();
//        boolean flag1 = authService.verifyCode(param.getPhoneCode(),param.getAccount());
//        if(!flag1){
//            throw new ServiceException(ServiceExceptionEnum.PHONE_CODE_IS_NOT_TRUE);
//        }
//        SysLoginUser sysLoginUser = authService.loginByPhoneCode(param);
//        //更新openId
//        appLoginVO.setToken(sysLoginUser.getToken());
//        appLoginVO.setHeadImgUrl(sysLoginUser.getAvatar());
//        appLoginVO.setNickname(sysLoginUser.getName());
//        return DCResponse.success(appLoginVO);
//    }
//
//    @PostMapping("/forGetPassWord")
//    @ApiOperation(value = "忘记密码", notes = "忘记密码")
//    public DCResponse<Boolean> forGetPassWord(@RequestBody SysUserLoginParam param) {
//        //验证完验证码之后直接修改密码
//        boolean flag = authService.updateUserPassword(param);
//        return DCResponse.success(flag);
//    }
//
//    @PostMapping("/customerRegister")
//    @ApiOperation(value = "点击注册", notes = "点击注册")
//    public DCResponse customerRegister(@RequestBody SysUserLoginParam param) {
//        //验证完验证码之后直接修改密码
//        boolean flag = authService.registerUser(param);
//        return DCResponse.success("操作成功");
//    }
//
//
//
//    /**
//     * 发送短信及接受
//     *
//     * @param phone 手机号
//     */
//    @GetMapping("/sendMessageInfo")
//    @ApiOperation(value = "发送短信及接受", notes = "发送短信及接受")
//    @ApiImplicitParams({
//            @ApiImplicitParam(name = "phone", value = "手机号", required = true, dataType = "String")
//    })
//    public DCResponse sendMessage(@RequestParam("phone") String phone) {
//        String res = authService.sendWxMessage(phone);
//        return DCResponse.success("已发送");
//    }
//}
