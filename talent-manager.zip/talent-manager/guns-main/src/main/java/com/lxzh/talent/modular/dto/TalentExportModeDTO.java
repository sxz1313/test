package com.lxzh.talent.modular.dto;

import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.annotation.format.DateTimeFormat;
import com.alibaba.excel.annotation.write.style.ColumnWidth;
import lombok.Data;

import java.util.Date;

/**
 * <p>
 * 人才库信息下载模板
 * </p>
 *
 * @author wr
 * @since 2023-02-21
 */
@Data
public class TalentExportModeDTO {

    @ExcelProperty(value = {"姓名"})
    @ColumnWidth(20)
    private String name;

    @ExcelProperty(value = {"性别"})
    @ColumnWidth(40)
    private String sexLabel;

    @ExcelProperty(value = {"出生日期"})
    @ColumnWidth(20)
    private String birthday;

    @ExcelProperty(value = {"毕业学校"})
    @ColumnWidth(20)
    private String schoolName;

    @ExcelProperty(value = {"专业"})
    @ColumnWidth(20)
    private String professionalCategoryLabel;

    @ExcelProperty(value = {"学历"})
    @ColumnWidth(20)
    private String educationLevelLabel;

    @ExcelProperty(value = {"学位"})
    @ColumnWidth(20)
    private String degree;

    @ExcelProperty(value = {"工作单位"})
    @ColumnWidth(40)
    private String companyName;

    @ExcelProperty(value = {"职务"})
    @ColumnWidth(40)
    private String professionalTechnicalPostLabel;

    @ExcelProperty(value = {"职称"})
    @ColumnWidth(60)
    private String talentProfessionalTechnical;

    @ExcelProperty(value = {"联系电话"})
    @ColumnWidth(20)
    private String mobile;
}
