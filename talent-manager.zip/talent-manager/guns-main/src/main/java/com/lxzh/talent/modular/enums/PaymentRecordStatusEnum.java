package com.lxzh.talent.modular.enums;

/**
 * <p>
 * 订单支付记录状态枚举类
 * </p>
 *
 * @author wr
 * @since 2022-09-28
 */
public enum PaymentRecordStatusEnum {

    WAIT_PAY(1, "待付款"),
    DOING_PAY(2, "支付中"),
    FINISH_PAY(3, "支付完成"),
    ERROR(4, "支付失败");

    private Integer value;
    private String desc;

    PaymentRecordStatusEnum(Integer value, String desc) {
        this.value = value;
        this.desc = desc;
    }

    public Integer getValue() {
        return this.value;
    }

    public String getDesc() {
        return desc;
    }

    @Override
    public String toString() {
        return this.desc;
    }

}
