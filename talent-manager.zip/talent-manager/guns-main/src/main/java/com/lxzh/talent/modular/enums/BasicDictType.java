package com.lxzh.talent.modular.enums;

import lombok.Getter;

/**
 * @author qun.zheng
 * @description: 基础字典类型
 * @date 2019/4/17下午4:49
 */
@Getter
public enum BasicDictType {
    NONE("NONE","NONE"),

    SourceCategory("source_category","生源类别"),
    AccountType("account_type","户口类型"),
    YesOrNo("yes_or_no","是否"),
    RiskCategory("risk_category","风险类别"),
    Classification("classification","分级"),
    CommonStatus("common_status","通用状态(0-正常,1-停用,2-删除)"),
    ForumType("forum_type","帖子类型"),
    SendForumType("send_forum_type","发帖类型"),
    GoodsMark("goods_mark","商品标签"),
    EDUCATION("education","学历"),


    Sex("sex","性别"),
    Health("health","健康状况"),
    MarriageStatus("marriage_status","婚姻状况"),
    JobLevel("job_level","职位级别"),
    Nation("nation","民族"),
    OccupationalQualifications("occupational_qualifications","执业资格"),
    ProfessionalCategory("professional_category","专业类别"),
    Other_validIdentityDocuments("other_valid_identity_documents","其他有效身份证件"),
    EmploymentForm("employment_form","用工形式"),
    TalentProperty("talent_property","人才属性"),
    EliteStudent("mingxiaoyousheng ","名校优生"),
    EducationalLevel("educational_level","学历层次"),
    Degree("degree","学位"),
    Job("job","职业"),
    Position("position","职位"),
    TechnicalPosition("technical_position","专业技术职务"),
    ProfessionalPost("professional_post","专业技术岗位"),
    HonoraryTitle("honorary_title","荣誉称号（奖励）名称"),
    HonoraryLevel("honorary_level","级别"),
    OralProficiency("oral_proficiency","口语熟练程度"),
    FamilyMembers("family_members","家庭成员及主要社会关系")
    ;

    BasicDictType(String code, String name) {
        this.code = code;
        this.name = name;
    }

    public String code;
    public String name;
}
