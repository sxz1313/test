package com.lxzh.talent.modular.enums;

/**
 * <p>
 * 订单状态枚举类
 * </p>
 *
 * @author wr
 * @since 2022-09-28
 */
public enum OrderStatusEnum {

    WAIT_PAY(1, "待支付"),
    FINISH_PAY(2, "已支付"),
    INVALID(3, "已取消");

    private Integer value;
    private String desc;

    OrderStatusEnum(Integer value, String desc) {
        this.value = value;
        this.desc = desc;
    }

    public Integer getValue() {
        return this.value;
    }

    public String getDesc() {
        return desc;
    }

    @Override
    public String toString() {
        return this.desc;
    }

}
