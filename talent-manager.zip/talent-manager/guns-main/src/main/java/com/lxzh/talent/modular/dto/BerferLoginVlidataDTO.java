package com.lxzh.talent.modular.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @author: wsn
 */
@Data
public class BerferLoginVlidataDTO {
    @ApiModelProperty("手机号")
    private String phone;

    @ApiModelProperty("登录端口类型1-后台管理,2-人才网站")
    private Integer loginPortType;

    @ApiModelProperty("业务类型 1-注册,2-忘记密码")
    private Integer relType;
}
