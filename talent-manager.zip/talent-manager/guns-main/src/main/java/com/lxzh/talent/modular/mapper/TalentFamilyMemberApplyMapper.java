package com.lxzh.talent.modular.mapper;

import com.lxzh.talent.modular.entity.TalentFamilyMemberApply;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 人才信息-家庭成员及主要社会关系申请表 Mapper 接口
 * </p>
 *
 * @author wr
 * @since 2022-10-18
 */
public interface TalentFamilyMemberApplyMapper extends BaseMapper<TalentFamilyMemberApply> {

}
