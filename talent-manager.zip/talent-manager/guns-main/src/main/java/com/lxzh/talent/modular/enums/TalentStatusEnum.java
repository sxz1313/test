package com.lxzh.talent.modular.enums;


/**
 * <p>
 * 人才退会状态枚举类
 * </p>
 *
 * @author wr
 * @since 2023-02-17
 */
public enum TalentStatusEnum {

    NORMAL(0,"正常"),
    EXIT_CLUB(1,"已退会")
    ;

    private Integer value;
    private String desc;

    TalentStatusEnum(Integer value, String desc) {
        this.value = value;
        this.desc = desc;
    }

    public Integer getValue() {
        return this.value;
    }

    public String getDesc() {
        return desc;
    }

    @Override
    public String toString() {
        return this.desc;
    }
}
