package com.lxzh.talent.modular.entity;

import lombok.Data;

/**
 * @author: wsn
 */
@Data
public class Country {
    private String code;
    private String name;
}
