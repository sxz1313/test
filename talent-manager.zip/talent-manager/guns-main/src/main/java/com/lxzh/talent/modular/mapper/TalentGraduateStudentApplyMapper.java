package com.lxzh.talent.modular.mapper;

import com.lxzh.talent.modular.entity.TalentGraduateStudentApply;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 人才信息-培养研究生情况申请表 Mapper 接口
 * </p>
 *
 * @author wr
 * @since 2022-10-18
 */
public interface TalentGraduateStudentApplyMapper extends BaseMapper<TalentGraduateStudentApply> {

}
