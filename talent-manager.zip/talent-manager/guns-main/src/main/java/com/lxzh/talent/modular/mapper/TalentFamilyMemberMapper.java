package com.lxzh.talent.modular.mapper;

import com.lxzh.talent.modular.entity.TalentFamilyMember;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 人才信息-家庭成员及主要社会关系表 Mapper 接口
 * </p>
 *
 * @author wr
 * @since 2022-10-18
 */
public interface TalentFamilyMemberMapper extends BaseMapper<TalentFamilyMember> {

}
