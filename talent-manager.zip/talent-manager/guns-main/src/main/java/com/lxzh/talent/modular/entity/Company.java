package com.lxzh.talent.modular.entity;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.lxzh.talent.core.pojo.base.entity.BasicEntity;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 公司信息表
 *
 * @author wsn
 * @date 2022/10/17 09:29
 */
@Data
@EqualsAndHashCode(callSuper = true)
@TableName("company")
public class Company extends BasicEntity {

    /**
     * 主键
     */
    @TableId("id")
    private Long id;

    /**
     * 单位名称
     */
    @TableField("name")
    private String name;

    /**
     * 统一社会信用代码
     */
    @TableField("social_credit_code")
    private String socialCreditCode;

    /**
     * 营业执照文件ID
     */
    @TableField("business_license_file_id")
    private Long businessLicenseFileId;

    /**
     * 联系人
     */
    @TableField("contact_user")
    private String contactUser;

    /**
     * 联系方式
     */
    @TableField("contact_phone")
    private String contactPhone;

    /**
     * 状态 0-待审核 1-审核通过 2-审核不通过
     */
    @TableField("status")
    private Integer status;

    /**
     * 来源 1-管理后台新增 2-人才库前端注册
     */
    @TableField("source")
    private Integer source;
}
