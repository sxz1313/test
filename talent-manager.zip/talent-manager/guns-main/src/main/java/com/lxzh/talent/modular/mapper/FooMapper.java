package com.lxzh.talent.modular.mapper;

import com.lxzh.talent.modular.entity.Foo;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author qun.zheng
 * @since 2021-03-25
 */
public interface FooMapper extends BaseMapper<Foo> {

}
