package com.lxzh.talent.modular.controller;

import com.lxzh.talent.modular.response.DCResponse;
import com.lxzh.talent.modular.vo.UploadReturnVO;
import com.lxzh.talent.sys.modular.file.entity.SysFileInfo;
import com.lxzh.talent.sys.modular.file.service.SysFileInfoService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;

@Api(tags = {"文件上传"})
@RestController
@RequestMapping("/v1/files")
public class UpLoadController {

    @Resource
    private SysFileInfoService sysFileInfoService;


    @ApiOperation(value = "文件上传")
    @ResponseBody
    @PostMapping("/upload")
    public DCResponse<UploadReturnVO> confirm(MultipartFile file, @RequestParam(value = "type", required = false) Integer type) {
        SysFileInfo sysFileInfo = sysFileInfoService.uploadFile(file, type);
        UploadReturnVO uploadReturnVO = new UploadReturnVO();
        uploadReturnVO.setFileId(sysFileInfo.getId());
        uploadReturnVO.setFileName(sysFileInfo.getFileOriginName());
        uploadReturnVO.setFileUrl(sysFileInfo.getFilePath());
        return DCResponse.success(uploadReturnVO);
    }
}
