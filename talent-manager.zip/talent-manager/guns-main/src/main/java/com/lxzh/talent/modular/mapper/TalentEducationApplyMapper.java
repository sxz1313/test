package com.lxzh.talent.modular.mapper;

import com.lxzh.talent.modular.entity.TalentEducationApply;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 人才信息-学历及学位申请表 Mapper 接口
 * </p>
 *
 * @author wr
 * @since 2022-10-18
 */
public interface TalentEducationApplyMapper extends BaseMapper<TalentEducationApply> {

}
