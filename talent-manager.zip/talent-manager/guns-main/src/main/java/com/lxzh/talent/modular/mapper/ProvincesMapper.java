package com.lxzh.talent.modular.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.lxzh.talent.modular.entity.Province;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author qun.zheng
 * @since 2019-04-10
 */
public interface ProvincesMapper extends BaseMapper<Province> {

}

