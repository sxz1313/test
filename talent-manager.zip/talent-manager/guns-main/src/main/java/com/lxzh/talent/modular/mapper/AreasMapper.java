package com.lxzh.talent.modular.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.lxzh.talent.modular.entity.Area;

/**
 * <p>
 * 区县信息表 Mapper 接口
 * </p>
 *
 * @author qun.zheng
 * @since 2019-04-10
 */
public interface AreasMapper extends BaseMapper<Area> {

}
