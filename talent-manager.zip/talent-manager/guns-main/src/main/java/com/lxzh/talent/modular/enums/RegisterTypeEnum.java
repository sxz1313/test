package com.lxzh.talent.modular.enums;

import lombok.Getter;

/**
 * @author: wsn
 */
@Getter
public enum RegisterTypeEnum {
    COMPANY(1, "单位"),
    PERSON(2, "个人"),
    ;

    private final Integer code;

    private final String message;

    RegisterTypeEnum(Integer code, String message) {
        this.code = code;
        this.message = message;
    }

    public static RegisterTypeEnum getEnumByCode(Integer code) {
        for (RegisterTypeEnum value : values()) {
            if (value.getCode().equals(code)) {
                return value;
            }
        }
        return null;
    }

    public static RegisterTypeEnum getEnumByMsg(String msg) {
        for (RegisterTypeEnum value : values()) {
            if (value.getMessage().equals(msg)) {
                return value;
            }
        }
        return null;
    }
}
