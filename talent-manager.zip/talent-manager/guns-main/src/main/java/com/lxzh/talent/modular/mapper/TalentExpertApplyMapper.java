package com.lxzh.talent.modular.mapper;

import com.lxzh.talent.modular.entity.TalentExpertApply;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 人才信息-荣获专家称号情况申请表 Mapper 接口
 * </p>
 *
 * @author wr
 * @since 2022-10-18
 */
public interface TalentExpertApplyMapper extends BaseMapper<TalentExpertApply> {

}
