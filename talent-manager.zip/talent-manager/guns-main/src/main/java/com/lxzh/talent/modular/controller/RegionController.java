package com.lxzh.talent.modular.controller;


import cn.hutool.core.bean.BeanUtil;
import com.lxzh.talent.modular.entity.Area;
import com.lxzh.talent.modular.entity.City;
import com.lxzh.talent.modular.entity.Country;
import com.lxzh.talent.modular.entity.Province;
import com.lxzh.talent.modular.model.KeyValue;
import com.lxzh.talent.modular.response.DCResponse;
import com.lxzh.talent.modular.service.IRegionService;
import com.lxzh.talent.modular.support.CountryQuerier;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

/**
 * <p>
 * 区域控制器，用于获取省份、地市、区县信息
 * </p>
 *
 * @author wr
 * @since 2022-09-28
 */
@Api(value = "/v1/region", tags = {"基础设施-省份、地市、区县信息"})
@RestController
@RequestMapping("/v1/region")
public class RegionController {
    @Autowired
    private IRegionService regionService;

    /**
     * 获取所有的国家信息
     * @return
     */
    @ApiOperation(value = "获取所有的国家信息", notes = "获取所有的国家信息")
    @GetMapping("/countrys")
    public DCResponse<List<Country>> getCountrys(){
        List<CountryQuerier.Country> all = CountryQuerier.getAll();
        List<Country> collect = all.stream().map(x -> {
            Country country = new Country();
            String s = x.toString();
            String[] split = s.split(" - ");
            country.setCode(split[0]);
            country.setName(split[1]);
            return country;
        }).collect(Collectors.toList());
        return DCResponse.success(collect);
    }


    /**
     * 获取所有的省份信息
     * @return
     */
    @ApiOperation(value = "获取所有的省份信息", notes = "获取所有的省份信息")
    @GetMapping("/provinces")
    public DCResponse<List<KeyValue>> getProvinces(){
        return DCResponse.success(regionService.getProvinces());
    }

    /**
     * 获取省份下的地市信息
     * @return
     */
    @ApiOperation(value = "获取省份下的地市信息", notes = "获取省份下的地市信息")
    @ApiImplicitParams(value = {
            @ApiImplicitParam(name = "provinceCode", value = "省份code", required = true, paramType = "path", dataType = "String"),
    })
    @GetMapping("/provinces/{provinceCode}/cities")
    public DCResponse<List<KeyValue>> getCitiesByProvinceId(@PathVariable("provinceCode") String provinceCode){
        return DCResponse.success(regionService.getCitiesByProvinceId(provinceCode));
    }

    /**
     * 获取地市下的区县信息
     * @return
     */
    @ApiOperation(value = "获取地市下的区县信息", notes = "获取地市下的区县信息")
    @ApiImplicitParams(value = {
            @ApiImplicitParam(name = "cityCode", value = "地市code", required = true, paramType = "path", dataType = "String"),
    })
    @GetMapping("/cities/{cityCode}/areas")
    public DCResponse<List<KeyValue>> getAreasByCityId(@PathVariable("cityCode") String cityCode){
        return DCResponse.success(regionService.getAreasByCityId(cityCode));
    }

    /**
     * 根据省code查名称
     * @return
     */
    @ApiOperation(value = "根据省code查名称", notes = "根据省code查名称")
    @ApiImplicitParams(value = {
            @ApiImplicitParam(name = "provinceCode", value = "省code", required = true, paramType = "path", dataType = "String"),
    })
    @GetMapping("getByProvinceCode")
    public DCResponse<Province> getByProvinceCode(@RequestParam("provinceCode") String provinceCode){
        return DCResponse.success(regionService.getByProvinceCode(provinceCode));
    }

    /**
     * 根据市code查名称
     * @return
     */
    @ApiOperation(value = "根据市code查名称", notes = "根据市code查名称")
    @ApiImplicitParams(value = {
            @ApiImplicitParam(name = "cityCode", value = "市code", required = true, paramType = "path", dataType = "String"),
    })
    @GetMapping("getByCityCode")
    public DCResponse<City> getByCityCode(@RequestParam("cityCode") String cityCode){
        return DCResponse.success(regionService.getByCityCode(cityCode));
    }

    /**
     * 根据区code查名称
     * @return
     */
    @ApiOperation(value = "根据区code查名称", notes = "根据区code查名称")
    @ApiImplicitParams(value = {
            @ApiImplicitParam(name = "areaCode", value = "区code", required = true, paramType = "path", dataType = "String"),
    })
    @GetMapping("getByAreaCode")
    public DCResponse<Area> getByAreaCode(@RequestParam("areaCode") String areaCode){
        return DCResponse.success(regionService.getByAreaCode(areaCode));
    }
}
