package com.lxzh.talent.modular.dto;

import com.lxzh.talent.modular.entity.TalentApply;
import com.lxzh.talent.modular.vo.CustomerSimpleVO;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;


/**
 * <p>
 * 人才信息-参加学术团体情况申请表
 * </p>
 *
 * @author wr
 * @since 2022-10-21
 */
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
public class TalentApplyBaseDTO implements Serializable {

    /**
     * 用户信息
     */
    private CustomerSimpleVO customerInfo;

    /**
     * 人才基本信息
     */
    private TalentApply talentApply;

    /**
     * 来源类型（1-个人 2-企业 3-从其他数据源复制过来的 4-待审核草稿）
     */
    private Integer sourceType;

    /**
     * 来源类型（1-个人 2-企业 3-从其他数据源复制过来的 4-待审核草稿）
     */
    private Long sourceId;

    /**
     * 用户id
     */
    private Long userId;

    /**
     * 单位id
     */
    private Long companyId;
}
