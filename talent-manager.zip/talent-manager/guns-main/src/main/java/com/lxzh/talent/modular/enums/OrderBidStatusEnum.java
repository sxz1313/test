package com.lxzh.talent.modular.enums;

/**
 * <p>
 * 订单中标状态枚举类
 * </p>
 *
 * @author wr
 * @since 2022-09-15
 */
public enum OrderBidStatusEnum {

    WAIT_BID(0, "待开标"),
    OUT_BID(1, "中标"),
    LOSE_BID(2, "未中标");

    private Integer value;
    private String desc;

    OrderBidStatusEnum(Integer value, String desc) {
        this.value = value;
        this.desc = desc;
    }

    public Integer getValue() {
        return this.value;
    }

    public String getDesc() {
        return desc;
    }

    @Override
    public String toString() {
        return this.desc;
    }

}
