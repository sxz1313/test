package com.lxzh.talent.modular.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import java.util.Date;
import java.time.LocalDate;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.TableLogic;
import com.baomidou.mybatisplus.annotation.TableField;
import java.io.Serializable;

import com.lxzh.talent.core.pojo.base.entity.BasicEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * <p>
 * 人才信息-取得专业技术职称、职（执）业资格情况申请表
 * </p>
 *
 * @author wr
 * @since 2022-10-18
 */
@Data
@EqualsAndHashCode(callSuper = false)
@TableName("talent_professional_technical_apply")
@ApiModel(value="TalentProfessionalTechnicalApply对象", description="人才信息-取得专业技术职称、职（执）业资格情况申请表")
public class TalentProfessionalTechnicalApply extends BasicEntity {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "id")
    @TableId("id")
    private Long id;

    @ApiModelProperty(value = "人才信息申请id")
    @TableField("talent_apply_id")
    private Long talentApplyId;

    @ApiModelProperty(value = "职称、职(执)业资格名称")
    @TableField("name")
    private String name;

    @ApiModelProperty(value = "证书编号")
    @TableField("certificate_no")
    private String certificateNo;

    @ApiModelProperty(value = "发证日期")
    @TableField("issue_date")
    private LocalDate issueDate;

    @ApiModelProperty(value = "发证单位名称")
    @TableField("issue_unit")
    private String issueUnit;

    @ApiModelProperty(value = "排序")
    @TableField("sort")
    private Integer sort;
}
