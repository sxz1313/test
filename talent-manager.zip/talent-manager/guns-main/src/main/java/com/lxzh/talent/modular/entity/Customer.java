package com.lxzh.talent.modular.entity;

import com.baomidou.mybatisplus.annotation.FieldStrategy;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.lxzh.talent.core.pojo.base.entity.BasicEntity;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.Date;

/**
 * 客户信息表
 *
 * @author wsn
 * @date 2022/10/17 09:29
 */
@Data
@EqualsAndHashCode(callSuper = true)
@TableName("customer")
public class Customer extends BasicEntity {

    /**
     * 主键
     */
    @TableId("id")
    private Long id;

    /**
     * 姓名
     */
    @TableField("name")
    private String name;

    /**
     * 手机号
     */
    @TableField("phone")
    private String phone;

    /**
     * 身份证号
     */
    @TableField("identity_card")
    private String identityCard;

    /**
     * 用户登录账号ID
     */
    @TableField("user_id")
    private Long userId;

    /**
     * 公司id
     */
    @TableField(value = "company_id", updateStrategy = FieldStrategy.IGNORED)
    private Long companyId;

    /**
     * 公司名称
     */
    @TableField("company_name")
    private String companyName;

    /**
     * 注册类型 1-单位 2-个人
     */
    @TableField("register_type")
    private Integer registerType;

    /**
     * 注册日期
     */
    @TableField("register_time")
    private Date registerTime;
}
