package com.lxzh.talent.modular.mapper;

import com.lxzh.talent.modular.entity.TalentExpert;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 人才信息-荣获专家称号情况表 Mapper 接口
 * </p>
 *
 * @author wr
 * @since 2022-10-18
 */
public interface TalentExpertMapper extends BaseMapper<TalentExpert> {

}
