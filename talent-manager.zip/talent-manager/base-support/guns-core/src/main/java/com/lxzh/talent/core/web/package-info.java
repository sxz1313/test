package com.lxzh.talent.core.web;
/**
 * 此包存放的对spring mvc的一些拓展
 */