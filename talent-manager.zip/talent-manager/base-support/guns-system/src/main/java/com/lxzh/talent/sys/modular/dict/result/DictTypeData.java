package com.lxzh.talent.sys.modular.dict.result;

import cn.hutool.core.convert.Convert;
import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.time.LocalDateTime;
import java.util.List;

/**
 * @author : zzw
 * @Description: 字典返回体
 * @date : 2021/3/8 11:25
 **/
@Data
@ApiModel
public class DictTypeData extends Convert {

    @ApiModelProperty("字典类型主键id")
    Long dictTypeId;

    private String code;

    @ApiModelProperty("字典类型名称")
    String dictTypeName;

    @ApiModelProperty("字典条目")
    List<String> dictData;

    @ApiModelProperty("创建时间")
    @JsonFormat(pattern="yyyy-MM-dd HH:mm:ss")
    LocalDateTime createTime;
}
