package com.lxzh.talent.sys.modular.dict.result;

import lombok.Data;

/**
 * @author: wsn
 */
@Data
public class DictTypeNode {
    private Long id;

    private String name;

    private String code;
}
