package com.lxzh.talent.sys.modular.dict.result;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @author : zzw
 * @Description: 字典条目
 * @date : 2021/3/8 13:29
 **/
@Data
@ApiModel
public class DictData {

    @ApiModelProperty("id")
    private Long id;

    @ApiModelProperty("编码")
    private String code;

    @ApiModelProperty("字典目录")
    private String value;

    @ApiModelProperty("排序")
    private Integer sort;
}
