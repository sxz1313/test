package com.lxzh.talent.sys.modular.auth.param;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * 系统用户登录请求参数
 *
 * @author xuyuxiang
 * @date 2020/3/23 9:21
 */
@Data
@ApiModel
public class SysUserLoginParam {

    @ApiModelProperty("账号(包括手机号)")
    private String account;

    @ApiModelProperty("密码")
    private String password;

    @ApiModelProperty("登录端口类型1-后台管理,2-人才网站")
    private Integer loginPortType;

    @ApiModelProperty("手机验证码")
    private String phoneCode;

    @ApiModelProperty("姓名")
    private String name;

    @ApiModelProperty("标识")
    private String uuid;

    @ApiModelProperty("验证码")
    private String code;

    @ApiModelProperty("注册类型1-单位,2-个人")
    private Integer registerType;

    @ApiModelProperty("公司id")
    private String companyId;

    @ApiModelProperty("公司名称")
    private String companyName;

    private String avatar;
}
