package com.lxzh.talent.sys.modular.dict.result;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.List;

/**
 * @author : zzw
 * @Description: 字典返回所有
 * @date : 2021/4/27 11:41
 **/
@Data
@ApiModel
public class AllDictData {

    @ApiModelProperty("字典类型id")
    private Long dictTypeId;

    @ApiModelProperty("字典类型名称")
    private String dictTypeName;

    @ApiModelProperty("字典类型code")
    private String dictTypeCode;

    @ApiModelProperty("字典值")
    private List<DictData> dictDataList;
}
