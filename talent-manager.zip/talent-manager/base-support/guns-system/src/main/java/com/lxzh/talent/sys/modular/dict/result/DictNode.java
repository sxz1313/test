package com.lxzh.talent.sys.modular.dict.result;

import lombok.Data;

/**
 * @author: wsn
 */
@Data
public class DictNode {
    private Long id;
    private String code;
    private String value;
}
