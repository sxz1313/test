const talent = {
  path: '/talent',
  name: 'talent',
  component: () => import('@/views/talent'),
  meta: {
    module: '',
    title: '人才管理',
    menuShow: true,
    authId: '1527089427250216961'
  },
  children: [
    {
      path: '/talent/talentReview',
      name: 'talentReview',
      component: () => import('@/views/talent/talentReview'),
      meta: {
        module: '',
        title: '人才审核',
        menuShow: true,
        authId: '1527089427489292290'
      }
    },
    {
      path: '/talent/talentReview/review',
      component: () => import('@/views/talent/talentReview/review'),
      name: 'talentReviewReview',
      meta: {
        module: '',
        title: '人才档案详情',
        menuShow: false,
        activeMenu: 'talentReview'
      }
    },
    {
      path: '/talent/talentPool',
      name: 'talentPool',
      component: () => import('@/views/talent/talentPool'),
      meta: {
        module: '',
        title: '人才库',
        menuShow: true,
        authId: '1527089428168769539'
      }
    },
    {
      path: '/talent/talentPool/detail',
      component: () => import('@/views/talent/talentPool/detail'),
      name: 'talentPoolDetail',
      meta: {
        module: '',
        title: '人才档案详情',
        menuShow: false,
        activeMenu: 'talentPool'
      }
    },
    {
      path: '/talent/exit',
      name: 'talentExit',
      component: () => import('@/views/talent/exit'),
      meta: {
        module: '',
        title: '退会人才库',
        menuShow: true,
        authId: '1527089428533673989'
      }
    },
    {
      path: '/talent/exit/detail',
      component: () => import('@/views/talent/exit/detail'),
      name: 'talentExitDetail',
      meta: {
        module: '',
        title: '退会人才详情',
        menuShow: false,
        activeMenu: 'talentExit'
      }
    }
  ]
}
export default talent
