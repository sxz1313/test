const business = {
  path: '/business',
  name: 'business',
  component: () => import('@/views/business'),
  meta: {
    module: '',
    title: '企业管理',
    menuShow: true,
    authId: '1527089428533675988'
  },
  children: [
    {
      path: '/business/enterpriseAudit',
      name: 'enterpriseAudit',
      component: () => import('@/views/business/enterpriseAudit'),
      meta: {
        module: '',
        title: '企业审核',
        menuShow: true,
        authId: '1527089428533675989'
      }
    },
    {
      path: '/business/enterpriseAccount',
      name: 'enterpriseAccount',
      component: () => import('@/views/business/enterpriseAccount'),
      meta: {
        module: '',
        title: '企业台账',
        menuShow: true,
        authId: '1527089428533676989'
      }
    },
    {
      path: '/business/enterpriseAccountAddEdit',
      name: 'enterpriseAccountAddEdit',
      component: () => import('@/views/business/enterpriseAccount/addEdit'),
      meta: {
        module: '',
        title: '企业台账',
        menuShow: false,
        activeMenu: 'enterpriseAccount'
      }
    },
    {
      path: '/business/enterpriseAccountCheck',
      name: 'enterpriseAccountCheck',
      component: () => import('@/views/business/enterpriseAccount/check'),
      meta: {
        module: '',
        title: '企业台账',
        menuShow: false,
        activeMenu: 'enterpriseAccount'
      }
    }
  ]
}
export default business
