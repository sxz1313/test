const systemManage = {
  path: '/system',
  name: 'system',
  component: () => import('@/views/system'),
  meta: {
    module: '',
    title: '系统管理',
    menuShow: true,
    authId: '1506105219308564481'
  },
  children: [
    // {
    //   path: '/system/user-manage',
    //   name: 'userManage',
    //   component: () => import('@/views/system/userManage/home'),
    //   meta: {
    //     module: '',
    //     title: '用户管理',
    //     menuShow: true,
    //     authId: '1506105219635720194'
    //   }
    // },
    {
      path: '/system/user-manage',
      name: 'userManage',
      component: () => import('@/views/system/userManage'),
      meta: {
        module: '',
        title: '用户管理',
        menuShow: true,
        authId: '1506105219635720194'
      }
    },
    {
      path: '/system/role-manage',
      name: 'roleManage',
      component: () => import('@/views/system/roleManage'),
      meta: {
        module: '',
        title: '角色管理',
        menuShow: true,
        authId: '1506105220587827202'
      }
    },
    {
      path: '/system/role-manage/edit-role',
      component: () => import('@/views/system/roleManage/addRole'),
      name: 'addRole',
      meta: {
        module: '',
        title: '添加角色',
        edit: true,
        menuShow: false,
        activeMenu: 'roleManage'
      }
    },
    {
      path: '/system/dict-manage',
      name: 'dictManage',
      component: () => import('@/views/system/dictManage'),
      meta: {
        module: '',
        title: '字典管理',
        menuShow: false,
        authId: '1506105219635720194'
      }
    }
  ]
}
export default systemManage
