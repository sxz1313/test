import Vue from 'vue'
import Router from 'vue-router'
// import { Message } from 'element-ui'
import User from '@/controller/User'
import system from './system' // 系统管理
import talent from './talent' // 人才管理
import business from './business' // 企业管理
const manageRoute = [
  talent,
  business,
  system
]
const routes = [
  {
    path: '/'
  },
  {
    path: '/login',
    name: 'login',
    component: () => import('@/views/login/index'),
    meta: {
      title: '登录'
    }
  },
  {
    path: '/register',
    name: 'register',
    component: () => import('@/views/register/index'),
    meta: {
      title: '注册'
    }
  },
  {
    path: '*',
    name: 'notFound',
    component: () => import('@/components/404/404'),
    meta: {
      title: '未找到'
    }
  },
  ...manageRoute
]
Vue.use(Router)
const router = new Router({
  routes
})

router.beforeEach((to, from, next) => {
  if (to.path === '/') {
    if (User.get('token')) {
      if (User.get('ids')) {
        const nav = JSON.parse(JSON.stringify(routes)).filter(ele => {
          const secondRoute = (ele.children || []).filter(item => item.meta && JSON.parse(User.get('ids')).includes(item.meta.authId))
          ele.children = secondRoute
          return ele && ele.children && ele.children.length > 0
        })
        if (nav.length) {
          next({ name: nav[0].children[0].name })
        } else {
          next('/404')
        }
      }
    } else {
      next('/login')
    }
  }
  next()
})

export default router
