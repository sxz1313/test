import Api from '@/api/Api'

const api = new Api({
  path: 'v1/'
})
const apiV0 = new Api({
  path: ''
})
// 企业
// 列表
export function companyList (param) {
  return api.get(`company/pageList`, param)
}
// 新增
export function companyAdd (param) {
  return api.post(`company/save`, param)
}
// 编辑
export function companyEdit (param) {
  return api.post(`company/update`, param)
}
// 详情
export function companyDetail (id) {
  return api.get(`company/${id}`)
}
// 删除
export function companyDel (id) {
  return api.del(`company/del/${id}`)
}
// 退会
export function exitClub (id) {
  return apiV0.post(`talent-manage/exit-club/${id}`)
}
// 审核
export function companyExamine (param) {
  return api.post(`company/examine`, param)
}
export function exitClubList (param) {
  return apiV0.post(`talent-manage/exit-club-page`, param)
}
// 人才管理
export function talentApplyPage (param) {
  return apiV0.post(`talent-apply-manage/page`, param)
}
export function auditTalentApply (param) {
  return apiV0.post(`talent-apply-manage/audit-talent-apply`, param)
}
export function talentMangePage (param) {
  return apiV0.post(`talent-manage/page`, param)
}
export function exportList (param) {
  return apiV0.postBlob(`talent-manage/batch-export`, param)
}
export function exportExitList (param) {
  return apiV0.postBlob(`talent-manage/exit-club-batch-export`, param)
}
// 搜索单位
export function queryByNameNoToken (name) {
  return api.get(`company/queryByNameNoToken`, name, { noLoading: true })
}
