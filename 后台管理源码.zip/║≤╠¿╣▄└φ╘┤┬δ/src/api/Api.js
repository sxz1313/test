import axios from 'axios'
import { Message, Loading } from 'element-ui'
// import loading from '@/components/loading'
import User from '@/controller/User'
const error = Message.error
let loading = null
let interNums = 0
export class ApiError extends Error {
  /**
   * @param msg {string, undefined}
   */
  constructor (msg) {
    super()
    this.message = msg
    this.isApiError = true
  }
}

export default class Api {
  static contentTypeJson = 'application/json;charset=UTF-8;';
  static contentTypeFormData = 'multipart/form-data;charset=UTF-8;';
  static contentTypeUrlEncode =
    'application/x-www-form-urlencoded;charset=UTF-8';
  static responseTypeJson = 'json';
  static responseTypeBlob = 'blob';
  static TIME_OUT = 20;

  /**
   * @param baseURL {string, undefined} 域名地址，默认使用项目配置
   * @param path {string} 路径
   */
  constructor ({ baseURL, path }) {
    this.baseURL = baseURL || process.env.VUE_APP_API_URL
    this.path = path
    this.responseType = Api.responseTypeJson
    this.contentType = Api.contentTypeJson
    this.withCredentials = false
    this.timeout = Api.TIME_OUT * 1000
    this.api = null
  }

  setResponseType (type) {
    this.responseType = type || Api.responseTypeJson
  }

  setContentType (type) {
    this.contentType = type || Api.contentTypeJson
  }

  setWithCredentials (bool) {
    this.withCredentials = bool
  }

  setTimeout (time) {
    this.timeout = time * 1000
  }

  create () {
    this.api = axios.create({
      baseURL: this.baseURL.concat(this.path),
      headers: {
        Accept: 'application/json,application/excel,text/plain,*/*',
        'Content-Type': this.contentType
      },
      timeout: this.timeout,
      validateStatus: (status) => {
        return status < 400
      },
      responseType: this.responseType,
      withCredentials: this.withCredentials
    })
    this.api.interceptors.request.use(requestInterceptor)
    this.api.interceptors.response.use(
      responseInterceptorSuccess,
      responseInterceptorFail
    )
  }

  get (url, queryData, config) {
    if (!this.api) {
      this.create()
    }
    url = queryData ? url + '?' + queryString(queryData) : url
    return this.api.get(url, config)
  }

  getBlob (url, queryData) {
    return this.get(url, queryData, {
      responseType: Api.responseTypeBlob,
      timeout: 0
    })
  }
  postBlob (url, queryData, data) {
    return this.post(url, queryData, data, {
      responseType: Api.responseTypeBlob,
      timeout: 0
    })
  }
  /**
   * post请求
   * @param url
   * @param queryData
   * @param data
   * @param config {Object, undefined}
   * @returns {*}
   */
  post (url, queryData, data, config) {
    if (!this.api) {
      this.create()
    }
    if (queryData && data) {
      url = url + '?' + queryString(queryData)
    }
    if (queryData && !data) {
      data = queryData
    }
    if (
      config &&
      config.headers &&
      config.headers['Content-Type'] === Api.contentTypeUrlEncode
    ) {
      data = this.toUrlEncode(data)
    }
    return this.api.post(url, data, config)
  }

  postUrlEncode (url, queryData, data) {
    return this.post(url, queryData, data, {
      headers: {
        'Content-Type': Api.contentTypeUrlEncode
      }
    })
  }
  putUrlEncode (url, queryData, data) {
    return this.put(url, queryData, data, {
      headers: {
        'Content-Type': Api.contentTypeUrlEncode
      }
    })
  }
  postFormData (url, queryData, data, config = {}) {
    return this.post(
      url,
      queryData,
      data,
      Object.assign(config, {
        headers: {
          'Content-Type': Api.contentTypeFormData
        },
        timeout: 0
      })
    )
  }

  del (url, queryData, data) {
    if (!this.api) {
      this.create()
    }
    if (queryData && data) {
      url = url + '?' + queryString(queryData)
    }
    if (queryData && !data) {
      data = queryData
    }
    return data ? this.api.delete(url, { data }) : this.api.delete(url)
  }

  put (url, queryData, data, config) {
    if (!this.api) {
      this.create()
    }
    if (queryData && data) {
      url = url + '?' + queryString(queryData)
    }
    if (queryData && !data) {
      data = queryData
    }
    if (
      config &&
      config.headers &&
      config.headers['Content-Type'] === Api.contentTypeUrlEncode
    ) {
      data = this.toUrlEncode(data)
    }
    return this.api.put(url, data, config)
  }

  getBaseURL () {
    return this.baseURL
  }
  toUrlEncode (data) {
    if (data instanceof Object) {
      let r = ''
      for (const key in data) {
        r += `${key}=${data[key]}&`
      }
      return r.slice(0, -1)
    } else {
      return data
    }
  }
  /**
   * 获取请求的api地址
   * @param path {string}
   * @param queryData {object}
   * @returns {string}
   */
  getCompletePath (path, queryData) {
    if (queryData) {
      return (
        this.getBaseURL() + this.path + path + '?' + queryString(queryData)
      )
    }
    return this.getBaseURL() + this.path + path
  }
}

/**
 * 对象转url query
 * @param data
 */

function queryString (data) {
  let r = ''
  for (const key in data) {
    if (data.hasOwnProperty(key)) {
      if (isNumber(data[key]) || isString(data[key]) || isObject(data[key])) {
        r += `&${key}=${data[key].toString()}`
      }
    }
  }
  return r.slice(1)
}

/**
 * axios请求拦截器
 * @param config {object} axios config
 * @returns {*}
 */
function requestInterceptor (config) {
  // loading.open()
  interNums++
  if (!loading && !config.noLoading) {
    loading = Loading.service({
      text: 'Loading',
      spinner: 'el-icon-loading',
      target: document.querySelector('.main'),
      background: 'rgba(0, 0, 0, 0.7)'
    })
  }
  config.headers['Authorization'] = User.token
  return config
}

/**
 * axios返回拦截器-成功
 * @param res {object} axios successful response data
 * @returns {Promise<any>| res}
 */
function responseInterceptorSuccess (res) {
  interNums--
  if (interNums <= 0) {
    loading && loading.close()
    loading = null
  }
  // loading.close()
  if (
    res.data.code === 200 ||
    res.request.responseType === Api.responseTypeBlob
  ) {
    return res
  } else if (
    res.data.code === 1011004 ||
    res.data.code === 1011005 ||
    res.data.code === 1011006 ||
    res.data.code === 1011008 ||
    res.data.code === 1011009 ||
    res.data.code === 10110012
  ) {
    window.location.hash = '/login'
    User.clear()
    return res
  } else {
    const msg = res.data.message || res.data.msg
    !res.config.closePrompt && error(msg)
    return Promise.reject(new ApiError(msg))
  }
}

/**
 * axios返回拦截器-失败
 * @param err {Error}
 * @returns {Promise<Error>}
 */
function responseInterceptorFail (err) {
  interNums--
  if (interNums <= 0) {
    loading && loading.close()
    loading = null
  }
  // loading.close()
  if (
    err.response.data.code === 1011004 ||
    err.response.data.code === 1011005 ||
    err.response.data.code === 1011006 ||
    err.response.data.code === 1011008 ||
    err.response.data.code === 1011009
  ) {
    window.location.hash = '/login'
    User.clear()
    return err
  }
  let msg = ''
  if (timeout(err)) {
    msg = '连接超时'
  } else if (serverIsNotResponsed(err)) {
    msg = '网络异常'
  } else {
    msg =
      (err.response &&
        err.response.data &&
        (err.response.data.message || err.response.data.msg)) ||
      err.message ||
      err.msg
  }
  error(msg)
  return Promise.reject(new ApiError(msg))
}

function timeout (err) {
  return err.code === 'ECONNABORTED'
}

function serverIsNotResponsed (err) {
  return (
    err.request && err.request.status === 0 && err.request.readyState === 4
  )
}

function isNumber (val) {
  return typeof val === 'number'
}

function isString (val) {
  return typeof val === 'string'
}

function isObject (val) {
  return val !== null && typeof val === 'object'
}
