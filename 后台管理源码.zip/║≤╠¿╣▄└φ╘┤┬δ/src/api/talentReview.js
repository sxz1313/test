import Api from '@/api/Api'

const api = new Api({
  path: 'talent-apply-manage/'
})

// 获取单位信息
export function getCompanyInfo (param) {
  return api.post(`find-talent-company-apply/${param.talentApplyId}`)
}

// 获取个人信息
export function getBasicInfo (param) {
  return api.post(`find-talent-detail-apply/${param.talentApplyId}`)
}

// 获取学历及学位
export function getEducationInfo (param) {
  return api.post(`find-talent-education-apply/${param.talentApplyId}`)
}

// 获取取得专业技术职称、职（执）业资格情况
export function getPracticeInfo (param) {
  return api.post(`find-talent-professional-technical-apply/${param.talentApplyId}`)
}

// 获取个人工作经历
export function getWorkExperience (param) {
  return api.post(`find-talent-work-experience-apply/${param.talentApplyId}`)
}

// 获取政治面貌（党派）情况
export function getPoliticalLandscapeInfo (param) {
  return api.post(`find-talent-political-apply/${param.talentApplyId}`)
}

// 获取年度考核情况
export function getAnnualAssessmentInfo (param) {
  return api.post(`find-talent-annual-check-apply/${param.talentApplyId}`)
}

// 获取荣誉称号（奖励）情况
export function getHonoraryTitleInfo (param) {
  return api.post(`find-talent-honor-apply/${param.talentApplyId}`)
}

// 获取荣获专家称号情况
export function getExpertTitleInfo (param) {
  return api.post(`find-talent-expert-apply/${param.talentApplyId}`)
}

// 获取惩戒（处分）情况
export function getDisciplinaryInfo (param) {
  return api.post(`find-talent-punishment-apply/${param.talentApplyId}`)
}

// 获取语言能力
export function getLanguageAbility (param) {
  return api.post(`find-talent-language-apply/${param.talentApplyId}`)
}

// 获取培训教育情况
export function getTrainingEducationInfo (param) {
  return api.post(`find-talent-train-apply/${param.talentApplyId}`)
}

// 获取主要论文及著作情况
export function getMainThesisInfo (param) {
  return api.post(`find-talent-publication-apply/${param.talentApplyId}`)
}

// 获取获得科研成果情况
export function getResearchResultInfo (param) {
  return api.post(`find-talent-achievement-apply/${param.talentApplyId}`)
}

// 获取获得专利情况
export function getPatentInfo (param) {
  return api.post(`find-talent-patent-apply/${param.talentApplyId}`)
}

// 获取参加学术团体情况
export function getAcademicBodyInfo (param) {
  return api.post(`find-talent-academy-apply/${param.talentApplyId}`)
}

// 获取培养研究生情况
export function getTrainGraduateStudentInfo (param) {
  return api.post(`find-talent-graduate-student-apply/${param.talentApplyId}`)
}

// 获取家庭成员及主要社会关系
export function getFamilyMember (param) {
  return api.post(`find-talent-family-member-apply/${param.talentApplyId}`)
}

// 审核
export function reviewTalent (param) {
  return api.post(`audit-talent-apply`, param)
}
