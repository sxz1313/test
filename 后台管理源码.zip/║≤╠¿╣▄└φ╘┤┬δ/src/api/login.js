import Api from '@/api/Api'

const api = new Api({
  path: 'v1/ht/'
})

// 登录
export function login (param) {
  return api.post(`login`, param)
}

// 获取加密公钥
export function getKey (param) {
  return api.get(`getKey`, param)
}

// 获取验证码图片
export function generateCode (param) {
  return api.get(`generate`, param)
}

// 退出登录
export function loginOut (param) {
  return api.get(`logout`, param)
}

// 获取用户信息
export function getLoginUser (param) {
  return api.get(`getLoginUser`, param)
}
