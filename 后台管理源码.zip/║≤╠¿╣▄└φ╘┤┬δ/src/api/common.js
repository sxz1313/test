/**
 * 公共服务api模块
 */
import Api from '@/api/Api'

const api = new Api({
  baseURL: process.env.VUE_APP_API_URL,
  path: ''
})
// const apiS = new Api({
//   baseURL: 'http://192.168.1.205:17576',
//   path: ''
// })
const APP_CODE = '1164461718124699652'

// 获取下拉列表值
export function reportDropList (type, param) {
  return api.get(`manage/report/getDownDropList/${type}`, param)
}
/**
 * 上传文件
 * @returns {*}
 */
export function fileUpload (data) {
  return api.postFormData(
    'v1/files/upload',
    data
  )
}
// 使用upload组件直接上传，返回id
export function uploadFileUrl () {
  return api.getBaseURL() + `v1/files/upload`
}
export function uploadFileUrlInfo () {
  return api.getBaseURL() + `v1/files/upload`
}
export function uploadFileUrl2 () {
  return api.getBaseURL() + `v1/files/upload2`
}
// 使用upload组件直接上传，返回url
export function uploadFileWithUrl () {
  return api.getBaseURL() + `sysFileInfo/uploadWithUrl`
}
// 文件下载
export function fileDownload (data) {
  return api.getBlob(
    'sysFileInfo/download',
    data
  )
}
// 多文件上传
export function uploadMultiple (data) {
  return api.post('file/uploadBatch?appCode=' + APP_CODE, data)
}
export function getUploadFileByIds (ids) {
  ids = ids.map(id => 'ids=' + id).join('&')
  return api.get('file/getFileInfoByIds?appCode=' + APP_CODE + '&' + ids)
}

export function downloadFileBolob (id) {
  return api.getBlob(`v1/bid-link/downloadFile/${id}`)
}
// 获取所有的省份信息
export function getProvinceList () {
  return api.get('region/provinces')
}
// 获取省份下的地市信息
export function getCityList (provinceCode) {
  return api.get(`region/provinces/${provinceCode}/cities`)
}
// 获取地市下的区县信息
export function getAreaList (cityCode) {
  return api.get(`region/cities/${cityCode}/areas`)
}

// 获取字典项
export function getDownList (param) {
  return api.get(`getDictNodes/${param.type}`)
}
export function queryByType (type) {
  return api.get(`v1/basic-data/queryByType`, type)
}
