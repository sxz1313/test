import Api from '@/api/Api'

const api = new Api({
  path: ''
})

const apiV1 = new Api({
  path: 'v1/'
})

// 获取角色分页列表
export function getRolePage (param) {
  return apiV1.get(`employee-role/getRoleList`, param)
}

// 新增角色
export function addRole (param) {
  return api.post(`sysRole/add`, param)
}

// 删除角色
export function delRole (param) {
  return api.post(`sysRole/delete`, param)
}

// 获取授权树
export function getRoleGrantTree (param) {
  return api.get(`sysMenu/treeForGrant`, param)
}

// 获取角色详情
export function getRoleDetail (param) {
  return api.get(`sysRole/detail`, param)
}

// 编辑角色
export function editRole (param) {
  return api.post(`sysRole/edit`, param)
}

// 获取用户分页列表
export function getUserPage (param) {
  return apiV1.get(`employee-role/employeePage`, param)
}

// 新增用户
export function addUser (param) {
  return apiV1.post(`employee-role/addEmployee`, param)
}

// 获取管理门店下拉
export function getAgencyList (param) {
  return apiV1.get(`agency/listxl`, param)
}

// 获取角色下拉列表
export function getRoleDownList (param) {
  return api.get(`sysRole/dropDown`, param)
}

// 获取部门下拉列表
export function getDepartmentDownList (param) {
  return api.get(`sysOrg/list`, param)
}

// 启用/停用用户
export function getUserDetail (param) {
  return apiV1.get(`employee-role/info/${param.id}`)
}

// 编辑用户
export function editUser (param) {
  return apiV1.post(`employee-role/editEmployee`, param)
}

// 删除用户
export function delUser (param) {
  return apiV1.del(`employee-role/deleteOne/${param.id}`)
}

// 启用/停用用户
export function changeUserStatus (param) {
  return apiV1.get(`employee-role/startOrStopUse`, param)
}

// 重置密码
export function resetPassword (param) {
  return apiV1.get(`employee-role/resetPassword`, param)
}

// 修改密码
export function editPassword (param) {
  return apiV1.get(`employee-role/modifyPassword`, param)
}

// 免责声明新增
export function saveDisclaimer (param) {
  return apiV1.post(`statement/add`, param)
}

// 免责声明详情
export function getDisclaimerDetail (param) {
  return apiV1.post(`statement/detail/${param.id}`)
}

// 获取院系机构树形列表
export function getAllDept (param) {
  return api.get(`v1/dept/allDept`, param)
}

// 获取部门成员
export function getDeptMember (param) {
  return api.get(`v1/dept/listMemberByDeptId`, param)
}

// 获取下级部门
export function getChildMember (param) {
  return api.get(`v1/dept/listChildrenDept`, param)
}

// 人员移动
export function moveUser (param) {
  return api.post(`v1/dept/moveUser`, param)
}

// 部门移动
export function moveDept (param) {
  return api.post(`v1/dept/moveDept`, param)
}

// 查询成员
export function getMemberList (param) {
  return api.get(`v1/dept/memberInfo`, param)
}

// 获取成员详情
export function getMemberDetail (param) {
  return api.get(`v1/dept/getMemberById`, param)
}

// 编辑成员
export function editMember (param) {
  return api.post(`v1/dept/updateMember`, param)
}

// 编辑部门
export function editDept (param) {
  return api.post(`v1/dept/updateDept`, param)
}

// 部门-设置负责人
export function setHeader (param) {
  return api.post(`v1/dept/setHeader`, param)
}

// 部门-人员离职
export function memberLevel (param) {
  return api.post(`v1/dept/leave`, param)
}

// 获取部门详情
export function getDeptDetail (param) {
  return api.get(`v1/dept/getDeptById`, param)
}

// 创建下级部门
export function addChildDept (param) {
  return api.post(`v1/dept/createDept`, param)
}

// 删除下级部门
export function delChildDept (param) {
  return api.del(`v1/dept/removeDept`, param)
}

// 获取角色列表
export function getRoleList (param) {
  return api.get(`v1/role/listAllRole`, param)
}

// 获取用户关联区域树形列表
export function getUserDept (param) {
  return api.get(`v1/bid-link/getUserDeptIds`, param)
}

/**
 * 字典项
 */
// 系统字典根据类型id获取所有字典条目内容
export function dictDataById (dictTypeId, param) {
  return api.get(`dictData/list/${dictTypeId}`, param)
}
// 保存字典条目内容
export function saveDictData (dictTypeId, param) {
  return api.post(`dictData/save/${dictTypeId}`, param)
}
// 系统字典查询
export function dictDataList (param) {
  return api.get('sysDictType/dictPage', param)
}
export function dictTypeSave (param) {
  return api.post('dictType/save', param)
}
