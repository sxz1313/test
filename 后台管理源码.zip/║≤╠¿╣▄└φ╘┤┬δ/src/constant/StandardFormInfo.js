/**
 * @abstract
 * 表单数据抽象类
 */
import Vue from 'vue'
import { ExtractAscOrZhChart, ExtractIp, ExtractNameNumber, ExtractTel, ExtractPwd } from '@/utils/index'

export default class StandardFormInfo {
  /**
   * 必填属性检验
   */
  isValidRequireProps () {
  }

  /**
   * 为api发送合适格式的数据
   */
  apiFormat () {
  }

  // 正整数
  limitPInteger (key, val, max) {
    val = Math.abs(parseInt(val))
    if (val > max) {
      val = parseInt(val / 10)
      Vue.prototype.warning('输入值大于 ' + max)
    }
    this[key] = val
  }

  // 正小数
  limitPFloat (key, val) {
    this[key] = Math.abs(parseFloat(val))
  }

  /**
   * 提取a-zA-Z_-和中文
   * @param val
   * @returns {*}
   */
  limitAscOrZh (key, val) {
    this[key] = (val.match(ExtractAscOrZhChart) || [''])[0]
  }

  /**
   * 提取a-zA-Z_-
   * @param val
   * @returns {*}
   */
  limitNumberName (key, val) {
    this[key] = (val.match(ExtractNameNumber) || [''])[0]
  }

  /**
   * 提取电话
   * @param val
   * @returns {*|string}
   */
  limitTel (key, val) {
    this[key] = (val.match(ExtractTel) || [''])[0]
  }

  /**
   * 提取ip
   * @param val
   * @returns {*}
   */
  limitIp (key, val) {
    this[key] = (val.match(ExtractIp) || [''])[0]
  }

  /**
   * 提取密码
   * @param val
   * @returns {*}
   */
  limitPwd (key, val) {
    this[key] = (val.match(ExtractPwd) || [''])[0]
  }
}
