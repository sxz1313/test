import BaseController from '@/controller/BaseController'
export default class User extends BaseController {
  /**
   * 自动登录标示
   */
  static isAutoLogin = false
  static get (key) {
    return this.isAutoLogin ? window.localStorage.getItem(key) : window.sessionStorage.getItem(key)
  }

  static set (key, value) {
    if (this.isAutoLogin) {
      return window.localStorage.setItem(key, value)
    } else {
      return window.sessionStorage.setItem(key, value)
    }
  }

  static setObject (obj) {
    for (const i in obj) {
      this.set(i, obj[i])
    }
  }

  static get isNotLogin () {
    return !this.token
  }

  static get headIcon () {
    return this.get('headIcon')
  }

  static get userId () {
    return this.get('userId')
  }

  static get deptId () {
    return this.get('deptId')
  }

  static get token () {
    return this.get('token') || ''
  }

  static get name () {
    return this.get('name')
  }

  static get deptName () {
    return this.get('deptName')
  }
  static get studentInfo () {
    return this.get('studentInfo')
  }
  static get type () {
    return this.get('type')
  }
  static get phone () {
    return this.get('phone')
  }
  static get ids () {
    return this.get('ids')
  }

  static clear () {
    this.isAutoLogin ? this.localStorageClear() : this.sessionClear()
  }
  static localStorageClear () {
    window.localStorage.clear()
  }
  static sessionClear () {
    window.sessionStorage.clear()
  }
}
