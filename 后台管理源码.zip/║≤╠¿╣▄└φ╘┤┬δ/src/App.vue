<template>
  <div id="app">
    <router-view v-if="isLogin" />
    <el-row v-else class="campus">
      <el-col class="main">
        <left-nav
          :menu-list="subMenu"
          :default-active="defaultActive"
          :default-open-key="defaultOpenKey"
        />
        <div class="content-container">
          <Headers />
          <div class="content-title">
            <view-path v-show="!isShowView" />
            <span v-show="isShowView">首页</span>
          </div>
          <el-col :span="24" style="min-width: 910px;padding: 0 20px;">
            <transition name="fade-transform" mode="out-in">
              <router-view />
            </transition>
          </el-col>
        </div>
      </el-col>
    </el-row>
  </div>
</template>

<script>
import Headers from '@/components/header/index'
import LeftNav from '@/components/leftNav/index'
import ViewPath from '@/components/viewPath/ViewPath'
export default {
  name: 'App',
  components: {
    Headers,
    LeftNav,
    ViewPath
  },
  data () {
    return {
      subMenu: [],
      defaultActive: '', // 默认样式
      defaultOpenKey: [], // 默认展开的导航
      isLogin: true,
      isShowView: true
    }
  },
  watch: {
    $route: function (to, from) {
      this.isLogin = to.name === 'login' || to.name === 'register'
      this.isShowView = to.name === 'desktop'
      this.subMenu = []
      this.subMenu = this.getSubMenu(to.meta.module)
      if (to.meta.module !== from.meta.module && !this.isShowView) {
        this.defaultOpenKey = [this.subMenu[0].name]
      }
      if (to.meta.menuShow) {
        this.defaultActive = to.name
      } else {
        this.defaultActive = to.meta.activeMenu
      }
    }
  },
  created () {
    // window.location.reload()
  },
  methods: {
    // 侧边栏菜单
    getSubMenu (val) {
      return (this.$router.options.routes || []).filter((item) => {
        assert(
          Object.prototype.toString(item.meta) === '[object Object]',
          new Error('meta 应该是一个对象')
        )
        return item.meta && val === item.meta.module && item.meta.menuShow
      })
    }
  }
}
</script>
<style lang="scss" scoped>
.campus {
  position: absolute;
  top: 0px;
  bottom: 0px;
  left: 0px;
  width: 100%;
  background-color: #f0f0f0;

  .main {
    position: absolute;
    top: 0px;
    bottom: 0px;
    display: flex;
    overflow: hidden;

    .content-container {
      flex: 1;
      overflow-y: auto;
      box-sizing: border-box;
      font-size: 14px;
      color: #666;

      .content-title {
        min-width: 910px;
        background-color: #ffffff;
        margin: -80px 20px 0;
        border-radius: 10px 10px 0 0;
        padding: 30px;
        line-height: 20px;
      }
    }
  }
}
</style>
