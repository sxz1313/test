import Vue from 'vue'
import 'babel-polyfill'
import App from './App.vue'
import router from './routes'
import ElementUI from 'element-ui'
import './assets/index.scss'
import '@/directives'
import permCode from './directives/permCode'

window.Vue = Vue
import DateFormat from '@/utils/DateFormat'
import { dateFormatting, fmoney } from '@/utils/index'

import store from '@/store'
import echarts from 'echarts'
Vue.prototype.$echarts = echarts

import User from '@/controller/User'
Vue.prototype.$user = User

Vue.config.productionTip = false
Vue.config.errorHandler = function (err, vm, info) {
  // eslint-disable-next-line no-console
  console.log('global error handler: ', err, vm, info)
}
Vue.use(ElementUI, { size: 'small' })
Vue.use(permCode)
Vue.prototype.$format = DateFormat.format
Vue.prototype.$dateFormatting = dateFormatting
Vue.prototype.$fmoney = fmoney
Vue.filter('dateFormat', (value, pattern = 'yyyy-MM-dd HH:mm:ss') => {
  return DateFormat.format(value, pattern)
})

new Vue({
  render: (h) => h(App),
  router,
  store
}).$mount('#app')

// eslint-disable-next-line no-console
const log = console.log
window.console.log = function (...message) {
  if (process.env.NODE_ENV !== 'production') {
    log(...message)
  }
}

window.assert = function (isTure, msg = '') {
  if (process.env.NODE_ENV !== 'production') {
    if (!isTure) {
      // console.error(msg)
    }
  }
}
