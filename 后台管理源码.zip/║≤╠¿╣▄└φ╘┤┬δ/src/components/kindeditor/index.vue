
<template>
  <div>
    <textarea :id="id" v-model="outContent" name="content" />
    <input
      id="inputFile"
      :ref="id"
      style="visibility: hidden;height:0;"
      type="file"
      name
      @change="selectedFile"
    >
  </div>
</template>
<script>
import * as api from '@/api/common'
import 'kindeditor/themes/default/default.css'
import 'kindeditor/kindeditor-all.js'
import 'kindeditor/lang/zh-CN.js'

// 以下四个配置文件见下文
import items from './config/items'
import htmlTags from './config/htmlTags'
import fontSizeTable from './config/fontSizeTable'
import otherConfig from './config/otherConfig'

export default {
  name: 'KindEditor',
  props: {
    // 编辑器内容 url
    html: {
      type: String,
      default: ''
    },
    // 编辑器内容
    content: {
      type: String,
      default: ''
    },
    // 编辑器id
    id: {
      type: String,
      // required: true,
      default: 'kindeditor-id'
    },
    // 宽
    width: {
      type: String,
      default: `100%`
    },
    // 高
    height: {
      type: String,
      default: '400'
    },
    // 最小宽
    minWidth: {
      type: Number,
      default: 650
    },
    // 最小高
    minHeight: {
      type: Number,
      default: 400
    },
    // toolbar 工具栏配置
    items: {
      type: Array,
      default: function () {
        return [...items]
      }
    },
    // 标签配置
    htmlTags: {
      type: Object,
      default: function () {
        return { ...htmlTags }
      }
    },
    // 字号配置
    fontSizeTable: {
      type: Array,
      default: function () {
        return [...fontSizeTable]
      }
    },
    // 语言配置
    langType: {
      type: String,
      default: 'zh-CN'
    },
    // 主题配置
    themeType: {
      type: String,
      default: 'default'
    },
    // body 的样式
    bodyClass: {
      type: String,
      default: 'ke-content'
    },
    // 其他配置项
    ...otherConfig
  },
  data () {
    return {
      editor: null,
      outContent: this.content
    }
  },

  watch: {
    content (val) {
      this.editor && val !== this.outContent && this.editor.html(val)
    },
    // 分发编辑器内容改变事件
    outContent (val) {
      this.$emit('update:content', val)
      this.$emit('on-content-change', val)
      this.$emit('input', val)
    },
    // 初始化编辑器内容
    html (val) {
      this.outContent = val
      this.editor.html(val)
    }
  },
  created () {
    this.outContent = this.html
    // this.editor.html(this.outContent)
  },
  mounted () {
    // 初始访问时创建
    this.initEditor()
    //  添加焦点
    // this.editor.focus();
    // 添加点击图片回调函数
    this.editor.clickToolbar('image', () => {
      this.editor.hideDialog() // 禁用自带的图片弹窗
      setTimeout(() => {
        this.editor.hideDialog()
      }, 0)
      this.handleOpenFile() // 打开文件
    })
  },
  activated () {
    // keep-alive 进入时创建
    this.initEditor()
  },
  deactivated () {
    // keep-alive 离开时移除
    this.removeEditor()
  },
  beforeDestroy () {
    // 实例销毁之前移除
    this.removeEditor()
  },
  methods: {
    // 打开文件
    handleOpenFile () {
      const input = this.$refs[this.id]
      // 解决同一个文件不能监听的问题
      input.addEventListener(
        'click',
        function () {
          this.value = ''
        },
        false
      )
      // 点击input
      input.click()
    },
    // 选择好文件
    selectedFile ($event) {
      const file = $event.target.files[0]
      const blob = new FormData()
      blob.append('file', file)
      blob.append('resultType', 1)
      api.fileUpload(blob).then(({ data }) => {
        // 调用appendHtml方法把图片追加到富文本
        if (file.type === 'image/png' || file.type === 'image/jpg' || file.type === 'image/jpeg') {
          this.editor.appendHtml(
            `<img style="max-width:100%;" src="${process.env.VUE_APP_IMG_API}${data.data.fileUrl}">`
          )
        } else {
          this.editor.appendHtml(
            `<a href="${process.env.VUE_APP_IMG_API}${data.data.fileUrl}" download="${data.data.fileName}"> ${data.data.fileName} </a>`
          )
        }
      })
    },
    // 移除编辑器实例
    removeEditor () {
      window.KindEditor.remove(`#${this.id}`)
    },
    // 初始化编辑器
    initEditor () {
      this.removeEditor()
      this.editor = window.KindEditor.create('#' + this.id, {
        width: this.width,
        height: this.height,
        minWidth: this.minWidth,
        minHeight: this.minHeight,
        items: this.items,
        noDisableItems: this.noDisableItems,
        filterMode: this.filterMode,
        htmlTags: this.htmlTags,
        wellFormatMode: this.wellFormatMode,
        resizeType: this.resizeType,
        themeType: this.themeType,
        langType: this.langType,
        designMode: this.designMode,
        fullscreenMode: this.fullscreenMode,
        basePath: this.basePath,
        themesPath: this.themesPath,
        pluginsPath: this.pluginsPath,
        langPath: this.langPath,
        minChangeSize: this.minChangeSize,
        loadStyleMode: this.loadStyleMode,
        urlType: this.urlType,
        newlineTag: this.newlineTag,
        pasteType: this.pasteType,
        dialogAlignType: this.dialogAlignType,
        shadowMode: this.shadowMode,
        zIndex: this.zIndex,
        useContextmenu: this.useContextmenu,
        syncType: this.syncType,
        indentChar: this.indentChar,
        cssPath: this.cssPath,
        cssData: this.cssData,
        bodyClass: this.bodyClass,
        colorTable: this.colorTable,
        afterCreate: this.afterCreate,
        // 编辑器内容改变回调
        afterChange: () => {
          this.editor ? (this.outContent = this.editor.html()) : ''
        },
        afterTab: this.afterTab,
        afterFocus: this.afterFocus,
        afterBlur: this.afterBlur,
        afterUpload: this.afterUpload,
        uploadJson: this.uploadJson,
        fileManagerJson: this.fileManagerJson,
        allowPreviewEmoticons: this.allowPreviewEmoticons,
        allowImageUpload: false,
        allowFlashUpload: this.allowFlashUpload,
        allowMediaUpload: this.allowMediaUpload,
        allowFileUpload: this.allowFileUpload,
        allowFileManager: this.allowFileManager,
        fontSizeTable: this.fontSizeTable,
        imageTabIndex: this.imageTabIndex,
        formatUploadUrl: this.formatUploadUrl,
        fullscreenShortcut: this.fullscreenShortcut,
        extraFileUploadParams: this.extraFileUploadParams,
        filePostName: this.filePostName,
        fillDescAfterUploadImage: this.fillDescAfterUploadImage,
        afterSelectFile: this.afterSelectFile,
        pagebreakHtml: this.pagebreakHtml,
        allowImageRemote: true,
        autoHeightMode: this.autoHeightMode,
        fixToolBar: this.fixToolBar,
        tabIndex: this.tabIndex
      })
    }
  }
}
</script>

<style>
</style>
