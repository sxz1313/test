// 字体配置
const fontSizeTable = [
  '9px',
  '10px',
  '12px',
  '14px',
  '16px',
  '18px',
  '24px',
  '32px'
]
export default fontSizeTable
