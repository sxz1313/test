<template>
  <el-table
    :data="tableData"
    style="width: 100%"
    highlight-current-row
    fit
  >
    <el-table-column v-slot="{row}" align="center" width="30">
      <el-radio
        v-model="templateRadio"
        :label="row.id"
        @change="$emit('radio-change', row)"
      >&nbsp;</el-radio>
    </el-table-column>
    <el-table-column
      label="序号"
      align="center"
      type="index"
      width="55"
    >
      <template slot-scope="scope">
        <span v-if="isShow">{{ scope.$index+(pageParam.pageNo - 1) * pageParam.pageSize + 1 }} </span>
        <span v-else>{{ scope.$index + 1 }}</span>
      </template>
    </el-table-column>
    <el-table-column
      v-for="(item, index) in tableHead"
      :key="index"
      :prop="item.prop"
      align="center"
      :label="item.label"
      :sortable="item.sortable ? 'custom' : false"
      show-overflow-tooltip
    />
    <el-table-column
      v-if="isShowOperate && isAuth"
      label="操作"
      align="center"
      width="120"
    >
      <template slot-scope="scope">
        <slot :scope="scope.row" name="button" />
      </template>
    </el-table-column>
  </el-table>
</template>
<script>
import User from '@/controller/User'
export default {
  name: 'TableRadio',
  props: {
    headList: {
      type: Object,
      default: () => { [] }
    },
    tableList: {
      type: Object,
      default: () => { [] }
    },
    isShowOperate: {
      type: Boolean,
      default: true
    },
    isPagination: {
      type: Boolean,
      default: true
    },
    filter: {
      type: Object,
      default: () => {}
    },
    authId: {
      type: String,
      default: ''
    }
  },
  data () {
    return {
      templateRadio: ''
    }
  },
  computed: {
    tableHead () {
      return this.headList
    },
    tableData () {
      return this.tableList
    },
    pageParam () {
      return this.filter
    },
    tableHeight () {
      return this.height
    },
    isShow () {
      return this.isPagination
    },
    isAuth () {
      return !this.authId || (this.authId.split(',') || []).some(ele => JSON.parse(User.get('ids')).includes(ele))
      // return true
    }
  },
  created () {
  },
  methods: {
    clearRadio () {
      this.templateRadio = ''
    }
  }
}
</script>
<style lang="scss" scoped>

</style>
