<template>
  <div>
    <el-table
      :data="tableData"
      style="width: 100%"
      :height="tableHeight ? tableHeight : auto"
    >
      <el-table-column
        label="序号"
        align="center"
        type="index"
        width="55"
      >
        <template slot-scope="scope">
          <span>{{ scope.$index + 1 }}</span>
        </template>
      </el-table-column>
      <el-table-column
        v-for="(item, index) in tableHead"
        :key="index"
        :prop="item.prop"
        align="center"
        :label="item.label"
        :width="item.width"
        show-overflow-tooltip
      >
        <template slot-scope="scope">
          <el-date-picker
            v-if="item.isDateSelect"
            v-model="scope.row[item.prop]"
            type="date"
            placeholder="选择日期"
            value-format="timestamp"
            :disabled="isOperate"
            :clearable="false"
            :picker-options="pickerOptions"
            @change="selectChange(scope.row)"
          />
          <el-input-number
            v-else-if="item.isInputNumber"
            v-model="scope.row[item.prop]"
            :min="1"
            :max="scope.row.max || 1000000"
            clearable
            :disabled="isOperate"
            @change="selectChange(scope.row)"
          />
          <el-select
            v-else-if="item.isNormalSelect"
            v-model="scope.row[item.prop]"
            filterable
            class="w140"
            :disabled="isOperate"
            @change="selectChange(scope.row)"
          >
            <el-option
              v-for="(ele, i) in sceneList"
              :key="i"
              :label="ele"
              :value="ele"
            />
          </el-select>
          <el-select
            v-else-if="item.isMutipleSelect"
            ref="isMutipleSelect"
            v-model="scope.row[item.prop]"
            multiple
            filterable
            :disabled="isOperate"
            @remove-tag="removeChange"
            @change="selectChange($event, scope.$index)"
            @visible-change="onVisibleChange($event, scope.row[item.prop])"
          >
            <el-option
              v-for="(ele, i) in sceneList"
              :key="i"
              :label="ele.name"
              :value="ele.id"
              :disabled="ele.disabled"
            />
          </el-select>
          <span v-else>{{ scope.row[item.prop] }}</span>
        </template>
      </el-table-column>
      <el-table-column
        v-if="isShowOperate && isAuth"
        label="操作"
        align="center"
        width="120"
      >
        <template slot-scope="scope">
          <slot :scope="scope" name="button" />
        </template>
      </el-table-column>
    </el-table>
  </div>
</template>
<script>
import User from '@/controller/User'
export default {
  name: 'TableSelect',
  props: {
    headList: {
      type: Object,
      default: () => {
        []
      }
    },
    tableList: {
      type: Object,
      default: () => {
        []
      }
    },
    filter: {
      type: Object,
      default: () => {}
    },
    isDateSelect: {
      type: Boolean,
      default: false
    },
    isNormalSelect: {
      type: Boolean,
      default: false
    },
    dateLimit: {
      type: Object,
      default: () => {
        []
      }
    },
    scene: {
      type: Object,
      default: () => {
        []
      }
    },
    height: {
      type: String,
      default: ''
    },
    isShowOperate: {
      type: Boolean,
      default: true
    },
    isDisabled: {
      type: Boolean,
      default: false
    },
    authId: {
      type: String,
      default: ''
    }
  },
  data () {
    return {
      pickerOptions: {
        disabledDate: (time) => {
          return this.dealPickDate(time)
        }
      }
    }
  },
  computed: {
    tableHead () {
      return this.headList
    },
    tableData () {
      return this.tableList
    },
    pageParam () {
      return this.filter
    },
    sceneList () {
      return this.scene
    },
    tableHeight () {
      return this.height
    },
    limitDate () {
      return this.limitDate
    },
    isMultiple () {
      return this.multiple
    },
    isOperate () {
      return this.isDisabled
    },
    isAuth () {
      return !this.authId || (this.authId.split(',') || []).some(ele => JSON.parse(User.get('ids')).includes(ele))
      // return true
    }
  },
  watch: {},
  created () {},
  methods: {
    selectChange (ele, index) {
      this.$emit('on-select', ele)
      if (
        !this.$refs.isMutipleSelect ||
				this.$refs.isMutipleSelect.length === 0
      ) {
        return
      }
      setTimeout(() => {
        this.$refs.isMutipleSelect[index].blur()
      }, 50)
    },
    removeChange (ele, index) {
      this.$emit('on-remove', ele)
    },
    onVisibleChange (ele, row) {
      this.$emit('on-visible-change', ele, row)
    },
    // 可选时间范围
    dealPickDate (time) {
      const maxDate = this.dateLimit.length > 0 ? this.dateLimit[1] : ''
      const minDate = this.dateLimit.length > 0 ? this.dateLimit[0] : ''
      if (maxDate && minDate) {
        return time.getTime() < minDate || time.getTime() > maxDate
      }
      if (maxDate && !minDate) {
        return time.getTime() > maxDate
      }
      if (minDate && !maxDate) {
        return time.getTime() < minDate
      }
    }
  }
}
</script>
<style lang="scss" scoped></style>
