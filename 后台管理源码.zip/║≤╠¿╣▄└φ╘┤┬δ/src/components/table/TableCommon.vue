<template>
  <el-table
    :data="tableData"
    :border="border"
    :height="tableHeight ? tableHeight : auto"
    style="width: 100%"
    :header-cell-style="{ 'text-align': 'center' }"
    :cell-class-name="setCellClassName"
    @sort-change="tableSortChange"
  >
    <el-table-column
      v-if="indexState"
      label="序号"
      align="center"
      type="index"
      width="55"
    >
      <template slot-scope="scope">
        <span
          v-if="isShowPagination"
        >{{ scope.$index + (pageParam.pageNo - 1) * pageParam.pageSize + 1 }}
        </span>
        <span v-else>{{ scope.$index + 1 }}</span>
      </template>
    </el-table-column>
    <el-table-column
      v-for="(item, index) in tableHead"
      :key="index"
      :prop="item.prop"
      :align="item.align ? item.align : 'center'"
      :label="item.label"
      :sortable="item.sortable ? 'custom' : false"
      :min-width="item.width ? item.width : 120"
      :fixed="item.fixed"
      :show-overflow-tooltip="!item.showOverflowTooltip"
    >
      <!-- :class-name="item.prop === 'assignTimeText' ? 'text-color-red' : ''" -->
      <template slot-scope="scope">
        <img v-if="item.image" :src="scope.row[item.prop]" class="innerImage">
        <span v-if="item.link">{{ scope.row[item.prop] }}
          <el-button type="text" @click="copyLink(scope.row[item.prop])">复制</el-button>
        </span>
        <el-button
          v-if="item.QrCode"
          type="text"
          @click="handlePreview(scope.row[item.prop])"
        >
          查看
        </el-button>
        <span v-if="!item.QrCode && !item.image && !item.link">{{
          scope.row[item.prop]
        }}</span>
      </template>
    </el-table-column>
    <slot name="unique" />
    <el-table-column
      v-if="isShowOperate && isAuth"
      :label="isShowOperateText?'操作':''"
      align="center"
      :width="operateWidth"
      fixed="right"
    >
      <template slot-scope="scope">
        <slot :scope="scope.row" :index="scope.$index" name="button" />
      </template>
    </el-table-column>
  </el-table>
</template>
<script>
import User from '@/controller/User'
export default {
  name: 'TableCommon',
  props: {
    headList: {
      type: Object,
      default: () => {
        []
      }
    },
    tableList: {
      type: Object,
      default: () => {
        []
      }
    },
    filter: {
      type: Object,
      default: () => {}
    },
    indexState: {
      type: Boolean,
      default: true
    },
    isShowheadPortrait: {
      type: Boolean,
      default: false
    },
    isShowstate: {
      type: Boolean,
      default: false
    },
    isShowhomeage: {
      type: Boolean,
      default: false
    },
    isPagination: {
      type: Boolean,
      default: true
    },
    isShowOperate: {
      type: Boolean,
      default: true
    },
    isShowOperateText: {
      type: Boolean,
      default: true
    },
    operateWidth: {
      type: Number,
      default: 120
    },
    isWidtch: {
      type: Boolean,
      default: false
    },
    height: {
      type: String,
      default: ''
    },
    isFixed: {
      type: Boolean,
      default: false
    },
    authId: {
      type: String,
      default: ''
    },
    border: {
      type: Boolean,
      default: false
    }
  },
  data () {
    return {}
  },
  computed: {
    tableHead () {
      return this.headList
    },
    tableData () {
      return this.tableList
    },
    pageParam () {
      return this.filter
    },
    isShowPagination () {
      return this.isPagination
    },
    tableHeight () {
      return this.height
    },
    isShowIndex () {
      return this.indexState
    },
    isAuth () {
      return !this.authId || (this.authId.split(',') || []).some(ele => JSON.parse(User.get('ids')).includes(ele))
      // return true
    }
  },
  created () {},
  methods: {
    copyLink (link) {
      this.$emit('copy', link)
    },
    setCellClassName ({ row, column, rowIndex, columnIndex }) {
      if (
        row.serviceStatus === 3 &&
        column.property === 'assignTimeText' &&
        row.assignTimeOver12HNotAccept
      ) {
        return 'text-color-red'
      }
    },
    tableSortChange (column) {
      this.$emit('order', column)
    },
    handlePreview (ele) {
      window.open(ele)
    }
  }
}
</script>
<style lang="scss" scoped>
.cellSpanWrap {
  display: inline-block;
  text-overflow: ellipsis;
  overflow: hidden;
  white-space: nowrap;
  width: 120px;
}
.innerImage {
  width: 50px;
  height: 50px;
}
.el-table /deep/ {
  .text-color-red {
    color: red;
  }
}
</style>
