<template>
  <el-table
    ref="multipleTable"
    :data="tableData"
    :row-key="row => {return row.id; }"
    style="width: 100%"
    :height="tableHeight ? tableHeight : auto"
    @selection-change="handleSelectionChange"
    @select="handleSelection"
  >
    <el-table-column
      type="selection"
      :selectable="selectionDisabled"
      :reserve-selection="true"
      align="center"
      width="55"
    />
    <el-table-column
      v-for="(item, index) in tableHead"
      :key="index"
      :prop="item.prop"
      align="center"
      :label="item.label"
      :min-width="item.width?item.width:auto"
      show-overflow-tooltip
    >
      <template slot-scope="scope">
        <slot
          v-if="item.name"
          :name="scope.column.property"
          :row="scope.row"
          :$index="scope.$index"
        />
        <span v-else>
          <!-- 状态 -->
          <div v-if="isShowstate&&scope.column.property=='state'&&scope.row[scope.column.property]">
            <span class="Tipsicon Tips-red" />
            {{ scope.row[scope.column.property] }}
          </div>
          <div v-else>
            {{ scope.row[scope.column.property] }}
          </div>
        </span>
      </template>
    </el-table-column>
    <el-table-column
      v-if="isShowOperate && isAuth"
      label="操作"
      align="center"
      width="120"
    >
      <template slot-scope="scope">
        <slot :scope="scope.row" name="button" />
      </template>
    </el-table-column>
  </el-table>
</template>
<script>
import User from '@/controller/User'
export default {
  name: 'TableSelection',
  props: {
    headList: {
      type: Object,
      default: () => { [] }
    },
    tableList: {
      type: Object,
      default: () => { [] }
    },
    isShowstate: {
      type: Boolean,
      default: true
    },
    isShowOperate: {
      type: Boolean,
      default: true
    },
    selectionDisabled: {
      type: Function,
      default: () => { return true }
    },
    height: {
      type: String,
      default: ''
    },
    authId: {
      type: String,
      default: ''
    }
  },
  data () {
    return {
    }
  },
  computed: {
    tableHead () {
      return this.headList
    },
    tableData () {
      return this.tableList
    },
    tableHeight () {
      return this.height
    },
    isAuth () {
      return !this.authId || (this.authId.split(',') || []).some(ele => JSON.parse(User.get('ids')).includes(ele))
      // return true
    }
  },
  created () {
  },
  methods: {
    // 批量选择改变
    handleSelectionChange (val) {
      this.handleSelection(val)
    },
    // 批量选择
    handleSelection (selection) {
      const obj = {}
      selection = selection.filter(item =>
        obj[item.id] ? '' : (obj[item.id] = true)
      )
      this.$emit('handleSelection', selection)
    },
    clearSelect () {
      this.$refs.multipleTable.clearSelection()
    },
    // 父组件调用子组件-->checkBox回显操作
    feedBack (selected) {
      if (selected.length === 0) return;
      (selected || []).forEach((item) => {
        this.$refs.multipleTable.toggleRowSelection(item, true)
      })
    }
  }
}
</script>
<style lang="scss" scoped>

</style>
