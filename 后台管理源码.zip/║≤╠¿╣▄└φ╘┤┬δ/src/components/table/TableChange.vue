<template>
  <div>
    <el-table
      :data="tableData"
      :height="tableHeight ? tableHeight : auto "
      style="width: 100%"
      @sort-change="tableSortChange"
    >
      <el-table-column
        v-if="indexState"
        label="序号"
        align="center"
        width="55"
      >
        <template slot-scope="scope">
          <span v-if="isShow">{{ scope.$index+(pageParam.pageNo - 1) * pageParam.pageSize + 1 }} </span>
          <span v-else-if="scope.$index+1 === tableData.length" />
          <span v-else>{{ scope.$index + 1 }}</span>
        </template>
      </el-table-column>
      <el-table-column
        v-for="(item, index) in tableHead"
        :key="index"
        :prop="item.key"
        align="center"
        :label="item.value"
        :min-width="item.width?item.width:120"
        show-overflow-tooltip
      >
        <template slot-scope="scope">
          <template v-for="s in scope.row">
            <span v-if="s.key === item.key" :key="s.key">{{ s.value }}</span>
          </template>
        </template>
      </el-table-column>
      <el-table-column
        v-if="isShowOperate && isAuth"
        label="操作"
        align="center"
        width="220"
      >
        <template slot-scope="scope">
          <slot :scope="scope.row" name="button" />
        </template>
      </el-table-column>
    </el-table>
  </div>
</template>
<script>
import User from '@/controller/User'
export default {
  name: 'TableCommon',
  props: {
    headList: {
      type: Object,
      default: () => { [] }
    },
    tableList: {
      type: Object,
      default: () => { [] }
    },
    filter: {
      type: Object,
      default: () => {}
    },
    indexState: {
      type: Boolean,
      default: true
    },
    isPagination: {
      type: Boolean,
      default: true
    },
    isShowOperate: {
      type: Boolean,
      default: true
    },
    height: {
      type: String,
      default: ''
    },
    authId: {
      type: String,
      default: ''
    }
  },
  data () {
    return {

    }
  },
  computed: {
    tableHead () {
      return this.headList
    },
    tableData () {
      return this.tableList
    },
    pageParam () {
      return this.filter
    },
    isShow () {
      return this.isPagination
    },
    tableHeight () {
      return this.height
    },
    isAuth () {
      return !this.authId || (this.authId.split(',') || []).some(ele => JSON.parse(User.get('ids')).includes(ele))
      // return true
    }
  },
  created () {
  },
  methods: {
    tableSortChange (column) {
      this.$emit('order', column)
    }
  }
}
</script>
<style lang="scss" scoped>
  .cellSpanWrap{
    display: inline-block;
    text-overflow: ellipsis;
    overflow: hidden;
    white-space: nowrap;
    width: 120px;
  }
</style>
