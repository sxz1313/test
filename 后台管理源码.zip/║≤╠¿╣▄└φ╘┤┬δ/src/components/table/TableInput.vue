<template>
  <div>
    <el-table
      :data="tableData"
      style="width: 100%"
    >
      <el-table-column
        label="序号"
        align="center"
        type="index"
        width="55"
      >
        <template slot-scope="scope">
          <span>{{ scope.$index + 1 }}</span>
        </template>
      </el-table-column>
      <el-table-column
        v-for="(item, index) in tableHead"
        :key="index"
        :prop="item.prop"
        align="center"
        :label="item.label"
        show-overflow-tooltip
      >
        <template slot-scope="scope">
          <el-input
            v-if="isShow && item.prop !== 'id'"
            v-model.trim="scope.row[item.prop]"
            maxlength="30"
            clearable
            @input="inputChange(scope.row, item.isNum, scope)"
          />
          <span v-else>{{ scope.row[item.prop] }}</span>
        </template>
      </el-table-column>
      <el-table-column
        v-if="isShow"
        label="操作"
        align="center"
        :width="operateWidth"
      >
        <template slot-scope="scope">
          <slot :scope="scope" name="button" />
        </template>
      </el-table-column>
    </el-table>
  </div>
</template>
<script>

export default {
  name: 'TableCommon',
  props: {
    headList: {
      type: Object,
      default: () => { [] }
    },
    tableList: {
      type: Object,
      default: () => { [] }
    },
    filter: {
      type: Object,
      default: () => {}
    },
    operateWidth: {
      type: Number,
      default: 120
    },
    isEdit: {
      type: Boolean,
      default: true
    }
  },
  data () {
    return {

    }
  },
  computed: {
    tableHead () {
      return this.headList
    },
    tableData () {
      return this.tableList
    },
    pageParam () {
      return this.filter
    },
    isShow () {
      return this.isEdit
    }
  },
  created () {
  },
  methods: {
    inputChange (ele, isNUm, scope) {
      if (isNUm) {
        ele.sort = ele['sort'].replace(/[^\d]/gi, '')
        ele.code = ele['code'].replace(/[^\d]/gi, '')
      }
      this.$emit('on-input', ele, scope)
    }
  }
}
</script>
<style lang="scss" scoped>

</style>
