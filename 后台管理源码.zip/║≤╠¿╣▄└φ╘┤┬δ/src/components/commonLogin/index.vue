<template>
  <div class="commonLogin">
    <h1>人才协会信息录入系统</h1>
    <div class="content">
      <slot />
    </div>
    <p v-if="false" class="record" @click="to">淮北悟到车联科技有限公司 皖ICP备2022006853号</p>
  </div>
</template>
<script>
export default {
  methods: {
  }
}
</script>
<style lang='scss' scoped>
.commonLogin{
  background: url("../../assets/img/login.png") no-repeat center center;
  height: 50vh;
  h1{
    padding: 100px 0;
    font-size:60px;
    color:rgba(255,255,255,1);
    letter-spacing: 10px;
    text-align: center;
  }
  .content{
    text-align: center;
    margin: 0 auto;
    background-color: #fff;
    width: 40%;
    padding: 50px 60px;
    border-radius: 5px;
    border: 1px solid #ccc;
    box-shadow:2px 2px 5px #333333;
    p{
      font-size:20px;
      color:rgba(23,120,210,1);
      text-align: left;
    }
    .loginInput{
      margin: 0 auto;
      padding: 10px 0;
      width: 50%;
      display: flex;
      justify-content: space-between;
      .innerInput{
        width: 60%;
      }
      .verCode{
        width: 30%;
        cursor: pointer;
      }
    }
    .submitBtn{
      width: 50%;
      margin: 20 auto;
      margin-top: 20px;
      margin-bottom: 20px;
      text-align: center;
    }
    .operate{
      text-align: center;
      width: 50%;
      display: flex;
      justify-content: space-between;
      margin: 0 auto;
    }
  }
  .record{
    position: fixed;
    bottom: 10px;
    cursor: pointer;
    left: 50%;
    transform: translateX(-50%);
  }
}
</style>
