<template>
  <div id="Collapse" :style="{height: isOpen ? slotHeight : 0}">
    <slot />
  </div>
</template>

<script type='text/ecmascript-6'>
export default {
  name: 'Collapse',
  props: {
    isOpen: {
      type: Boolean,
      default: false
    }
  },
  data () {
    return {
      slotHeight: 0
    }
  },
  mounted () {
    this.setSlotHeight()
    window.addEventListener('resize', this.setSlotHeight)
  },
  beforeDestroy () {
    window.removeEventListener('resize', this.setSlotHeight)
  },
  methods: {
    setSlotHeight () {
      this.slotHeight = this.$el.firstElementChild.scrollHeight + 'px'
    }
  }
}
</script>

<style lang="scss" scoped>
#Collapse {
  height: 0;
  transition: height .3s;
  overflow: hidden;
}
</style>
