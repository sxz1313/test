<template>
  <div class="clo-grey text-center not-found">
    <p>这里什么也没有!</p>
    <el-button type="primary" @click="back">返回</el-button>
  </div>
</template>

<script type='text/ecmascript-6'>
export default {
  name: 'NotFound',
  methods: {
    back () {
      this.$router.push({ name: 'desktop' })
    }
  }
}
</script>

<style lang='scss' scoped>
    .not-found {
        position: relative;
        top: 20vh;
        p{
          margin-bottom: 20px;
        }
    }
</style>
