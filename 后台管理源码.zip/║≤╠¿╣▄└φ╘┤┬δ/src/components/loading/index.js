import Loading from './Loading'
import Vue from 'vue'

const LoadingConstructore = Vue.extend(Loading)

const instance = new LoadingConstructore({
  el: document.createElement('div')
})

document.body.appendChild(instance.$el)

let count = 0

export default {
  open () {
    count++
    if (!instance.isOpen) {
      instance.isOpen = true
    }
  },
  close () {
    count--
    if (count === 0) {
      instance.isOpen = false
    }
  }
}
