<template>
  <div v-show="isOpen" id="Loading">
    <div class="loading-wrap">
      <div class="circle" />
      <div class="desc">加载中</div>
    </div>
  </div>
</template>

<script type='text/ecmascript-6'>
export default {
  name: 'Loading',
  data () {
    return {
      isOpen: false
    }
  }
}
</script>

<style lang="scss">
#Loading {
  position: fixed;
  top: 0;
  right: 0;
  bottom: 0;
  left: 0;
  display: flex;
  justify-content: center;
  align-items: center;
  z-index: 10000000000;

  .loading-wrap {
    background: rgba(0, 0, 0, 0.5);
    border-radius: 5px;

    @keyframes circle {
      to {
        transform: rotate(360deg);
      }
    }

    .circle {
      width: 35px;
      height: 35px;
      margin: 10px 20px;
      border-radius: 50%;
      border: 3px solid #fff;
      border-bottom-color: transparent;
      animation: circle infinite linear 0.7s;
    }

    .desc {
      font-size: 12px;
      color: #fff;
      text-align: center;
      margin: 10px 0;
    }
  }
}
</style>
