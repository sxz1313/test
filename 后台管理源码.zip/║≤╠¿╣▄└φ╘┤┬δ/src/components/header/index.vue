<template>
  <div class="headers">
    <div class="right">
      <div class="avatar">
        <up-load
          :image-list="headIcon || user.headIcon"
          :un-normal-up="normal"
          @getImage="saveImage"
        />
        <p>{{ user.name }}</p>
      </div>
      <el-menu
        class="menuItem"
        mode="horizontal"
        background-color="#1778D2"
        text-color="#fff"
        style="border-bottom: inherit;"
        active-text-color="#fff"
      >
        <el-submenu index="2">
          <template slot="title">{{ userName }}</template>
          <el-menu-item index="2-1" @click="resetPwd">修改密码</el-menu-item>
          <el-menu-item index="2-2" @click="logout">退出</el-menu-item>
        </el-submenu>
      </el-menu>
    </div>
    <!-- 修改密码模态框 -->
    <el-dialog
      v-if="editVisible"
      title="修改密码"
      width="532px"
      :close-on-click-modal="false"
      :visible.sync="editVisible"
    >
      <reset-password @submit="onSubmit" @cancel="onCancel" />
    </el-dialog>
  </div>
</template>

<script>
import User from '@/controller/User'
import upLoad from '@/components/upload/index'
import resetPassword from '@/components/resetPassword/index'
import * as loginApi from '@/api/login'

export default {
  name: 'Headers',
  components: { upLoad, resetPassword },
  data () {
    return {
      editVisible: false,
      user: User,
      normal: false,
      headIcon: ''
    }
  },
  created () {
    if (!this.user.token) return
    this.getUser()
  },
  methods: {
    // router (route) {
    //   try {
    //     if (route.module === 'teachingEducational') {
    //       this.$router.push(route)
    //       return
    //     }
    //     const firstChildren = this.$router.options.routes.find(
    //       (r) => r.meta && r.meta.module === route.module
    //     )
    //     if (firstChildren.children) {
    //       this.$router.push(firstChildren.children[0])
    //     } else {
    //       this.$router.push(firstChildren)
    //     }
    //   } catch (e) {
    //     // console.error(e)
    //   }
    // },
    // 获取用户信息
    getUser () {
      loginApi.getLoginUser().then(({ data }) => {
        this.headIcon =
          data.data.avatar || require('@/assets/img/avatar-default.jpg')

        User.setObject({
          headIcon: data.data.avatar || '',
          name: data.data.name,
          phone: data.data.phone,
          deptId: data.data.deptId,
          userId: data.data.id,
          ids: JSON.stringify(data.data.permissionIds),
          adminType: data.data.adminType
        })
      })
    },
    // 退出操作
    logout () {
      loginApi.loginOut().then(({ data }) => {
        window.localStorage.clear()
        this.$router.replace({ path: '/login' })
      })
    },
    // 修改密码
    resetPwd () {
      this.editVisible = true
      // this.$router.push({
      //   name: 'changePassword'
      // })
    },
    // 模态框确定操作
    onSubmit () {
      this.editVisible = false
      this.$router.replace({ path: '/login' })
    },
    // 模态框取消操作
    onCancel () {
      this.editVisible = false
    },
    //  上传完图片后,获取图片进行保存
    saveImage (ele) {
      // api.updateIcon({
      //   icon: ele
      // }).then(({ data }) => {
      //   this.$message({
      //     message: '保存头像成功!',
      //     type: 'success',
      //     center: true,
      //     duration: 1000
      //   })
      // })
    }
  }
}
</script>

<style lang="scss" scoped>
.headers {
  height: 186px;
  box-sizing: border-box;
  color: #fff;
  z-index: 100; // 头部层高100
  display: flex;
  justify-content: flex-end;
  background: url("~@/assets/img/header-bg.png") no-repeat center;
  background-size: cover;

  .middle {
    flex: 1;

    ul {
      padding-right: 50px;
      margin: 0;
      border-bottom: 1px solid rgba(255, 255, 255, 0.2);

      li {
        text-align: center;
        box-sizing: border-box;
        display: inline-block;
        margin-left: 40px;
        padding: 30px 0 15px;
        color: #fff;
        font-size: 18px;
        font-family: PingFang SC;
        cursor: pointer;
        border-bottom: 2px solid transparent;
        transition: border-bottom-color 0.3s;

        &:hover,
        &.is-active {
          border-bottom: 2px solid #ffffff;
        }
      }
    }
  }

  .right {
    ul {
      border-bottom: none;
    }
    .el-menu /deep/ {
      .el-submenu__title {
        border-bottom: transparent !important;
      }
    }
  }
}
</style>
