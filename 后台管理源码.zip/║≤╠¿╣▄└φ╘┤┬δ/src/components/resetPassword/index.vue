<template>
  <el-form
    ref="ruleForm"
    :model="ruleForm"
    :rules="rules"
    label-width="100px"
  >
    <el-form-item label="旧密码" prop="oldPassword">
      <el-input
        v-model.trim="ruleForm.oldPassword"
        type="password"
        placeholder="请输入旧密码"
        maxlength="18"
        class="w215"
        on-key-up="ruleForm.oldPassword=ruleForm.oldPassword.replace(/[\W]/g,'')"
        autocomplete="off"
        clearable
      />
    </el-form-item>
    <el-form-item label="新密码" prop="newPassword">
      <el-input
        v-model.trim="ruleForm.newPassword"
        type="password"
        placeholder="请输入新密码"
        maxlength="18"
        class="w215"
        on-key-up="ruleForm.newPassword=ruleForm.newPassword.replace(/[\W]/g,'')"
        autocomplete="off"
        clearable
      />
    </el-form-item>
    <el-form-item label="确认密码" prop="confirmPassword">
      <el-input
        v-model.trim="ruleForm.confirmPassword"
        type="password"
        placeholder="请输入确认密码"
        maxlength="18"
        class="w215"
        on-key-up="ruleForm.confirmPassword=ruleForm.confirmPassword.replace(/[\W]/g,'')"
        autocomplete="off"
        clearable
      />
    </el-form-item>
    <div class="tc">
      <el-button @click="onCancel">取消</el-button>
      <el-button
        type="primary"
        :disabled="!ruleForm.oldPassword || !ruleForm.newPassword || !ruleForm.confirmPassword"
        @click="onSubmit('ruleForm')"
      >保存</el-button>
    </div>
  </el-form>
</template>
<script>
import * as systemApi from '@/api/system'

export default {
  name: 'ResetPwd',
  data () {
    var validateOldPass = (rule, value, callback) => {
      if (value === '') {
        callback(new Error('请输入旧密码'))
      } else {
        callback()
      }
    }
    var validateNewPass = (rule, value, callback) => {
      if (value === '') {
        callback(new Error('请输入新密码'))
      } else {
        if (this.ruleForm.confirmPassword !== '') {
          this.$refs.ruleForm.validateField('checkPassword')
        }
        callback()
      }
    }
    var validateCheckPass = (rule, value, callback) => {
      if (value === '') {
        callback(new Error('请再次输入密码'))
      } else if (value !== this.ruleForm.newPassword) {
        callback(new Error('两次输入密码不一致!'))
      } else {
        callback()
      }
    }
    return {
      ruleForm: {
        oldPassword: '',
        newPassword: '',
        confirmPassword: ''
      },
      rules: {
        oldPassword: [
          { validator: validateOldPass, trigger: 'blur' },
          { min: 6, max: 18, message: '长度在 6 到 18 个字符', trigger: 'blur' }
        ],
        newPassword: [
          { validator: validateNewPass, trigger: 'blur' },
          { min: 6, max: 18, message: '长度在 6 到 18 个字符', trigger: 'blur' }
        ],
        confirmPassword: [
          { validator: validateCheckPass, trigger: 'blur' },
          { min: 6, max: 18, message: '长度在 6 到 18 个字符', trigger: 'blur' }
        ]
      }
    }
  },
  created () {

  },
  methods: {
    // 确定操作
    onSubmit (formName) {
      this.$refs[formName].validate((valid) => {
        if (valid) {
          systemApi.editPassword({
            newPassword: this.ruleForm.newPassword,
            oldPassword: this.ruleForm.oldPassword
          }).then(({ data }) => {
            this.$message({
              message: '密码修改成功',
              type: 'success',
              center: true,
              duration: 1000
            })
            window.localStorage.clear()
            this.$emit('submit')
          })
        } else {
          return false
        }
      })
    },
    // 取消操作
    onCancel () {
      this.$emit('cancel')
    }
  }
}
</script>
