<template>
  <el-dialog
    :visible="visible"
    title="查看图片"
    append-to-body
    @update:visible="update"
  >
    <pic-pending :big-pic="bigPic" />
    <slot />
  </el-dialog>
</template>

<script>
import PicPending from './PicPending'

export default {
  name: 'PicDialog',
  components: { PicPending },
  props: {
    visible: Boolean,
    bigPic: String
  },
  methods: {
    update () {
      this.$emit('update:visible', false)
    }
  }
}
</script>
