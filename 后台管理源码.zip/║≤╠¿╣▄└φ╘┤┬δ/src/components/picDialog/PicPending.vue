<template>
  <div class="pic-pending-container">
    <img
      v-show="src"
      :src="src"
      width="100%"
      alt="图片异常"
      @click="$emit('imgClick', src)"
    >
    <div v-show="isNoPic" class="text-center">暂无图片</div>
    <div v-show="isErrorPic" class="text-center">图片加载失败</div>
    <div class="text-center">
      <div v-show="isPicPending" class="sm-loading">{{ nothing }}</div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'PicPending',
  props: {
    bigPic: {
      type: String,
      default: ''
    }
  },
  data () {
    return {
      isPicPending: false,
      src: '',
      isErrorPic: false,
      isNoPic: false
    }
  },
  computed: {
    nothing () {
      return this.loadPic(this.bigPic)
    }
  },
  methods: {
    reset () {
      this.isPicPending = false
      this.src = ''
      this.isErrorPic = false
      this.isNoPic = false
    },
    loadPic (src) {
      this.reset()
      if (src) {
        this.isPicPending = true
        const img = document.createElement('img')
        img.src = src
        img.onload = () => {
          this.src = src
          this.isPicPending = false
        }
        img.onerror = () => {
          this.isPicPending = false
          this.isErrorPic = true
        }
      } else {
        this.isNoPic = true
      }
    }
  }
}
</script>
