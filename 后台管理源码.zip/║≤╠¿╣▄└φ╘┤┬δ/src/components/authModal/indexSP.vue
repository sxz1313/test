<template>
  <div class="auth">
    <div class="treeLeft">
      <div class="treeHeader">
        <el-input
          v-model="filterText"
          placeholder="输入关键字进行过滤"
          clearable
          class="w215"
        />
        <el-tooltip effect="dark" content="点击展开全部" placement="top">
          <span class="expand" @click="expandAll"> + </span>
        </el-tooltip>
        <el-tooltip effect="dark" content="点击收缩全部" placement="top">
          <span class="close" @click="closeAll"> - </span>
        </el-tooltip>
      </div>
      <el-tree
        ref="tree"
        style="max-height:500px;overflow:auto"
        :data="treeData"
        :props="defaultProps"
        :default-expand-all="defaultExpand"
        :filter-node-method="filterNode"
        node-key="id"
        show-checkbox
        :check-strictly="isStrictly"
        :default-checked-keys="defaultKey"
        @check-change="checkChange"
        @check="checkGroupNode"
      />
    </div>
    <div class="treeRight">
      <p>{{ choiceName }}</p>
      <div class="tag">
        <el-tag v-for="tag in authTags" :key="tag.id">
          <span v-show="authParam !== '已选人员'">
            {{ tag.templateName || tag.name }}</span>
          <span v-show="authParam === '已选人员'">
            {{
              tag.templateName ||
                (tag.titleName
                  ? `${tag.name}(${tag.titleName})`
                  : `${tag.name}`)
            }}</span>
        </el-tag>
      </div>
      <div class="tc mt">
        <el-button @click="onCancel">取消</el-button>
        <el-button type="primary" @click="onSubmit">保存</el-button>
      </div>
    </div>
  </div>
</template>

<script>
import * as api from '@/api/common'
import {
  userTree,
  departmentTree,
  userTreeRadio,
  departmentTreeRadio
} from '@/utils/index'
export default {
  name: 'AuthModal',
  props: {
    /**
		 * 父组件传值
		 * 判断是部门权限还是人员权限页面
		 */
    authParam: {
      type: String,
      default: ''
    },
    /**
		 * 父组件传值
		 * 已授权人员/部分的ID集合
		 */
    authorized: {
      type: Array,
      default: () => []
    },
    /**
		 * 父组件传值
		 * 数组类型
		 * 0----->支持选择所有人员
		 * 1----->只支持选择在职人员
		 */
    isAllPeroson: {
      type: Number,
      default: 1
    },
    /**
		 * 父组件传值
		 * 布尔类型
		 * false---> 支持多选操作
		 * true---->支持单选操作
		 */
    isRadio: {
      type: Boolean,
      default: false
    },
    // 不可选的监考老师列表
    disabledList: {
      type: Object,
      default: () => {
        []
      }
    }
  },
  data () {
    return {
      filterText: '',
      treeData: [],
      defaultKey: [],
      defaultProps: {
        children: 'children',
        label: 'name'
      },
      authTags: [],
      defaultExpand: true,
      isStrictly: false
    }
  },
  computed: {
    choiceName () {
      if (this.authParam === '已选人员') {
        this.getAuthUser(this.isAllPeroson)
      } else if (this.authParam === '已选部门') {
        this.getAuthDepartment()
      }
      return this.authParam
    }
  },
  watch: {
    filterText (val) {
      this.$refs.tree.filter(val)
    },
    authorized: {
      handler (newVal) {
        this.defaultKey = (newVal || []).map((item) => item.id)
        this.authTags = newVal || []
      }
    }
  },
  created () {
    if (this.authParam === '已选人员') {
      this.isStrictly = false
    } else if (this.authParam === '已选部门') {
      this.isStrictly = true
    }
    this.defaultKey = (this.authorized || []).map((item) => item.id)
    this.authTags = this.authorized || []
  },
  methods: {
    // 获取授权人员列表
    getAuthUser (val) {
      // 0--->所有人员  1 --->在职人员
      const param = {
        status: val,
        appCode: process.env.VUE_APP_APP_CODE
      }
      api.getOrganizationContainMember(param).then(({ data }) => {
        const tempArr = JSON.stringify(data.data || []).replace(
          /realName/g,
          'name'
        )
        this.treeData = JSON.parse(tempArr)
        if (this.isRadio) {
          userTreeRadio(this.treeData)
        } else {
          userTree(this.treeData)
        }
        if (!this.disabledList || this.disabledList.length === 0) return
        this.setDisabled(
          (this.disabledList || []).map((item) => item.id),
          this.treeData
        )
      })
    },
    // 获取授权部门列表
    getAuthDepartment () {
      const param = {
        appCode: process.env.VUE_APP_APP_CODE
      }
      api.allDept(param).then(({ data }) => {
        this.treeData = data.data || []
        if (this.isRadio && this.authParam === '已选人员') {
          departmentTreeRadio(this.treeData)
        } else {
          departmentTree(this.treeData)
        }
      })
    },
    // 选中改变触发
    checkChange () {
      // 获取子节点ID
      if (this.authParam === '已选部门') {
        const departments = this.$refs.tree.getCheckedNodes()
        this.authTags = departments
      } else if (this.authParam === '已选人员') {
        const nodes = this.$refs.tree
          .getCheckedNodes()
          .concat(this.$refs.tree.getHalfCheckedNodes())
        this.authTags = nodes.filter((node) => {
          return node.children === undefined
        })
      }
    },
    // 选择触发--->支持单选
    checkGroupNode (ele, val) {
      if (!this.isRadio || this.authParam === '已选部门') {
        return
      }
      if (val.checkedKeys.length > 0) {
        this.$refs.tree.setCheckedKeys([ele.id])
      }
    },
    // 取消操作提交
    onCancel () {
      this.$emit('cancel')
    },
    // 确定操作提交
    onSubmit () {
      this.$emit('authSubmit', this.authTags, this.authParam)
    },
    // 关键字过滤
    filterNode (value, data, node) {
      if (!value) return true
      if (data.name.indexOf(value) !== -1) {
        return true
      }
      return this.checkBelongToChooseNode(value, data, node)
    },
    // 判断传入的节点是不是选中节点的子节点
    checkBelongToChooseNode (value, data, node) {
      const level = node.level
      if (level === 1) {
        return false
      }
      let parentData = node.parent
      let index = 0
      while (index < level - 1) {
        if (parentData.data.name.indexOf(value) !== -1) {
          return true
        }
        parentData = parentData.parent
        index++
      }
      // 没匹配到返回false
      return false
    },
    // 展开所有树结构
    expandAll () {
      this.defaultExpand = true // 展开所有节点
      for (var i = 0; i < this.$refs.tree.store._getAllNodes().length; i++) {
        this.$refs.tree.store._getAllNodes()[i].expanded = this.defaultExpand
      }
    },
    // 收缩所有树结构
    closeAll () {
      this.defaultExpand = false
      for (var i = 0; i < this.$refs.tree.store._getAllNodes().length; i++) {
        this.$refs.tree.store._getAllNodes()[i].expanded = this.defaultExpand
      }
    },
    // 人员树设置disabled
    setDisabled (ele, treeData) {
      treeData.forEach((item) => {
        (item.userList || []).forEach((element) => {
          if (ele.includes(element.id)) {
            this.$set(element, 'disabled', true)
          }
          if (item.children.length > 0) {
            this.setDisabled(
              (this.disabledList || []).map((item) => item.id),
              item.children
            )
          }
        })
      })
    }
  }
}
</script>

<style lang="scss" scoped>
.auth {
	display: flex;
	justify-content: space-between;
	.treeLeft {
		width: 49%;
		border-right: 1px solid #ccc;
		.treeHeader {
			margin-bottom: 10px;
			.expand,
			.close {
				cursor: pointer;
				color: #009dda;
				font-size: 30px;
				font-weight: bold;
				line-height: 20px;
			}
		}
	}
	.treeRight {
		width: 49%;
		p {
			line-height: 32px;
			margin-left: 10px;
		}
		.tag {
			height: 500px;
			overflow: auto;
			margin-top: 10px;
			span {
				margin-bottom: 10px;
				margin-right: 20px;
			}
		}
		.button {
			text-align: right;
		}
	}
}
</style>
