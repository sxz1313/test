<template>
  <div class="auth">
    <div class="treeLeft">
      <el-tree
        ref="tree"
        class="filter-tree"
        style="max-height:500px;overflow:auto"
        :data="treeData"
        :props="defaultProps"
        :default-expand-all="defaultExpand"
        node-key="id"
        show-checkbox
        :check-strictly="isStrictly"
        :default-checked-keys="defaultKey"
        @check-change="checkChange"
        @check="checkGroupNode"
      />
    </div>
    <div class="treeRight">
      <p>{{ authParam }}</p>
      <div class="tag">
        <el-tag
          v-for="tag in authTags"
          :key="tag.id"
        >
          {{ tag.templateName || tag.name }}
        </el-tag>
      </div>
      <div class="button">
        <el-button
          @click="resetForm"
        >取消</el-button>
        <el-button
          type="primary"
          @click="submitForm()"
        >确定</el-button>
      </div>
    </div>
  </div>
</template>
<script>
import * as api from '@/api/meeting/resourceManage'
import {
  departmentTree
} from '@/utils/index'
export default {
  name: 'AuthModal',
  props: {
    /**
     * 父组件传值
     * 判断是部门权限还是人员权限页面
     */
    authParam: {
      type: String,
      default: ''
    },
    /**
     * 父组件传值
     * 已授权人员/部分的ID集合
     */
    authorized: {
      type: Array,
      default: () => []
    },
    /**
     * 父组件传值
     * 数组类型
     * 0----->支持选择所有人员
     * 1----->只支持选择在职人员
     */
    isAllPeroson: {
      type: Number,
      default: 1
    },
    /**
     * 父组件传值
     * 布尔类型
     * false---> 支持多选操作
     * true---->支持单选操作
     */
    isRadio: {
      type: Boolean,
      default: false
    }
  },
  data () {
    return {
      treeData: [
        {
          id: 1,
          label: '一级 1',
          children: [{
            id: 4,
            label: '二级 1-1',
            children: [{
              id: 9,
              label: '三级 1-1-1'
            }, {
              id: 10,
              label: '三级 1-1-2'
            }]
          }]
        }, {
          id: 2,
          label: '一级 2',
          children: [{
            id: 5,
            label: '二级 2-1'
          }, {
            id: 6,
            label: '二级 2-2'
          }]
        }, {
          id: 3,
          label: '一级 3',
          children: [{
            id: 7,
            label: '二级 3-1'
          }, {
            id: 8,
            label: '二级 3-2'
          }]
        }
      ],
      defaultKey: [],
      defaultProps: {
        children: 'children',
        label: 'name'
      },
      authTags: [],
      defaultExpand: true,
      isStrictly: false
    }
  },
  created () {
    this.isStrictly = true
    this.defaultKey = (this.authorized || []).map(item => item.id)
    this.authTags = this.authorized || []
    this.getAuthDepartment()
  },
  methods: {
    getAuthDepartment () {
      api.allDept().then(({ data }) => {
        if (data.code === 200) {
          this.treeData = data.data
          departmentTree(this.treeData)
        }
      })
    },
    checkChange () {
      // 获取子节点ID
      const departments = this.$refs.tree.getCheckedNodes()
      this.authTags = departments
    },
    // 选择触发--->支持单选
    checkGroupNode (ele, val) {
      if (!this.isRadio || this.authParam === '已选部门') {
        return
      }
      if (val.checkedKeys.length > 0) {
        this.$refs.tree.setCheckedKeys([ele.id])
      }
    },
    // 取消操作提交
    resetForm () {
      this.$emit('cancel')
    },
    // 确定操作提交
    submitForm () {
      this.$emit('authSubmit', this.authTags, this.authParam)
    }
  }
}
</script>

<style lang='scss' scoped>
  .auth {
    display: flex;
    justify-content: space-between;
    .treeLeft {
      width: 49%;
      border-right: 1px solid #ccc;
      .treeHeader {
        margin-bottom: 10px;
        .expand,
        .close {
          cursor: pointer;
          color: #009dda;
          font-size: 30px;
          font-weight: bold;
          line-height: 20px;
        }
      }
    }
    .treeRight {
      width: 49%;
      p {
        line-height: 32px;
        margin-left: 10px;
      }
      .tag {
        height: 500px;
        overflow: auto;
        margin-top: 10px;
        span {
          margin-bottom: 10px;
          margin-right: 20px;
        }
      }
      .button {
        text-align: right;
      }
    }
  }
</style>
