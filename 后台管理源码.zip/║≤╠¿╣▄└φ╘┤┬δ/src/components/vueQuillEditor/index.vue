<template>
  <div class="vueQuillEditor">
    <quill-editor
      ref="myQuillEditor"
      v-model="content"
      :options="editorOption"
      @blur="onEditorBlur($event)"
      @focus="onEditorFocus($event)"
      @change="onEditorChange($event)"
      @ready="onEditorReady($event)"
    />
    <input
      id="inputFile"
      ref="imageFile"
      style="visibility: hidden;height:0;"
      type="file"
      name
      accept="image/*"
      @change="selectedFile"
    >
    <input
      id="inputFile"
      ref="videoFile"
      style="visibility: hidden;height:0;"
      type="file"
      name
      accept="video/*"
      @change="selectedFile"
    >
  </div>
</template>
<script>
import { Quill, quillEditor } from 'vue-quill-editor'

import 'quill/dist/quill.core.css'
import 'quill/dist/quill.snow.css'
import 'quill/dist/quill.bubble.css'
import * as api from '@/api/common'
var fonts = [
  'SimSun',
  'SimHei',
  'Microsoft-YaHei',
  'KaiTi',
  'FangSong',
  'Arial',
  'Times-New-Roman',
  'sans-serif'
]
var Font = Quill.import('formats/font')
Font.whitelist = fonts
Quill.register(Font, true)
var sizes = ['14px', '16px', '18px', '20px', '28px', '32px']
var Size = Quill.import('attributors/style/size')
Size.whitelist = sizes
Quill.register(Size)
export default {
  name: 'VueQuillEditor',
  components: {
    quillEditor
  },
  props: {
    content: {
      type: String,
      default: ''
    }
  },
  data () {
    return {
      // 富文本编辑器配置
      editorOption: {
        modules: {
          toolbar: {
            container: [
              ['bold', 'italic', 'underline', 'strike'], // 加粗 斜体 下划线 删除线
              ['blockquote', 'code-block'], // 引用  代码块
              [{ header: 1 }, { header: 2 }], // 1、2 级标题
              [{ list: 'ordered' }, { list: 'bullet' }], // 有序、无序列表
              [{ script: 'sub' }, { script: 'super' }], // 上标/下标
              [{ indent: '-1' }, { indent: '+1' }], // 缩进
              [{ direction: 'rtl' }], // 文本方向
              // [{ size: sizes }], // 字体大小
              [{ header: [1, 2, 3, 4, 5, 6] }], // 标题
              [{ color: [] }, { background: [] }], // 字体颜色、字体背景颜色
              [{ font: fonts }], // 字体种类
              [{ align: [] }], // 对齐方式
              ['clean'], // 清除文本格式
              ['image', 'video'] // 链接、图片、视频
            ],
            handlers: {
              image: () => {
                // 劫持原来的图片点击按钮事件
                this.handleOpenImageFile() // 打开文件
              },
              video: () => {
                this.handleOpenVideoFile() // 打开文件
              }
            }
          }
        },
        placeholder: '请输入'
      },
      upvideoShow: false, // 控制上传视频展示
      upimgShow: false // 控制上传图片展示
    }
  },
  mounted () {},
  methods: {
    // 打开文件
    handleOpenImageFile () {
      const input = this.$refs.imageFile
      // 解决同一个文件不能监听的问题
      input.addEventListener(
        'click',
        function () {
          this.value = ''
        },
        false
      )
      // 点击input
      input.click()
    },
    // 打开文件
    handleOpenVideoFile () {
      const input = this.$refs.videoFile
      // 解决同一个文件不能监听的问题
      input.addEventListener(
        'click',
        function () {
          this.value = ''
        },
        false
      )
      // 点击input
      input.click()
    },
    // 选择好文件
    selectedFile ($event) {
      const file = $event.target.files[0]
      if (file.size > 500 * 1024 * 1024) {
        this.$message.warning('上传的文件不能超过500Mb')
        return
      }
      const blob = new FormData()
      blob.append('file', file)
      blob.append('resultType', 1)
      api.fileUpload(blob).then(({ data }) => {
        // 调用appendHtml方法把图片追加到富文本
        const quill = this.$refs.myQuillEditor.quill
        const length = quill.getSelection().index
        // 插入图片  response.data.url为服务器返回的图片地址
        var type =
          file.type === 'image/png' ||
          file.type === 'image/jpg' ||
          file.type === 'image/jpeg'
            ? 'image'
            : 'video'
        quill.insertEmbed(length, type, process.env.VUE_APP_IMG_API + data.data.fileUrl)
        // 调整光标到最后
        quill.setSelection(length + 1)
      })
    },
    // 失去焦点事件
    onEditorBlur (quill) {
      // console.log('editor blur!', quill)
    },
    // 获得焦点事件
    onEditorFocus (quill) {
      // console.log('editor focus!', quill)
    },
    // 准备富文本编辑器
    onEditorReady (quill) {
      // console.log('editor ready!', quill)
    },
    // 内容改变事件
    onEditorChange ({ quill, html, text }) {
      // console.log('editor change!', quill, html, text)
      this.$emit('onEditorChange', html)
    },
    init () {
      // 禁用编辑期
      this.$refs.myQuillEditor.quill.enable(false)
      this.$nextTick(() => {
        // 丢掉编辑器焦点并重新启用编辑器
        setTimeout(() => {
          this.$refs.myQuillEditor.quill.blur()
          this.$refs.myQuillEditor.quill.enable(true)
        }, 500)
      })
    }
  }
}
</script>
<style lang="scss" scoped>
.vueQuillEditor {
  .quill-editor /deep/ {
    .ql-container {
      height: 400px;
    }

    .ql-snow .ql-picker.ql-font .ql-picker-label[data-value="SimSun"]::before,
    .ql-snow .ql-picker.ql-font .ql-picker-item[data-value="SimSun"]::before {
      content: "宋体";
      font-family: "SimSun";
    }

    .ql-snow .ql-picker.ql-font .ql-picker-label[data-value="SimHei"]::before,
    .ql-snow .ql-picker.ql-font .ql-picker-item[data-value="SimHei"]::before {
      content: "黑体";
      font-family: "SimHei";
    }

    .ql-snow
      .ql-picker.ql-font
      .ql-picker-label[data-value="Microsoft-YaHei"]::before,
    .ql-snow
      .ql-picker.ql-font
      .ql-picker-item[data-value="Microsoft-YaHei"]::before {
      content: "微软雅黑";
      font-family: "Microsoft YaHei";
    }

    .ql-snow .ql-picker.ql-font .ql-picker-label[data-value="KaiTi"]::before,
    .ql-snow .ql-picker.ql-font .ql-picker-item[data-value="KaiTi"]::before {
      content: "楷体";
      font-family: "KaiTi";
    }

    .ql-snow .ql-picker.ql-font .ql-picker-label[data-value="FangSong"]::before,
    .ql-snow .ql-picker.ql-font .ql-picker-item[data-value="FangSong"]::before {
      content: "仿宋";
      font-family: "FangSong";
    }

    .ql-snow .ql-picker.ql-font .ql-picker-label[data-value="Arial"]::before,
    .ql-snow .ql-picker.ql-font .ql-picker-item[data-value="Arial"]::before {
      content: "Arial";
      font-family: "Arial";
    }

    .ql-snow
      .ql-picker.ql-font
      .ql-picker-label[data-value="Times-New-Roman"]::before,
    .ql-snow
      .ql-picker.ql-font
      .ql-picker-item[data-value="Times-New-Roman"]::before {
      content: "Times New Roman";
      font-family: "Times New Roman";
    }

    .ql-snow
      .ql-picker.ql-font
      .ql-picker-label[data-value="sans-serif"]::before,
    .ql-snow
      .ql-picker.ql-font
      .ql-picker-item[data-value="sans-serif"]::before {
      content: "sans-serif";
      font-family: "sans-serif";
    }

    .ql-font-SimSun {
      font-family: "SimSun";
    }

    .ql-font-SimHei {
      font-family: "SimHei";
    }

    .ql-font-Microsoft-YaHei {
      font-family: "Microsoft YaHei";
    }

    .ql-font-KaiTi {
      font-family: "KaiTi";
    }

    .ql-font-FangSong {
      font-family: "FangSong";
    }

    .ql-font-Arial {
      font-family: "Arial";
    }

    .ql-font-Times-New-Roman {
      font-family: "Times New Roman";
    }

    .ql-font-sans-serif {
      font-family: "sans-serif";
    }

    .ql-snow .ql-picker.ql-size .ql-picker-label[data-value="12px"]::before,
    .ql-snow .ql-picker.ql-size .ql-picker-item[data-value="12px"]::before {
      content: "12px";
    }
    .ql-snow .ql-picker.ql-size .ql-picker-label[data-value="14px"]::before,
    .ql-snow .ql-picker.ql-size .ql-picker-item[data-value="14px"]::before {
      content: "14px";
    }
    .ql-snow .ql-picker.ql-size .ql-picker-label[data-value="16px"]::before,
    .ql-snow .ql-picker.ql-size .ql-picker-item[data-value="16px"]::before {
      content: "16px";
    }
    .ql-snow .ql-picker.ql-size .ql-picker-label[data-value="18px"]::before,
    .ql-snow .ql-picker.ql-size .ql-picker-item[data-value="18px"]::before {
      content: "18px";
    }
    .ql-snow .ql-picker.ql-size .ql-picker-label[data-value="20px"]::before,
    .ql-snow .ql-picker.ql-size .ql-picker-item[data-value="20px"]::before {
      content: "20px";
    }
    .ql-snow .ql-picker.ql-size .ql-picker-label[data-value="22px"]::before,
    .ql-snow .ql-picker.ql-size .ql-picker-item[data-value="22px"]::before {
      content: "22px";
    }
    .ql-snow .ql-picker.ql-size .ql-picker-label[data-value="24px"]::before,
    .ql-snow .ql-picker.ql-size .ql-picker-item[data-value="24px"]::before {
      content: "24px";
    }
    .ql-snow .ql-picker.ql-size .ql-picker-label[data-value="28px"]::before,
    .ql-snow .ql-picker.ql-size .ql-picker-item[data-value="28px"]::before {
      content: "28px";
    }
    .ql-snow .ql-picker.ql-size .ql-picker-label[data-value="32px"]::before,
    .ql-snow .ql-picker.ql-size .ql-picker-item[data-value="32px"]::before {
      content: "32px";
    }
    .ql-snow .ql-picker.ql-size .ql-picker-label[data-value="36px"]::before,
    .ql-snow .ql-picker.ql-size .ql-picker-item[data-value="36px"]::before {
      content: "36px";
    }
  }
}
</style>
