<template>
  <el-pagination
    v-show="filter.total > 0"
    background
    layout="prev, pager, next"
    :page-size="filter.pageSize"
    :total="filter.total"
    :current-page="filter.pageNo"
    @current-change="currentChange"
  />
</template>

<script type='text/ecmascript-6'>
export default {
  name: 'Pagination',
  props: {
    pageParam: {
      type: Object,
      default: () => { }
    }
  },
  data () {
    return {
    }
  },
  computed: {
    filter () {
      return this.pageParam
    }
  },
  created () {
  },
  methods: {
    currentChange (currentPage) {
      this.$emit('pageChange', currentPage)
    }
  }
}
</script>
