<template>
  <!--左侧导航-->
  <aside>
    <div class="header-title">人才信息录入</div>
    <!--导航菜单-->
    <el-menu
      background-color="#FFFFFF"
      text-color="#666"
      active-text-color="#0066C5"
      unique-opened
      :default-active="defaultActive"
      :default-openeds="openKey"
      @open="handleOpen"
    >
      <div v-for="(item,index) in sideMenu" :key="index">
        <el-submenu
          v-show="item.children && item.children.length > 0"

          :index="item.name"
          class="rsfMenu"
        >
          <template slot="title">
            <!-- <i :class="item.meta.iconCls"></i> -->
            <span slot="title">{{ item.meta.title }}</span>
          </template>
          <el-menu-item
            v-for="term in item.children"
            v-show="term.meta.menuShow"
            :key="term.path"
            :index="term.name"
            :class="activeClass(term)"
            @click="handleSelect(term)"
          >
            <!-- <i :class="term.meta.iconCls"></i> -->
            <span slot="title">{{ term.meta.title }}</span>
          </el-menu-item>
        </el-submenu>
        <el-menu-item
          v-show="!item.children || item.children.length === 0"
          :key="item.path"
          :index="item.name"
          :class="activeClass(item)"
          @click="handleSelect(item)"
        >
          <!-- <i :class="term.meta.iconCls"></i> -->
          <span slot="title" style="font-size: 16px;">{{ item.meta.title }}</span>
        </el-menu-item>
      </div>
    </el-menu>
  </aside>
</template>
<script>
import User from '@/controller/User'
export default {
  props: {
    menuList: {
      type: Array,
      default: () => []
    },
    defaultActive: { type: String, default: '' }, // 默认打开的导航
    defaultOpenKey: { type: String, default: '' }
  },
  data () {
    return {
      openKey: 0,
      sideMenu: []
    }
  },
  watch: {
    menuList: {
      handler (newVal) {
        const tempRoute = JSON.parse(JSON.stringify(newVal))
        const routers = (tempRoute || []).filter(ele => {
          const secondRoute = (ele.children || []).filter(item => item.meta && JSON.parse(User.get('ids')).includes(item.meta.authId))
          this.$set(ele, 'children', secondRoute)
          return ele && ele.children.length > 0 || ele.path === '/index'
        })
        this.sideMenu = routers
      }
    },
    defaultOpenKey: {
      handler (newVal) {
        this.openKey = newVal
      }
    }
  },
  created () {
    this.openKey = this.defaultOpenKey
    const tempRoute = JSON.parse(JSON.stringify(this.menuList))
    const routers = (tempRoute || []).filter(ele => {
      const secondRoute = (ele.children || []).filter(item => item.meta && JSON.parse(User.get('ids')).includes(item.meta.authId))
      this.$set(ele, 'children', secondRoute)
      return (ele && ele.children.length > 0) || ele.path === '/index'
    })
    this.sideMenu = routers
  },
  methods: {
    // 菜单栏选中
    handleSelect (ele) {
      const { fullPath } = this.$router.match({ name: ele.name }) || {}
      if (fullPath !== this.$route.fullPath) {
        this.$router.push(fullPath)
      }
    },
    // 展开事件触发
    handleOpen (key) {
      this.openKey = [key]
    },
    // 选中样式修改
    activeClass (info) {
      if (this.$route.meta && this.$route.meta === info.meta) {
        return 'is-active'
      } else {
        return ''
      }
    }
  }
}
</script>
<style scoped lang="scss">
aside {
  font-size: 16px;
  background-color: #ffffff;
  border-bottom: 1px solid transparent;
  touch-callout: none;
  user-select: none;

  &::-webkit-scrollbar {
    display: none;
  }

  &.showSidebar {
    overflow-x: hidden;
    overflow-y: auto;
  }

  .el-menu {
    min-width: 230px;
    padding-top: 15px;
    border-right: none;
    height: calc(100vh - 100px);
    overflow-y: auto;
    span{
      margin-left: 10px;
    }
  }

  .el-menu--collapse {
    width: 60px;
  }

  /deep/ .is-active .el-submenu__title {
    color: #0066C5 !important;
  }

  /deep/ .el-submenu__title {
    font-size: 16px;
    text-align: left;

    &:hover {
      background-color: #fff !important;
    }
  }

  /deep/ .el-menu-item {
    border-radius: 25px 0 0 25px;
    margin-left: 10px;
    text-align: left;
  }

  /deep/ .el-menu-item:hover, .el-submenu:hover,
  .el-submenu .el-menu-item:hover {
    background-color: #ECF0FF !important;
    color: #0066C5 !important;
    border-radius: 25px 0 0 25px;
  }

  /deep/ .el-menu-item.is-active {
    background-color: #ECF0FF !important;
    color: #0066C5 !important;
    border-radius: 25px 0 0 25px;
    // margin-left: 30px;
  }

  .header-title {
    line-height: 71px;
    font-size: 26px;
    text-align: center;
    color: #1778D2;
    background: #EBF5FF;
  }
}
</style>
