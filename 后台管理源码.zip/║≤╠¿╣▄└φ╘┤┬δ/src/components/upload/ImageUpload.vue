<!--图片list-type上传公共组件-->
<template>
  <div>
    <el-upload
      :action="uploadUrl"
      list-type="picture-card"
      :before-upload="beforeUploadOpr"
      :on-remove="imageRemoveOpr"
      :on-success="imageUploadSuccess"
      :show-file-list="false"
    >
      <i class="el-icon-plus" />
    </el-upload>
  </div>
</template>
<script>
// import { getToken } from '@/utils/auth'
// import { uploadAppCode } from '@/utils/lzxh-common'
export default {
  name: 'ImageUpload',
  props: {
    viewFileList: {
      // 查看动作默认展示图片
      type: Array,
      default: () => []
    },
    limit: {
      type: Number,
      default: 12
    }
  },
  data () {
    return {
      uploadUrl:
				process.env.VUE_APP_API_URL + 'sysFileInfo/upload', // 上传接口地址
      fileList: [] // 文件集合
      // headerData: { Authorization: getToken() } // 上传图片token校验
    }
  },
  watch: {
    viewFileList (val) {
      this.fileList = []
      if (val && val.length > 0) {
        val.map((ele) => {
          this.fileList.push({ url: ele })
        })
      }
    }
  },
  created () {
    if (this.viewFileList && this.viewFileList.length > 0) {
      this.viewFileList.map((ele) => {
        this.fileList.push({ url: ele })
      })
    }
  },
  methods: {
    // 上传前的钩子
    beforeUploadOpr (img) {

    },
    handleExceed (files, fileList) {
      this.$message.warning(
        `当前限制选择 ${this.limit} 个文件，已经选择了  ${this.limit} 个文件`
      )
    },
    // 文件上传成功后的钩子
    imageUploadSuccess (res) {
      const { imageThumUrl } = res.data // 上传成功的url图片
      this.$emit('getImagesData', imageThumUrl)
    },
    // 删除触发的钩子
    imageRemoveOpr (file, fileList) {
      this.fileList = this.fileList.filter((ele) => {
        if (ele.url !== file.url) {
          return ele
        }
      })
      this.$emit('getImagesData', this.fileList)
    }
  }
}
</script>
