<!--图片list-type上传公共组件-->
<template>
  <div class="upBar">
    <el-upload
      class="img-uploader"
      accept="image/*"
      :action="uploadUrl"
      :data="authData"
      :headers="headers"
      :show-file-list="false"
      :on-success="handleImgSuccess"
      :before-upload="beforeImgUpload"
      :on-error="handleImgError"
    >
      <img v-if="imgUrl" :src="imgUrl" class="img">
      <i v-else class="el-icon-plus img-uploader-icon" />
      <div v-if="imgUrl && upState" class="bg-o" @click.stop="stop">
        <i class="el-icon-zoom-in" @click.stop="dialogVisible = true" />
        <i class="el-icon-delete ml-20" @click.stop="del" />
      </div>
    </el-upload>
    <el-dialog :append-to-body="true" width="40%" :visible.sync="dialogVisible">
      <img width="100%" :src="imgUrl" alt="">
    </el-dialog>
  </div>
</template>
<script>
import User from '@/controller/User'
import * as commonApi from '@/api/common'
export default {
  name: 'ImageUpload',
  props: {
    imgUrl: {
      type: String,
      default: ''
    },
    upState: {
      type: Boolean,
      default: false
    }
  },
  data () {
    return {
      uploadUrl: commonApi.uploadFileUrlInfo(),
      dialogVisible: false,
      dialogImageUrl: '',
      authData: {
        resultType: '2'
      },
      headers: {
        Authorization: User.token
      }
    }
  },
  created () {},
  methods: {
    stop () {},
    del () {
      this.imgUrl = ''
      this.dialogVisible = false
      this.$emit('handleImgSuccess', '')
    },
    beforeImgUpload (file) {
      const isLt2M = file.size / 1024 / 1024 < 2
      if (!isLt2M) {
        this.$message.error('图片大小不能超过 2MB!')
      }
      return isLt2M
    },
    handleImgSuccess (res, file) {
      if (res.code === 200) {
        this.$emit('handleImgSuccess', res.data)
      } else if (
        res.code === 1011004 ||
        res.code === 1011005 ||
        res.code === 1011006 ||
        res.code === 1011009
      ) {
        window.location.hash = '/login'
        window.localStorage.clear()
      } else {
        this.$message.error(res.message)
      }
    },
    handleImgError (err) {
      let msg = ''
      if (err.code === 'ECONNABORTED') {
        msg = '连接超时'
      } else if (
        err.request &&
        err.request.status === 0 &&
        err.request.readyState === 4
      ) {
        msg = '网络异常'
      } else {
        msg =
          (err.response &&
            err.response.data &&
            (err.response.data.message || err.response.data.msg)) ||
          err.message ||
          err.msg
      }
      this.$message.error(msg)
    }
  }
}
</script>
<style lang="scss" scoped>
  .img-uploader /deep/ {
    height: 152px;
    .el-upload {
      border: 1px dashed #d9d9d9;
      border-radius: 6px;
      cursor: pointer;
      position: relative;
      overflow: hidden;
      .bg-o{
        display: none;
      }
    }
    .el-upload:hover {
      border-color: #409eff;
      .bg-o {
        position: absolute;
        left: 0;
        top: 0;
        width: 100%;
        height: 100%;
        background: rgba(0, 0, 0, 0.5);
        display: flex;
        align-items: center;
        justify-content: center;
        i {
          font-size: 24px;
          color: #fff;
        }
      }
    }
  }
  .img-uploader-icon {
    font-size: 50px;
    color: #8c939d;
    width: 150px;
    height: 150px;
    line-height: 150px;
    text-align: center;
  }
  .img {
    width: 150px;
    height: 150px;
    display: block;
  }
</style>
