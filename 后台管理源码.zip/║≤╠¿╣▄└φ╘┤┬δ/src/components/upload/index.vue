<template>
  <el-upload
    :action="upLoadAction"
    :list-type="!isNormal?'picture-card':''"
    :show-file-list="!isNormal"
    :data="upLoadData"
    :class="{hideUp:hideUpload}"
    :on-remove="handleRemove"
    :before-upload="beforeAvatarUpload"
    :limit="limitNum"
    disabled
    :on-success="fileSuccess"
    accept=".png,.jpg,.jpeg,.gif"
    :file-list="fileList"
  >
    <i v-show="!isNormal" class="el-icon-plus" />
    <el-button v-show="isNormal" type="primary">上传图片</el-button>
  </el-upload>
</template>

<script>
import { uploadFileWithUrl } from '@/api/common'

export default {
  name: 'Upload',
  props: {
    imageList: {
      type: String,
      default: ''
    },
    unNormalUp: {
      type: Boolean,
      default: true
    },
    compress: {
      type: Boolean,
      default: false
    },
    limitNum: {
      type: String,
      default: '1'
    }
  },
  data () {
    return {
      fileList: [],
      hideUpload: false,
      upLoadData: { resultType: 0 },
      upLoadAction: ''
    }
  },
  computed: {
    isNormal () {
      return this.unNormalUp
    }
  },
  watch: {
    imageList: {
      handler (newVal) {
        this.fileList = newVal ? [{ url: newVal }] : []
        this.hideUpload = newVal && this.limitNum === '1'
      }
    }
  },
  created () {
    this.upLoadAction = uploadFileWithUrl()
    this.fileList = this.imageList ? [{ url: this.imageList }] : []
    this.hideUpload = this.imageList && this.limitNum === '1'
  },
  methods: {
    // 上传文件
    fileSuccess (file, fileList) {
      // this.hideUpload = this.limitNum === '1' ? (fileList.length >= 1) : false
      this.hideUpload = this.limitNum === '1' ? (fileList.url) : false
      if (file && file.data) {
        this.$emit('getImage', file.data)
        // this.$emit('getImage', `${process.env.VUE_APP_API_URL}${file.data.fileUrl}`)
        // this.$emit('getImageId', file.data.id)
        // this.$emit('getImageName', fileList.name)
      }
    },
    // 图片上传之前验证
    beforeAvatarUpload (file) {
      const isJPG = /^image\/(jpg|jpeg|png|gif)/.test(file.type)
      const isLt2M = file.size / 1024 / 1024 < 2
      if (!isJPG) {
        this.$message.error('上传图片只能是 JPG/PNG/JPEG/GIF 格式!')
        return false
      }
      if (!isLt2M) {
        this.$message.error('上传图片大小不能超过 2MB!')
        return false
      }
      if (this.compress) {
        const _this = this
        return new Promise(resolve => {
          const reader = new FileReader()
          const image = new Image()
          image.onload = (imageEvent) => {
            const canvas = document.createElement('canvas')
            const context = canvas.getContext('2d')
            const width = 312
            const height = 214
            canvas.width = width
            canvas.height = height
            context.clearRect(0, 0, width, height)
            context.drawImage(image, 0, 0, width, height)
            const dataUrl = canvas.toDataURL(file.type)
            const blobData = _this.dataURItoBlob(dataUrl, file.type)
            resolve(blobData)
          }
          reader.onload = e => { image.src = e.target.result }
          reader.readAsDataURL(file)
        })
      } else {
        return true
      }
    },
    dataURItoBlob (dataURI, type) {
      var binary = atob(dataURI.split(',')[1])
      var array = []
      for (var i = 0; i < binary.length; i++) {
        array.push(binary.charCodeAt(i))
      }
      return new Blob([new Uint8Array(array)], { type: type })
    },
    // 上传图片移除
    handleRemove (file, fileList) {
      // this.$emit('getImage', '')
      // this.$emit('getImageId', '')
      this.hideUpload = (this.imageList && this.limitNum === '1') ? (fileList.length >= 1) : false
    }
  }
}
</script>

<style lang='scss' scoped>
</style>
