<template>
  <el-cascader
    style="width: auto;"
    :props="{checkStrictly: true, value: 'id', label: 'name'}"
    :options="departments"
    :show-all-levels="false"
    :value="deptIds"
    placeholder="请输入"
    clearable
    @change="change"
  />
</template>

<script>
import * as api from '@/api/meeting/system'
export default {
  name: 'SelectDepartments',
  model: {
    event: 'change',
    prop: 'deptIds'
  },
  props: ['deptIds'],
  data () {
    return {
      departments: []
    }
  },
  mounted () {
    this.getDepartments()
  },
  methods: {
    async getDepartments () {
      const param = {
        appCode: process.env.VUE_APP_APP_CODE
      }
      const res = await api.getAllDept(param)
      this.departments = this.deleteEmptyChildren(res.data.data)
    },
    deleteEmptyChildren (root) {
      let stack = [{ children: root }]
      while (stack.length) {
        const current = stack.pop()
        if (current.children.length === 0) {
          delete current.children
        } else {
          stack = stack.concat(current.children)
        }
      }
      return root
    },
    change (result) {
      this.$emit('change', result)
    }
  }
}
</script>
