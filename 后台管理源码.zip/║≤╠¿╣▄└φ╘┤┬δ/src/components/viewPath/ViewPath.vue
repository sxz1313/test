<template>
  <div id="ViewPath">
    <div>{{ paths.join(' > ') }}{{ last ? ' > ' : '' }}<span
      style="color: #0066C5;"
    >{{ last }}</span></div>
    <div class="back">
      <el-button v-show="isForm" @click="$router.back()">关闭窗口</el-button>
    </div>
  </div>
</template>

<script>
import { headerTitleManage } from '@/utils/globalDefine'

export default {
  name: 'ViewPath',
  data () {
    return {
      paths: [],
      last: '',
      isForm: ''
    }
  },
  watch: {
    $route: {
      handler: function (to) {
        this.isForm = to.name === 'templateG6' || to.name === 'templateForm' || to.name === 'exceptionFlowG6'
        const routes = to.matched
        if (routes && routes.length > 0) {
          const headerTitle = headerTitleManage
          let firstName = ''
          try {
            firstName = headerTitle.find(item => item.module === routes[0].meta.module).name
          } catch (e) {
            // console.error('error: ViewPath.vue error module name: ', routes[0])
          }
          this.paths = routes.map(r => (r.meta || {}).title)
          firstName && this.paths.unshift(firstName)
          this.last = this.paths.pop()
          if (to.meta.edit && (to.query.type === 'edit' || to.query.handleType === 'edit')) {
            this.last = this.last.replace(/新增|添加/, '编辑')
            this.last = this.last.replace(/创建/, '修改')
          }
        }
      },
      immediate: true
    }
  }
}
</script>
<style lang="scss" scoped>
#ViewPath {
  font-size: 13px;
  display: flex;
  justify-content: space-between;

  .back {
    display: flex;
    align-items: center;

    p {
      margin-right: 10px;
      cursor: pointer;
    }
  }
}
</style>
