import User from '@/controller/User'
export default {
  install (Vue) {
    Vue.directive('perm-code', {
      async bind (el, binding, vnode) {
        const permissionList = JSON.parse(User.get('ids') || '[]')
        if (typeof (binding.value) === 'string' && permissionList.includes(binding.value)) {
          el.style.display = 'inline-block'
        } else {
          el.style.display = 'none'
        }
      }
    })
  }
}
