import Vue from 'vue'
import avatar from '@/assets/img/avatar-default.jpg'

Vue.directive('default-avatar', {
  bind (el) {
    el.src = avatar
    el.classList.add('no-zoom')
  },
  update (el, binding, vnode) {
    let img = new Image()
    img.onload = (e) => {
      el.src = img.src
      el.classList.remove('no-zoom')
      img = null
    }
    img.src = el.src
    el.src = avatar
  }
})

Vue.directive('number', {
  bind (el, binding, vnode) {
    el.oninput = function (e) {
      const exp = binding.expression.split('.')
      const last = exp.pop()
      const obj = exp.reduce((acc, cur, i, arr) => {
        if (acc) {
          return acc[cur]
        } else {
          return vnode.context[cur]
        }
      }, undefined)
      if (isNaN(Number(obj[last]))) {
        obj[last] = undefined
      } else {
        obj[last] = Number(obj[last])
      }
    }
  },
  unbind (el) {
    el.oninput = null
  }
})
