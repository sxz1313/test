export const states = [
  { name: '启用', id: 1 },
  { name: '禁用', id: 2 },
  { name: '注销', id: 3 }
]
export const jobStatus = [
  { name: '在职', id: 1 },
  { name: '离职', id: 2 },
  { name: '进修', id: 3 },
  { name: '退休', id: 4 },
  { name: '试用', id: 5 },
  { name: '返聘', id: 6 }
]
export function getStateName (id) {
  return states[id].name
}
export function getJobStatusName (id) {
  return jobStatus[id].name
}
// 验证输入金额
export function moneyLimit (val) {
  let num = val.toString() // 先转换成字符串类型
  if (num.indexOf('.') === 0) {
    // 第一位就是 .
    num = '0' + num
  }
  num = num.replace(/[^\d.]/g, '') // 清除“数字”和“.”以外的字符
  num = num.replace(/\.{2,}/g, '.') // 只保留第一个. 清除多余的
  num = num
    .replace('.', '$#$')
    .replace(/\./g, '')
    .replace('$#$', '.')
  num = num.replace(/^(\-)*(\d+)\.(\d\d).*$/, '$1$2.$3') // 只能输入两个小数
  if (num.indexOf('.') < 0 && num !== '') {
    num = parseFloat(num)
  }
  return num
}
// 不以0开头的数字
export function numLimit (val) {
  val = val.replace(/\.{1,}/gi, '')
  val = val.replace(/[^\d]/gi, '')
  val = val.replace(/^[0]+[0-9]*/gi, '')
  return val
}
// 验证输入金额
export function numLimit_1 (val) {
  let num = val.toString() // 先转换成字符串类型
  if (num.indexOf('0') === 0 && num.length > 1) { // 第一位就是 .
    num = num.substring(1)
  }
  num = num.replace(/\.{1,}/gi, '')
  num = num.replace(/[^\d]/gi, '')
  return num
}

export const install = (key, component) => {
  if (!key || !component) {
    return
  }
  // 自动加载组件
  window.Vue.component(key, component)
}
/**
 * json对象深拷贝
 * @param json
 */
export function jsonDeepCopy (json) {
  return JSON.parse(JSON.stringify(json))
}
export const ExtractAscOrZhChart = /^([\w\u4e00-\u9fa5-]*)/
export const ExtractIp = /^([0-9.]*)/
export const ExtractNameNumber = /^([\w-]*)/
export const ExtractTel = /^(1[0-9]*)/
export const ExtractPwd = /^([\w!@#$%^&*]+)/

export class SecCounter {
  constructor () {
    this.timer = undefined
  }

  // 启动倒计时
  start (second, resolve) {
    if (typeof second !== 'number') {
      throw new TypeError(
        'SecCounter: (second, resolve) seconde is not a number'
      )
    }
    resolve(SecCounter.getDate(second))
    this.timer = setInterval(() => {
      if (second > 0) {
        second--
        resolve(SecCounter.getDate(second))
        second === 0 && this.stop()
      } else {
        this.stop()
      }
    }, 1000)
  }

  // 关闭倒计时
  stop () {
    this.timer && clearInterval(this.timer)
  }

  // 倒计时计算
  static getDate (second) {
    const year = Math.floor(second / 31536000) // 365一年
    const days = Math.floor((second / 86400) % 365)
    const hours = Math.floor((second / 3600) % 24)
    const mins = Math.floor((second / 60) % 60)
    const sec = Math.floor(second % 60)
    return {
      year,
      days,
      hours,
      mins,
      sec
    }
  }
}

/**
 * @desc produce a constant length array
 * @param total {number} > 0
 * @param start {number} start index
 * @returns {Array.<number>}
 */
export const ranger = function (total, start = 0) {
  const r = []
  for (let i = start; i < total + start; i++) {
    r.push(i)
  }
  return r
}

/**
 * @desc 获取特定月份的总天数
 * @param month {number}
 * @param year {number}
 * @returns {Array.<number>}
 */
function getMonthTotalDays (month, year) {
  const totalDays = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]
  if (year % 4 === 0) {
    if (year % 100 === 0) {
      if (year % 400 === 0) {
        totalDays[1] = 29
      }
    } else {
      totalDays[1] = 29
    }
  }
  return totalDays[month - 1]
}
/**
 * @desc 生成日历
 * @param month
 * @param year
 * @param firstDay {number} 从星期几开始 星期日从0开始
 * @returns {Array}
 */
export const cal = function (
  month = new Date().getMonth() + 1,
  year = new Date().getFullYear(),
  firstDay
) {
  const total = getMonthTotalDays(month, year) // 当前月份的总天数
  const weekday = new Date(`${year}/${month}`).getDay() // 当月首日星期
  let row = ranger(total, 1)
  // 获取首部偏移量
  const offset = (weekday + 7 - firstDay) % 7
  const headOffset = new Array(offset)
  const endOffset = new Array((7 - ((total + offset) % 7)) % 7)
  row = headOffset.concat(row, endOffset)
  const r = []
  while (row.length > 0) {
    r.push(row.splice(0, 7))
  }
  return r
}
/**
 * @desc 日期换行
 * @param time {date}
 * @returns {String}
 */
export function dateFormatting (time) {
  const timeList = time
    ? this.$format(time, 'yyyy-MM-dd HH:mm:ss').split(' ')
    : ''
  const timeText = timeList ? `${timeList[0]}\n${timeList[1]}` : ''
  return timeText
}
/**
 * @desc 获取年份列表
 * @param startYear {Number}
 * @param endYear {Number}
 * @returns {Array}
 */
export function getYearList (startYear, endYear) {
  const yearList = []
  for (var i = endYear; i >= startYear; i--) {
    yearList.push(i)
  }
  return yearList
}

export const getCurrentNodeKey = function (treeList, selectId) {
  var curNodeKey = selectId
  ;(treeList || []).forEach((ele) => {
    if (curNodeKey) return
    curNodeKey = ele.id || ele.roleId
  })
  return curNodeKey
}
/**
 * @desc 数字逗号隔开
 * @param val {Number}
 * @param digit {Number}
 * @returns {Array}
 */
export function fmoney (val, digit) {
  var num = parseFloat((val + '').replace(/[^\d\.-]/g, '')).toFixed(digit) + ''
  var l = num
    .split('.')[0]
    .split('')
    .reverse()
  var r = num.split('.')[1] || null
  var t = ''
  for (var i = 0; i < l.length; i++) {
    t += l[i] + ((i + 1) % 3 === 0 && i + 1 !== l.length ? ',' : '')
  }
  return (
    t
      .split('')
      .reverse()
      .join('') + (digit > 0 && r > 0 ? '.' + r : '')
  )
}
/**
 * 授权人员Tree树数据整合->支持单选,所有父节点disabled
 *
 */
export function userTreeRadio (ele) {
  for (var i in ele) {
    if (ele[i].children.length > 0) {
      userTreeRadio(ele[i].children)
    }
    if (ele[i].userList.length > 0) {
      ele[i].userList.forEach((element) => {
        if (element.status !== 1) {
          element.disabled = true
        }
      })
      ele[i].children = [...ele[i].children, ...ele[i].userList]
    }
    if (ele[i].children.length !== 0 || ele[i].type === 0) {
      ele[i].disabled = true
    }
  }
}
/**
 * 授权人员Tree树数据整合->支持单选,所有父节点disabled,放开所有子节点
 *
 */
export function userTreeAllOpen (ele) {
  for (var i in ele) {
    if (ele[i].children.length > 0) {
      userTreeAllOpen(ele[i].children)
    }
    if (ele[i].userList.length > 0) {
      ele[i].userList.forEach((element) => {
        if (element.status !== 1) {
          // element.disabled = true
        }
      })
      ele[i].children = [...ele[i].children, ...ele[i].userList]
    }
    if (ele[i].children.length !== 0 || ele[i].type === 0) {
      ele[i].disabled = true
    }
  }
}

/**
 * 授权人员Tree树数据整合
 *
 */
export function userTree (ele) {
  for (var i in ele) {
    if (ele[i].children.length > 0) {
      userTree(ele[i].children)
    }
    if (ele[i].userList.length > 0) {
      ele[i].userList.forEach((element) => {
        if (element.status !== 1) {
          element.disabled = true
        }
      })
      ele[i].children = [...ele[i].children, ...ele[i].userList]
    }
    if (ele[i].children.length === 0 && ele[i].type === 0) {
      ele[i].disabled = true
    }
  }
}

/**
 * 授权部门Tree树数据整合->支持单选,所有父节点disabled
 *
 */
export function departmentTreeRadio (ele) {
  for (var i in ele) {
    if (ele[i].children && ele[i].children.length > 0) {
      ele[i].disabled = true
      departmentTreeRadio(ele[i].children)
    } else {
      delete ele[i].children
    }
  }
}

/**
 * 授权部门Tree树数据整合
 *
 */
export function departmentTree (ele) {
  for (var i in ele) {
    if (ele[i].children.length > 0) {
      departmentTree(ele[i].children)
    } else {
      delete ele[i].children
    }
  }
}
// 修善后台数据结构,去除结尾空数组children字段
export const deleteEmptyChildren = function (roles) {
  const stack = [{ children: roles }]
  while (stack.length) {
    const current = stack.shift()
    if (current.children.length === 0) {
      delete current.children
    } else {
      stack.unshift(...current.children)
    }
  }
  return roles
}
// 部门级联选择器回显
export const seekDeptPath = function (allDept, deptId) {
  let path = []
  if (deptId) {
    const all = allDept.slice(0) // copy param allDept
    const depthCount = [all.length] // 记录层级深度，已经每个层级上的计数
    while (all.length) {
      const cur = all.pop()
      depthCount[depthCount.length - 1]-- // 当前深度引用数减一
      path[depthCount.length - 1] = cur.id // 当前深度记录其引用的id
      if (cur.id === deptId) {
        break
      }
      if (cur.children && cur.children.length) {
      // 存在children，增加层级深度，并记录引用数量
        all.push(...cur.children)
        depthCount.push(cur.children.length)
      }
      // 最后一个引用数量为零的时候，重新调整深度和id记录
      while (depthCount.length && depthCount[depthCount.length - 1] === 0) {
        depthCount.pop()
      }
      path = path.slice(0, depthCount.length)
    }
  }
  return path
}
