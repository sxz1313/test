export function name (rule, val, cb) {
  if (!val) {
    cb()
    return
  }
  if (!/^[a-zA-Z0-9\u4e00-\u9fa5 ]+$/.test(val)) {
    cb(new Error('只支持字母和中文'))
    return
  }
  if (/^ /.test(val) || / $/.test(val)) {
    cb(new Error('不能以空格开头和结尾'))
    return
  }
  cb()
}

export function code (rule, val, cb) {
  if (!val) {
    cb()
    return
  }
  if (!/^[a-zA-Z0-9]+$/.test(val)) {
    cb(new Error('只支持字母和数字'))
    return
  }
  if (/^ /.test(val) || / $/.test(val)) {
    cb(new Error('不能以空格开头和结尾'))
    return
  }
  cb()
}

export function phone (rule, val, cb) {
  if (!val) {
    cb()
    return
  }
  if (!/^1[0-9]{10}$/.test(val)) {
    cb(new Error('手机号格式不正确'))
    return
  }
  cb()
}

export function homePhone (rule, val, cb) {
  if (!val) {
    cb()
    return
  }
  // eslint-disable-next-line no-useless-escape
  if (!/^[0-9]{3,4}\-[0-9]{8}$/.test(val)) {
    cb(new Error('座机格式不正确'))
    return
  }
  cb()
}

export function email (rule, val, cb) {
  if (!val) {
    cb()
    return
  }
  /**
   * 字符@前后必为\w内容，邮箱地址最后一项必为\w
   * 1@1 pass
   * a.a@a pass
   * a.a@a.a pass
   * ^[A-Za-z0-9\u4e00-\u9fa5]+@[a-zA-Z0-9_-]+(\.[a-zA-Z0-9_-]+)+$
   * 1.@. error
   */
  if (!/^[A-Za-z0-9\u4e00-\u9fa5]+@[a-zA-Z0-9_-]+(\.[a-zA-Z0-9_-]+)+$/.test(val)) {
    cb(new Error('邮箱格式不正确'))
    return
  }
  cb()
}

export function qq (rule, val, cb) {
  if (!val) {
    cb()
    return
  }
  if (!/^[0-9]{1,20}$/.test(val)) {
    cb(new Error('qq号格式不正确'))
    return
  }
  cb()
}

export function weixin (rule, val, cb) {
  if (!val) {
    cb()
    return
  }
  if (!/^[\w]{1,20}$/.test(val)) {
    cb(new Error('微信号格式不正确'))
    return
  }
  cb()
}

export function postcode (rule, val, cb) {
  if (!val) {
    cb()
    return
  }
  if (!/^[0-9]{1,6}$/.test(val)) {
    cb(new Error('邮编格式不正确'))
    return
  }
  cb()
}

export function number (rule, val, cb) {
  if (!val) {
    cb()
    return
  }
  if (!/^[0-9]+$/.test(val)) {
    cb(new Error('全部为数字'))
    return
  }
  cb()
}

export function positiveInteger (rule, val, cb) {
  if (!val) {
    cb()
    return
  }
  if (!/^[0-9]+$/.test(Number(val))) {
    cb(new Error('数字为正整数'))
    return
  }
  cb()
}
export function positiveInt (rule, val, cb) {
  if (!val) {
    cb()
    return
  }
  if (!/^[1-9]\d*$/.test(Number(val))) {
    cb(new Error('数字为正整数'))
    return
  }
  cb()
}

export function positiveNumber (rule, val, cb) {
  if (!val) {
    cb()
    return
  }
  if (!/^[1-9][0-9]*$|^[0-9]+\.[0-9]+$/.test(val)) {
    cb(new Error('数字为整数或小数'))
    return
  }
  cb()
}

export function idCard (rule, val, cb) {
  if (!val) {
    cb()
    return
  }
  if (!/^[0-9xX]{18}$|^[0-9xX]{15}$/.test(val)) {
    cb(new Error('身份证格式不正确'))
    return
  }
  cb()
}
