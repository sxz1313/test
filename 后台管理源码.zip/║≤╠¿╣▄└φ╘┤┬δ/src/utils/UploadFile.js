import * as api from '@/api/common'

export default class UploadFile {
  static IMG_FILE_TYPE = '.jpg, .png, .jpeg, .gif'
  static EXCEL_FILE_TYPE = '.xls, .xlsx'
  static ZIP_FILE_TYPE = '.zip'
  static EXCEL_ZIP_FILE_TYPE = '.zip, .xls, .xlsx'

  constructor (...fileType) {
    this.input = document.createElement('input')
    this.a = document.createElement('a')
    this.fileType = fileType.join(', ') || '*'
    this.input.type = 'file'
    this.input.accept = this.fileType
    this.file = null // 单个文件
    this.files = [] // 多个文件
  }

  selectSingleFile () {
    return new Promise((resolve, reject) => {
      this.input.multiple = false
      const self = this
      this.input.onchange = function () {
        self.file = this.files[0]
        if (UploadFile.isValidateFile(self.file, self.fileType)) {
          self.file.prettySize = UploadFile.getFileSize(self.file.size)
          resolve(self.file)
        } else {
          reject(new TypeError(`不是${self.fileType}格式文件`))
        }
        this.value = null
      }
      this.input.click()
    })
  }

  generateImgLocalUrl () {
    return window.URL.createObjectURL(this.file)
  }

  /**
   * 上传单个文件
   * @param resultType {string} 0 返回id 1 返回url
   * @returns {Promise<string>}
   */
  async uploadFileApi (resultType) {
    if (!this.file) {
      throw new Error('请选择文件')
    }
    const formData = new FormData()
    formData.append('file', this.file)
    formData.append('resultType', resultType) // 1: url 0: id
    const res = await api.fileUpload(formData)
    return res.data.data
  }

  static isValidateFile (file, fileType) {
    const reg = new RegExp(`\\.(${fileType.match(/[\w]*/g).join('|')})$`)
    return reg.test(file.name)
  }

  static getFileSize (number) {
    if (number < 1024) {
      return number + 'bytes'
    } else if (number > 1024 && number < 1048576) {
      return (number / 1024).toFixed(1) + 'KB'
    } else if (number > 1048576) {
      return (number / 1048576).toFixed(1) + 'MB'
    }
  }

  /**
   * 是否是本地生成的地址
   * @param src
   * @returns {boolean}
   */
  static isLocalUrl (src) {
    return /^blob:/.test(src)
  }
}

export function downloadBlob (blob, filename) {
  const a = document.createElement('a')
  a.download = filename
  a.href = window.URL.createObjectURL(blob)
  a.click()
}

// 文件url下载
export function download (url, filename) {
  var elink = document.createElement('a')
  elink.download = filename
  elink.href = url
  document.body.appendChild(elink)
  elink.click()
  document.body.removeChild(elink)
}
