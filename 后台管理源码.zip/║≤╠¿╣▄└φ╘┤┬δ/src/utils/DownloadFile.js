export default class DownloadFile {
  static download (url) {

  }
}
