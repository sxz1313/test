import * as api from '@/api/common'

const state = {
  provinceList: [],
  cityList: [],
  areaList: []
}
const getters = {
  provinceList: state => state.provinceList,
  cityList: state => state.cityList,
  areaList: state => state.areaList
}
const mutations = {
  setProvinceList (state, val) {
    state.provinceList = val
  },
  setCityList (state, val) {
    state.cityList = val
  },
  setAreaList (state, val) {
    state.areaList = val
  }
}
const actions = {
  // 获取所有的省份信息
  async getProvinceList ({ commit }) {
    const res = (await api.getProvinceList()).data.data
    commit('setProvinceList', res)
  },
  // 获取省份下的地市信息
  async getCityList ({ commit }, provinceCode) {
    const res = (await api.getCityList(provinceCode)).data.data
    commit('setCityList', res)
  },
  // 获取省份下的地市信息
  async getAreaList ({ commit }, cityCode) {
    const res = (await api.getAreaList(cityCode)).data.data
    commit('setAreaList', res)
  }
}

export default {
  namespaced: true,
  getters,
  state,
  actions,
  mutations
}
