// import * as api from '@/api/meeting/system'

/**
 * 字典数据请求缓存存储
 * 当刷新页面的时候，通知字典缓存更新
 * 后期每次获得数据，直接从缓存中获取
 */
const state = {
  dicts: {}
}
const getters = {
  /**
   * 根据key获取字典项
   * @returns {function(*): *}
   */
  get (state) {
    return key => {
      return (state.dicts || {})[key]
    }
  }
}
const mutations = {
  setDicts (state, val) {
    state.dicts = val
  }
}
const actions = {
  async getDictByCode ({ state, commit, dispatch, getters }, code) {
    if (!getters.get(code)) {
      await dispatch('getAllDicts')
    }
    return getters.get(code)
  },
  async getAllDicts ({ commit }) {
    // const res = (await api.dictList()).data.data
    const dict = {}
    // res.forEach(ele => {
    //   dict[ele.dictTypeCode] = ele.dictDataList
    // })
    commit('setDicts', dict)
  }
}

export default {
  namespaced: true,
  getters,
  state,
  actions,
  mutations
}
