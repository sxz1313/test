
const state = {
  storeActive: ''
}
const getters = {
  storeActive: state => state.storeActive
}
const mutations = {
  setTabActive (state, val) {
    state.storeActive = val
  },
  delCityList (state, val) {
    state.storeActive = ''
  }
}
const actions = {
}

export default {
  namespaced: true,
  getters,
  state,
  actions,
  mutations
}
