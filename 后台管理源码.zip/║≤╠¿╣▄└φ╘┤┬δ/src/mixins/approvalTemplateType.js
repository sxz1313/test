import * as api from '@/api/approval'

class TemplateType {
  constructor ({ id, templateName } = {}) {
    this.id = id
    this.name = templateName
  }
}

export default {
  data () {
    return {
      templateType: []
    }
  },
  mounted () {
    this.getTemplateType()
  },
  methods: {
    clearTemplateType () {
      this.templateType = []
    },
    getTemplateType () {
      api.getApprovalTemplateName()
        .then(res => {
          this.templateType = (res.data.data || []).map(item => new TemplateType(item))
        })
    }
  }
}
