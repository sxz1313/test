import * as api from '@/api/approval'

class TemplateType {
  constructor ({ id, name } = {}) {
    this.id = id
    this.name = name
  }
}

export default {
  data () {
    return {
      templateType: []
    }
  },
  mounted () {
    this.getTemplateType()
  },
  methods: {
    clearTemplateType () {
      this.templateType = []
    },
    getTemplateType () {
      api.getBusinessFormListAll()
        .then(res => {
          this.templateType = (res.data.data || [])
            .map(item => new TemplateType(item))
        })
    }
  }
}
