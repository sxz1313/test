<template>
  <div class="review pb-20">
    <div class="title">
      <strong
        class="font-size-18"
      >人才档案详情</strong>
      <el-button @click="$router.back()">返回</el-button>
    </div>
    <el-divider />
    <div class="content mt-20 px-30">
      <div class="text-center">
        <el-button type="primary" @click="check('1')">通过</el-button>
        <el-button @click="check('2')">不通过</el-button>
      </div>
      <div
        v-for="(item, index) in labels"
        :key="index"
      >
        <p class="name my-20 pl-10">{{ item.name }}</p>
        <component
          :is="item.component"
          :ref="`component${index}`"
          :is-review="true"
          @cut="cut"
        />
      </div>
    </div>
  </div>
</template>
<script>
import Unit from '../components/unit.vue'
import BasicInfo from '../components/basicInfo.vue'
import Education from '../components/education.vue'
import Practice from '../components/practice.vue'
import WorkExperience from '../components/workExperience.vue'
import PoliticalLandscape from '../components/politicalLandscape.vue'
import AnnualAssessment from '../components/annualAssessment.vue'
import HonoraryTitle from '../components/honoraryTitle.vue'
import ExpertTitle from '../components/expertTitle.vue'
import Disciplinary from '../components/disciplinary.vue'
import LanguageAbility from '../components/languageAbility.vue'
import TrainingEducation from '../components/trainingEducation.vue'
import MainThesis from '../components/mainThesis.vue'
import ResearchResult from '../components/researchResult.vue'
import Patent from '../components/patent.vue'
import AcademicBody from '../components/academicBody.vue'
import TrainGraduateStudent from '../components/trainGraduateStudent.vue'
import FamilyMember from '../components/familyMember.vue'
import * as talentReviewApi from '@/api/talentReview'
export default {
  name: 'Review',
  components: {
    Unit,
    BasicInfo,
    Education,
    Practice,
    WorkExperience,
    PoliticalLandscape,
    AnnualAssessment,
    HonoraryTitle,
    ExpertTitle,
    Disciplinary,
    LanguageAbility,
    TrainingEducation,
    MainThesis,
    ResearchResult,
    Patent,
    AcademicBody,
    TrainGraduateStudent,
    FamilyMember
  },
  data () {
    return {
      param: {},
      labels: [
        {
          name: '单位信息',
          component: 'Unit'
        },
        {
          name: '人员基本信息',
          component: 'BasicInfo'
        },
        {
          name: '学历及学位[从高中（中专)起]',
          component: 'Education'
        },
        {
          name: '取得专业技术职称、职（执）业资格情况',
          component: 'Practice'
        },
        {
          name: '个人工作经历',
          component: 'WorkExperience'
        },
        {
          name: '政治面貌（党派）情况',
          component: 'PoliticalLandscape'
        },
        {
          name: '年度考核情况（填写近五年情况）',
          component: 'AnnualAssessment'
        },
        {
          name: '荣誉称号（奖励）情况',
          component: 'HonoraryTitle'
        },
        {
          name: '荣获专家称号情况',
          component: 'ExpertTitle'
        },
        {
          name: '惩戒（处分）情况',
          component: 'Disciplinary'
        },
        {
          name: '语言能力',
          component: 'LanguageAbility'
        },
        {
          name: '培训教育情况',
          component: 'TrainingEducation'
        },
        {
          name: '主要论文及著作情况',
          component: 'MainThesis'
        },
        {
          name: '获得科研成果情况',
          component: 'ResearchResult'
        },
        {
          name: '获得专利情况',
          component: 'Patent'
        },
        {
          name: '参加学术团体情况',
          component: 'AcademicBody'
        },
        {
          name: '培养研究生情况',
          component: 'TrainGraduateStudent'
        },
        {
          name: '家庭成员及主要社会关系',
          component: 'FamilyMember'
        }
      ]
    }
  },
  mounted () {
    this.param = this.$route.query
  },
  methods: {
    check (type) {
      talentReviewApi.reviewTalent({
        ids: [this.param.talentApplyId],
        isPass: type === '1'
      }).then(res => {
        this.$message.success('审核成功')
        this.$router.back()
      })
    }
  }
}
</script>
<style lang="scss" scoped>
.review{
  background: #fff;
   .title {
    padding: 0 30px;
    display: flex;
    justify-content: space-between;
    line-height: 32px;
    height: 32px;
    color: #111;
  }
  .content {
    .name {
      border-left: 2px solid #1890ff;
      color: #666;
      line-height: 20px;
    }
  }
  .el-divider--horizontal {
    margin: 5px 0;
  }
}
</style>
