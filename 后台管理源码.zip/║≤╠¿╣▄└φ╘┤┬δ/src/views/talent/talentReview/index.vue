<template>
  <div class="commonContainer">
    <div class="header">
      <el-form :inline="true" :model="formInline" class="list-filter-wrap">
        <el-form-item label="姓名：">
          <el-input
            v-model.trim="filter.name"
            placeholder="请输入姓名"
            maxlength="30"
            clearable
          />
        </el-form-item>
        <el-form-item label="手机号：">
          <el-input
            v-model.trim="filter.mobile"
            placeholder="请输入手机号"
            maxlength="11"
            clearable
          />
        </el-form-item>
        <el-form-item label="学历：">
          <el-select clearable v-model="filter.educationLevel" placeholder="请选择">
            <el-option
              v-for="item in educationLevels"
              :key="item.id"
              :label="item.name"
              :value="item.id"
            />
          </el-select>
        </el-form-item>
        <el-form-item label="性别：">
          <el-select clearable v-model="filter.sex" placeholder="请选择">
            <el-option
              v-for="item in sexs"
              :key="item.id"
              :label="item.name"
              :value="item.id"
            />
          </el-select>
        </el-form-item>
        <el-form-item label="单位：">
          <el-select
            ref="select"
            v-model="filter.companyId"
            filterable
            remote
            clearable
            placeholder="请输入"
            :remote-method="remoteMethod"
            :loading="loading"
            @change="selectChange"
            @focus="changeCom"
          >
            <el-option
              v-for="(item, index) in units"
              :key="index"
              :label="item.name"
              :value="item.id"
            />
          </el-select>
        </el-form-item>
        <el-form-item>
          <el-button type="primary" @click="search">查询</el-button>
          <el-button @click="reset">重置</el-button>
        </el-form-item>
      </el-form>
    </div>
    <div class="content list-content-wrap">
      <div class="mb-1">
        <el-button
          v-perm-code="'1527089427657064451'"
          type="primary"
          :disabled="selectData.length === 0"
          @click="reviews"
        >批量审核</el-button>
      </div>
      <TableSelection
        :head-list="headList"
        :table-list="tableList"
        auth-id="1527089427657064450"
        @handleSelection="handleSelection"
      >
        <div slot="button" slot-scope="props">
          <el-button v-perm-code="'1527089427657064450'" type="text" @click="review(props.scope)">审核</el-button>
        </div>
      </TableSelection>
      <pagination :page-param="filter" @pageChange="pageChange" />
    </div>
    <el-dialog
      v-if="reViewVisible"
      title="批量审核"
      width="40%"
      :close-on-click-modal="false"
      :visible.sync="reViewVisible"
    >
      <el-form
        ref="ruleForm"
        :model="ruleForm"
        :rules="rules"
        label-width="130px"
      >
        <el-form-item label="审核日期：">{{ ruleForm.date }}</el-form-item>
        <el-form-item label="审核人数：">{{ ruleForm.num }}</el-form-item>
        <el-form-item>
          <el-button @click="submitForm('ruleForm', false)">不通过</el-button>
          <el-button type="primary" @click="submitForm('ruleForm', true)">审核通过</el-button>
        </el-form-item>
      </el-form>
    </el-dialog>
  </div>
</template>
<script>
import TableSelection from '@/components/table/TableSelection'
import pagination from '@/components/pagination/index'
import * as api from '@/api/company'
import * as common from '@/api/common'
export default {
  components: {
    TableSelection,
    pagination
  },
  data () {
    return {
      filter: {
        mobile: '',
        name: '',
        pageSize: 10,
        pageNo: 1,
        total: 0
      },
      sexs: [],
      units: [],
      educationLevels: [],
      reViewVisible: false,
      selectData: [],
      headList: [
        { prop: 'name', label: '姓名' },
        { prop: 'mobile', label: '手机号' },
        { prop: 'companyName', label: '单位名称' },
        { prop: 'auditStatusLabel', label: '状态' },
        { prop: 'updateTime', label: '提交时间' }
      ],
      tableList: [],
      ruleForm: {
        date: this.$format(new Date(), 'yyyy-MM-dd'),
        num: ''
      },
      rules: {}
    }
  },
  created () {
    this.initList()
    common.queryByType({ type: 'sex' }).then(({ data }) => {
      this.sexs = data.data
    })
    common.queryByType({ type: 'educational_level' }).then(({ data }) => {
      this.educationLevels = data.data
    })
  },
  methods: {
    changeCom () {
      if (!this.filter.companyId) {
        this.units = []
      }
    },
    selectChange () {
      if (!this.filter.companyId) {
        this.filter.companyId = ''
        this.units = []
      }
    },
    remoteMethod (text) {
      if (text !== '') {
        api.queryByNameNoToken({
          name: text
        }).then(({ data }) => {
          this.units = data.data
        })
      } else {
        this.units = []
      }
    },
    submitForm (formName, falg) {
      this.$refs[formName].validate((valid) => {
        if (valid) {
          const ids = []
          this.selectData.forEach((item) => {
            ids.push(item.id)
          })
          const param = {
            ids: ids,
            isPass: falg
          }
          api.auditTalentApply(param).then(({ data }) => {
            this.reViewVisible = false
            this.$message.success('操作成功')
            this.reset()
          })
        }
      })
    },
    selectionDisabled (row, index) {
      return row.auditStatus === 2
    },
    // 表格选择
    handleSelection (val) {
      this.selectData = val
    },
    reviews () {
      this.ruleForm.num = this.selectData.length
      this.reViewVisible = true
    },
    review (row) {
      this.$router.push({
        name: 'talentReviewReview',
        query: {
          handleType: 'view',
          talentApplyId: row.id
        }
      })
    },
    pageChange (pageNo) {
      this.filter.pageNo = Number(pageNo)
      this.initList()
    },
    search () {
      this.pageChange(1)
    },
    initList () {
      api.talentApplyPage(this.filter).then(({ data }) => {
        this.tableList = []
        data.data.rows.forEach((item) => {
          if (item.company) {
            item.companyName = item.company.name
          } else {
            item.companyName = ''
          }
          if (item.auditStatus === 2) {
            this.tableList.push(item)
          }
        })
        this.filter.total = Number(data.data.totalRows)
      })
    },
    // 重置
    reset () {
      this.filter.name = ''
      this.filter.mobile = ''
      this.filter.sex = ''
      this.filter.educationLevel = ''
      this.filter.companyId = ''
      this.pageChange(1)
    }
  }
}
</script>
