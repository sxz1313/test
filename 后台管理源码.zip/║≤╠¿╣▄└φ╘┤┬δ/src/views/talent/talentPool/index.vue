<template>
  <div class="commonContainer">
    <div class="header">
      <el-form :inline="true" :model="formInline" class="list-filter-wrap">
        <el-form-item label="姓名：">
          <el-input
            v-model.trim="filter.name"
            placeholder="请输入姓名"
            maxlength="30"
            clearable
          />
        </el-form-item>
        <el-form-item label="手机号：">
          <el-input
            v-model.trim="filter.mobile"
            placeholder="请输入手机号"
            maxlength="11"
            clearable
          />
        </el-form-item>
        <el-form-item label="学历：">
          <el-select v-model="filter.educationLevel" clearable placeholder="请选择">
            <el-option
              v-for="item in educationLevels"
              :key="item.id"
              :label="item.name"
              :value="item.id"
            />
          </el-select>
        </el-form-item>
        <el-form-item label="性别：">
          <el-select v-model="filter.sex" clearable placeholder="请选择">
            <el-option
              v-for="item in sexs"
              :key="item.id"
              :label="item.name"
              :value="item.id"
            />
          </el-select>
        </el-form-item>
        <el-form-item label="单位：">
          <el-select
            ref="select"
            v-model="filter.companyId"
            filterable
            remote
            clearable
            placeholder="请输入"
            :remote-method="remoteMethod"
            :loading="loading"
            @change="selectChange"
            @focus="changeCom"
          >
            <el-option
              v-for="(item, index) in units"
              :key="index"
              :label="item.name"
              :value="item.id"
            />
          </el-select>
        </el-form-item>
        <el-form-item label="学位：">
          <el-select v-model="filter.degree" clearable placeholder="请选择">
            <el-option
              v-for="item in degrees"
              :key="item.id"
              :label="item.name"
              :value="item.id"
            />
          </el-select>
        </el-form-item>
        <el-form-item label="专业类别：">
          <el-select v-model="filter.professionalCategory" clearable placeholder="请选择">
            <el-option
              v-for="item in professionals"
              :key="item.id"
              :label="item.name"
              :value="item.id"
            />
          </el-select>
        </el-form-item>
        <el-form-item label="荣耀称号：">
          <el-input
            v-model.trim="filter.expertHonorName"
            placeholder="请输入荣耀称号"
            maxlength="30"
            clearable
          />
        </el-form-item>
        <el-form-item label="职务：">
          <el-cascader
            ref="position"
            v-model="filter.positions"
            placeholder="请选择职务"
            :props="technicalPositionProps"
            clearable
          />
        </el-form-item>
        <el-form-item label="出生日期：">
          <el-date-picker
            v-model="filter.date"
            type="monthrange"
            :unlink-panels="true"
            range-separator="至"
            start-placeholder="开始月份"
            end-placeholder="结束月份"
            format="yyyy年MM月"
            value-format="yyyyMM"
          />
        </el-form-item>
        <el-form-item>
          <el-button type="primary" @click="search">查询</el-button>
          <el-button @click="reset">重置</el-button>
        </el-form-item>
      </el-form>
    </div>
    <div class="content list-content-wrap">
      <div class="mb-1">
        <el-button v-perm-code="'1527089428533673986'" type="primary" @click="download">导出</el-button>
      </div>
      <TableCommon
        :head-list="headList"
        :table-list="tableList"
        :filter="filter"
        auth-id="1527089428533673987"
      >
        <div slot="button" slot-scope="props">
          <el-button v-perm-code="'1527089428533673988'" type="text" @click="check(props.scope)">查看</el-button>
          <el-button
            v-if="props.scope.status === 0"
            v-perm-code="'1527089428533673987'"
            type="text"
            @click="cancel(props.scope)"
          >退会</el-button>
        </div>
      </TableCommon>
      <div class="pageStyle">
        <pagination :page-param="filter" @pageChange="pageChange" />
        <div v-show="filter.total > 0" class="total">人才总数：{{ filter.total }}人</div>
      </div>
    </div>
  </div>
</template>
<script>
import TableCommon from '@/components/table/TableCommon'
import pagination from '@/components/pagination/index'
import * as api from '@/api/company'
import * as common from '@/api/common'
import * as downloadFile from '@/utils/UploadFile'
export default {
  components: {
    TableCommon,
    pagination
  },
  data () {
    return {
      filter: {
        date: [],
        birthdayEnd: '',
        birthdayStart: '',
        degree: '',
        expertHonorName: '',
        professionalCategory: '',
        positions: '',
        position: '',
        mobile: '',
        name: '',
        educationLevel: '',
        companyId: '',
        sex: '',
        pageSize: 10,
        pageNo: 1,
        total: 0
      },
      sexs: [],
      degrees: [],
      units: [],
      professionals: [],
      educationLevels: [],
      technicalPositionProps: {
        label: 'name',
        value: 'id',
        lazy: true,
        lazyLoad (node, resolve) {
          const { level, value } = node
          var nodes = []
          if (level === 0) {
            common
              .queryByType({
                type: 'position'
              })
              .then(({ data }) => {
                nodes = data.data
                nodes.forEach((item) => {
                  if (!item.hasSubs) {
                    item.leaf = level >= 0
                  } else {
                    item.leaf = level >= 2
                  }
                })
                resolve(nodes)
              })
          } else if (level === 1) {
            common
              .queryByType({
                id: value
              })
              .then(({ data }) => {
                nodes = data.data
                nodes.forEach((item) => {
                  if (!item.hasSubs) {
                    item.leaf = level >= 1
                  } else {
                    item.leaf = level >= 2
                  }
                })
                resolve(nodes)
              })
          } else if (level === 2) {
            common
              .queryByType({
                id: value
              })
              .then(({ data }) => {
                nodes = data.data
                nodes.forEach((item) => {
                  item.leaf = level >= 2
                })
                resolve(nodes)
              })
          }
        }
      },
      headList: [
        { prop: 'name', label: '姓名' },
        { prop: 'mobile', label: '手机号' },
        { prop: 'companyName', label: '单位名称' },
        { prop: 'auditStatusLabel', label: '状态' },
        { prop: 'updateTime', label: '提交时间' }
      ],
      tableList: []
    }
  },
  created () {
    this.initList()
    common.queryByType({ type: 'sex' }).then(({ data }) => {
      this.sexs = data.data
    })
    common.queryByType({ type: 'degree' }).then(({ data }) => {
      this.degrees = data.data
    })
    common.queryByType({ type: 'professional_category' }).then(({ data }) => {
      this.professionals = data.data
    })
    common.queryByType({ type: 'educational_level' }).then(({ data }) => {
      this.educationLevels = data.data
    })
  },
  methods: {
    changeCom () {
      if (!this.filter.companyId) {
        this.units = []
      }
    },
    selectChange () {
      if (!this.filter.companyId) {
        this.filter.companyId = ''
        this.units = []
      }
    },
    remoteMethod (text) {
      if (text !== '') {
        this.loading = true
        api.queryByNameNoToken({
          name: text
        }).then(({ data }) => {
          this.loading = false
          this.units = data.data
        })
      } else {
        this.units = []
      }
    },
    download () {
      api.exportList(this.filter).then((res) => {
        downloadFile.downloadBlob(res.data, '人才信息.xlsx')
      })
    },
    check (row) {
      this.$router.push({
        name: 'talentPoolDetail',
        query: {
          handleType: 'view',
          talentApplyId: row.id
        }
      })
    },
    pageChange (pageNo) {
      this.filter.pageNo = Number(pageNo)
      this.initList()
    },
    initList () {
      this.filter.birthdayStart = this.filter.date && this.filter.date.length ? this.filter.date[0] : ''
      this.filter.birthdayEnd = this.filter.date && this.filter.date.length ? this.filter.date[1] : ''
      this.filter.position = this.filter.positions[this.filter.positions.length - 1]
      api.talentMangePage(this.filter).then(({ data }) => {
        this.tableList = (data.data.rows || []).map((item) => {
          if (item.company) {
            item.companyName = item.company.name
          } else {
            item.companyName = ''
          }
          return item
        })
        this.filter.total = Number(data.data.totalRows)
      })
    },
    cancel (row) {
      this.$confirm('确认退会?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        api.exitClub(row.id).then(({ data }) => {
          this.$message({
            type: 'success',
            message: '退会成功!'
          })
          this.reset(1)
        })
      }).catch(() => {
        this.$message({
          type: 'info',
          message: '已取消退会'
        })
      })
    },
    search () {
      this.pageChange(1)
    },
    // 重置
    reset () {
      this.filter.mobile = ''
      this.filter.name = ''
      this.filter.sex = ''
      this.filter.educationLevel = ''
      this.filter.companyId = ''
      this.filter.birthdayStart = ''
      this.filter.birthdayEnd = ''
      this.filter.degree = ''
      this.filter.expertHonorName = ''
      this.filter.professionalCategory = ''
      this.filter.position = ''
      this.filter.positions = []
      this.filter.date = []
      this.pageChange(1)
    }
  }
}
</script>
<style lang="scss" scoped>
  .pageStyle /deep/ {
    position: relative;
    .total {
      position: absolute;
      padding: 10px 0;
      line-height: 28px;
      right: 10px;
      top: 0;
    }
  }
</style>
