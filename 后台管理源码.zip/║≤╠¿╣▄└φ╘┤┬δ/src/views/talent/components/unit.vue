<template>
  <div class="unit">
    <el-form
      ref="ruleForm"
      class="ruleForm"
      :model="ruleForm"
      inline
      :rules="param.handleType !== 'view' ? rules : {}"
      label-width="130px"
    >
      <el-form-item label="单位名称:" prop="companyId">
        <div v-if="param.handleType !== 'view'">
          <div v-if="!$user.get('companyId')">
            <el-select
              ref="select"
              v-model="ruleForm.companyId"
              filterable
              remote
              clearable
              placeholder="请输入"
              :remote-method="remoteMethod"
              :loading="loading"
              @change="unitChange"
            >
              <el-option
                v-for="(item, index) in units"
                :key="index"
                :label="item.name"
                :value="item.id"
              />
            </el-select>
          </div>
          <div v-else>
            <el-input
              v-model="ruleForm.companyName"
              readonly
            />
          </div>
        </div>
        <div v-else class="value w-300">{{ ruleForm.company && ruleForm.company.name }}</div>
      </el-form-item>
      <el-form-item label="统一社会信用代码:" prop="socialCreditCode">
        <el-input
          v-if="param.handleType !== 'view'"
          v-model="ruleForm.socialCreditCode"
          readonly
        />
        <div v-else class="value  w-300">{{ ruleForm.company && ruleForm.company.socialCreditCode }}</div>
      </el-form-item>
    </el-form>
  </div>
</template>
<script>
import * as talentApi from '@/api/talent'
import * as talentReviewApi from '@/api/talentReview'
import * as loginApi from '@/api/login'
export default {
  name: 'Unit',
  props: {
    active: {
      type: Number,
      default: 0
    },
    isReview: {
      type: Boolean,
      default: false
    }
  },
  data () {
    return {
      param: {},
      ruleForm: {
        companyId: '',
        companyName: '',
        socialCreditCode: ''
      }
    }
  },
  mounted () {
    this.param = this.$route.query
    this.initData()
  },
  methods: {
    unitChange (value) {
      this.units.forEach(item => {
        if (value === item.id) {
          this.ruleForm.socialCreditCode = item.socialCreditCode
        }
      })
    },
    remoteMethod (text) {
      if (text !== '') {
        this.loading = true
        loginApi.queryByNameNoToken({
          name: text
        }).then(({ data }) => {
          this.loading = false
          this.units = data.data
        })
      } else {
        this.units = []
      }
    },
    initData () {
      if (this.param.talentApplyId) {
        if (this.isReview) {
          talentReviewApi.getCompanyInfo({
            talentApplyId: this.param.talentApplyId
          }).then(res => {
            this.ruleForm = res.data.data || {}
          })
        } else {
          talentApi.getCompanyInfo({
            talentApplyId: this.param.talentApplyId
          }).then(res => {
            this.ruleForm = res.data.data || {}
          })
        }
      }
    }
  }
}
</script>
<style lang="scss" scoped>
.unit {
  .ruleForm {
    .w-300 {
      width: 300px;
    }
    .w-150 {
      width: 135px;
    }
    .d-flex {
      display: flex;
    }
    .img {
      width: 100px;
      height: 100px;
      display: block;
    }
    .perch {
      width: 400px;
    }
    .textarea {
      width: 1160px;
    }
  }
}
</style>
