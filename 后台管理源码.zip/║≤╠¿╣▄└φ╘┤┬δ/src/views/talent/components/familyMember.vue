<template>
  <div class="familyMember">
    <TableInput
      :head-list="headList"
      :table-list="tableList"
      :index-state="false"
      :is-edit="param.handleType !== 'view'"
      :is-show-operate="false"
    />
  </div>
</template>
<script>
import TableInput from '@/components/table/TableInput.vue'
import * as talentApi from '@/api/talent'
import * as talentReviewApi from '@/api/talentReview'
export default {
  name: 'FamilyMember',
  components: {
    TableInput
  },
  props: {
    active: {
      type: Number,
      default: 0
    },
    isReview: {
      type: Boolean,
      default: false
    }
  },
  data () {
    return {
      param: {},
      tableList: []
    }
  },
  computed: {
    headList: function () {
      var headList = []
      if (this.param.handleType !== 'view') {
        headList = [
          {
            prop: 'name',
            label: '姓名'
          },
          {
            prop: 'relationship',
            label: '与本人关系',
            select: true,
            selects: []
          },
          {
            prop: 'birthday',
            label: '出生日期',
            date: true
          },
          { prop: 'politicsStatus', label: '政治面貌' },
          { prop: 'ocupertino', label: '工作单位及职务' }
        ]
      } else {
        headList = [
          {
            prop: 'name',
            label: '姓名'
          },
          {
            prop: 'relationshipLabel',
            label: '与本人关系'
          },
          {
            prop: 'birthday',
            label: '出生日期'
          },
          { prop: 'politicsStatus', label: '政治面貌' },
          { prop: 'ocupertino', label: '工作单位及职务' }
        ]
      }
      return headList
    }
  },
  mounted () {
    this.param = this.$route.query
    this.initData()
  },
  methods: {
    initData () {
      if (this.param.talentApplyId) {
        if (this.isReview) {
          talentReviewApi.getFamilyMember({
            talentApplyId: this.param.talentApplyId
          }).then(res => {
            this.tableList = res.data.data || []
          })
        } else {
          talentApi.getFamilyMember({
            talentApplyId: this.param.talentApplyId
          }).then(res => {
            this.tableList = res.data.data || []
          })
        }
      }
    }
  }
}
</script>
<style lang="scss" scoped>
.familyMember {
}
</style>
