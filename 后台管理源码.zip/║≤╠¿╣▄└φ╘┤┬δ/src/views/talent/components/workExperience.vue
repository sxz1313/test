<template>
  <div class="workExperience">
    <TableInput
      :head-list="headList"
      :table-list="tableList"
      :index-state="false"
      :is-edit="param.handleType !== 'view'"
      :is-show-operate="false"
    />
  </div>
</template>
<script>
import TableInput from '@/components/table/TableInput.vue'
import * as talentApi from '@/api/talent'
import * as talentReviewApi from '@/api/talentReview'
export default {
  name: 'WorkExperience',
  components: {
    TableInput
  },
  props: {
    active: {
      type: Number,
      default: 0
    },
    isReview: {
      type: Boolean,
      default: false
    }
  },
  data () {
    return {
      param: {},
      tableList: []
    }
  },
  computed: {
    headList: function () {
      var headList = []
      if (this.param.handleType !== 'view') {
        headList = [
          {
            prop: 'startDate',
            label: '起始日期',
            date: true,
            type: 'month',
            format: 'yyyy-MM'
          },
          {
            prop: 'endDate',
            label: '终止日期',
            date: true,
            type: 'month',
            format: 'yyyy-MM'
          },
          { prop: 'companyName', label: '单位名称' },
          { prop: 'position', label: '部门职务' },
          {
            prop: 'majorDuty',
            label: '主要职责'
          },
          { prop: 'supervisorName', label: '主管姓名' }
        ]
      } else {
        headList = [
          { prop: 'startDate', label: '起始日期' },
          { prop: 'endDate', label: '终止日期' },
          { prop: 'companyName', label: '单位名称' },
          { prop: 'position', label: '部门职务' },
          { prop: 'majorDuty', label: '主要职责' },
          { prop: 'supervisorName', label: '主管姓名' }
        ]
      }
      return headList
    }
  },
  mounted () {
    this.param = this.$route.query
    this.initData()
  },
  methods: {
    initData () {
      if (this.param.talentApplyId) {
        if (this.isReview) {
          talentReviewApi.getWorkExperience({
            talentApplyId: this.param.talentApplyId
          }).then(res => {
            this.tableList = res.data.data || []
          })
        } else {
          talentApi.getWorkExperience({
            talentApplyId: this.param.talentApplyId
          }).then(res => {
            this.tableList = res.data.data || []
          })
        }
      }
    }
  }
}
</script>
<style lang="scss" scoped>
.workExperience{}
</style>
