<template>
  <div class="trainingEducation">
    <TableInput
      :head-list="headList"
      :table-list="tableList"
      :index-state="false"
      :is-edit="param.handleType !== 'view'"
      :is-show-operate="false"
    />
  </div>
</template>
<script>
import TableInput from '@/components/table/TableInput.vue'
import * as talentApi from '@/api/talent'
import * as talentReviewApi from '@/api/talentReview'
export default {
  name: 'TrainingEducation',
  components: {
    TableInput
  },
  props: {
    active: {
      type: Number,
      default: 0
    },
    isReview: {
      type: Boolean,
      default: false
    }
  },
  data () {
    return {
      param: {},
      tableList: []
    }
  },
  computed: {
    headList: function () {
      var headList = []
      if (this.param.handleType !== 'view') {
        headList = [
          {
            prop: 'startDate',
            label: '开始日期',
            date: true
          },
          {
            prop: 'endDate',
            label: '终止日期',
            date: true
          },
          { prop: 'name', label: '培训机构(组织)名称' },
          {
            prop: 'content',
            label: '培训（学习）内容'
          },
          { prop: 'certificateName', label: '证书名称' },
          { prop: 'certificateNo', label: '证书编号' }
        ]
      } else {
        headList = [
          {
            prop: 'startDate',
            label: '开始日期'
          },
          {
            prop: 'endDate',
            label: '终止日期'
          },
          { prop: 'name', label: '培训机构(组织)名称' },
          {
            prop: 'content',
            label: '培训（学习）内容'
          },
          { prop: 'certificateName', label: '证书名称' },
          { prop: 'certificateNo', label: '证书编号' }
        ]
      }
      return headList
    }
  },
  mounted () {
    this.param = this.$route.query
    this.initData()
  },
  methods: {
    initData () {
      if (this.param.talentApplyId) {
        if (this.isReview) {
          talentReviewApi.getTrainingEducationInfo({
            talentApplyId: this.param.talentApplyId
          }).then(res => {
            this.tableList = res.data.data || []
          })
        } else {
          talentApi.getTrainingEducationInfo({
            talentApplyId: this.param.talentApplyId
          }).then(res => {
            this.tableList = res.data.data || []
          })
        }
      }
    }
  }
}
</script>
<style lang="scss" scoped>
.trainingEducation {
}
</style>
