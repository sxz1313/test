<template>
  <div class="trainGraduateStudent">
    <TableInput
      :head-list="headList"
      :table-list="tableList"
      :index-state="false"
      :is-edit="param.handleType !== 'view'"
      :is-show-operate="false"
    />
  </div>
</template>
<script>
import TableInput from '@/components/table/TableInput.vue'
import * as talentApi from '@/api/talent'
import * as talentReviewApi from '@/api/talentReview'
export default {
  name: 'TrainGraduateStudent',
  components: {
    TableInput
  },
  props: {
    active: {
      type: Number,
      default: 0
    },
    isReview: {
      type: Boolean,
      default: false
    }
  },
  data () {
    return {
      param: {},
      tableList: []
    }
  },
  computed: {
    headList: function () {
      var headList = []
      if (this.param.handleType !== 'view') {
        headList = [
          {
            prop: 'startDate',
            label: '开始日期',
            date: true
          },
          {
            prop: 'endDate',
            label: '终止日期',
            date: true
          },
          {
            prop: 'count',
            label: '培养研究生数量',
            isNum: true
          },
          { prop: 'researchDirection', label: '研究方向' }
        ]
      } else {
        headList = [
          {
            prop: 'startDate',
            label: '开始日期'
          },
          {
            prop: 'endDate',
            label: '终止日期'
          },
          {
            prop: 'count',
            label: '培养研究生数量'
          },
          { prop: 'researchDirection', label: '研究方向' }
        ]
      }
      return headList
    }
  },
  mounted () {
    this.param = this.$route.query
    this.initData()
  },
  methods: {
    initData () {
      if (this.param.talentApplyId) {
        if (this.isReview) {
          talentReviewApi.getTrainGraduateStudentInfo({
            talentApplyId: this.param.talentApplyId
          }).then(res => {
            this.tableList = res.data.data || []
          })
        } else {
          talentApi.getTrainGraduateStudentInfo({
            talentApplyId: this.param.talentApplyId
          }).then(res => {
            this.tableList = res.data.data || []
          })
        }
      }
    }
  }
}
</script>
<style lang="scss" scoped>
.trainGraduateStudent {
}
</style>
