<template>
  <div class="basicInfo">
    <el-form
      ref="ruleForm"
      class="ruleForm"
      :model="ruleForm"
      inline
      :rules="param.handleType !== 'view' ? rules : {}"
      label-width="130px"
    >
      <el-form-item label="姓名:" prop="name">
        <el-input
          v-if="param.handleType !== 'view'"
          v-model="ruleForm.name"
          placeholder="请输入姓名"
          maxlength="30"
          clearable
        />
        <div v-else class="value w-300">{{ ruleForm.name }}</div>
      </el-form-item>
      <el-form-item label="名校优生:" prop="name">
        <el-input
          v-if="param.handleType !== 'view'"
          v-model="ruleForm.name"
          placeholder="请输入姓名"
          maxlength="30"
          clearable
        />
        <div v-else class="value w-300">{{ ruleForm.eliteStudentLabel }}</div>
      </el-form-item>
      <el-form-item label="性别:" prop="sex">
        <el-select
          v-if="param.handleType !== 'view'"
          v-model="ruleForm.sex"
          placeholder="请选择性别"
          clearable
        >
          <el-option
            v-for="c in sexs"
            :key="c.id"
            :value="c.id"
            :label="c.name"
          />
        </el-select>
        <div v-else class="value w-300">{{ ruleForm.sexLabel }}</div>
      </el-form-item>
      <el-form-item label="照片:" prop="picture">
        <div>
          <UploadImage
            v-if="param.handleType !== 'view'"
            :img-url="ruleForm.picture"
            @handleImgSuccess="handleImgSuccess"
          />
          <div v-else class="w-300">
            <img v-if="ruleForm.picture" :src="ruleForm.picture" class="img">
          </div>
        </div>
      </el-form-item>
      <el-form-item label="电子简历:" prop="resumeFileName">
        <div>
          <UploadFile
            v-if="param.handleType !== 'view'"
            accept=""
            :file="ruleForm.resumeFileName"
            @handleFileSuccess="handleFileSuccess"
          />
          <div v-else class="w-300 cursor-p" @click="download">
            {{ ruleForm.resumeFileInfo && ruleForm.resumeFileInfo.fileOriginName }}
          </div>
        </div>
      </el-form-item>
      <el-form-item label="民族:" prop="nation">
        <el-select
          v-if="param.handleType !== 'view'"
          v-model="ruleForm.nation"
          placeholder="请选择民族"
          clearable
        >
          <el-option
            v-for="c in nations"
            :key="c.id"
            :value="c.id"
            :label="c.name"
          />
        </el-select>
        <div v-else class="value w-300">{{ ruleForm.nationLabel }}</div>
      </el-form-item>
      <el-form-item label="出生日期:" prop="birthday">
        <el-date-picker
          v-if="param.handleType !== 'view'"
          v-model="ruleForm.birthday"
          type="date"
          format="yyyy-MM-dd"
          value-format="yyyy-MM-dd"
          placeholder="请选择出生日期"
        />
        <div v-else class="value w-300">{{ ruleForm.birthday }}</div>
      </el-form-item>
      <el-form-item label="出生地:" prop="birthPlace">
        <el-input
          v-if="param.handleType !== 'view'"
          v-model="ruleForm.birthPlace"
          placeholder="请输入出生地(省+市+县/区)"
          maxlength="100"
          clearable
        />
        <div v-else class="value w-300">{{ ruleForm.birthPlace }}</div>
      </el-form-item>
      <el-form-item label="曾用名:" prop="usedName">
        <el-input
          v-if="param.handleType !== 'view'"
          v-model="ruleForm.usedName"
          placeholder="请输入曾用名"
          maxlength="30"
          clearable
        />
        <div v-else class="value w-300">{{ ruleForm.usedName }}</div>
      </el-form-item>
      <el-form-item label="外文姓名:" prop="foreignName">
        <el-input
          v-if="param.handleType !== 'view'"
          v-model="ruleForm.foreignName"
          placeholder="请输入外文姓名"
          maxlength="30"
          clearable
        />
        <div v-else class="value w-300">{{ ruleForm.foreignName }}</div>
      </el-form-item>
      <el-form-item label="国籍:" prop="nationality">
        <el-select
          v-if="param.handleType !== 'view'"
          v-model="ruleForm.nationality"
          placeholder="请选择国籍"
          clearable
        >
          <el-option
            v-for="c in nationalitys"
            :key="c.code"
            :value="c.code"
            :label="c.name"
          />
        </el-select>
        <div v-else class="value w-300">{{ ruleForm.nationalityLabel }}</div>
      </el-form-item>
      <el-form-item label="籍贯:" prop="nativePlace">
        <el-cascader
          v-if="param.handleType !== 'view'"
          ref="nativePlace"
          v-model="ruleForm.nativePlace"
          placeholder="请选择籍贯"
          :props="areaProps"
        />
        <div v-else class="value w-300">
          {{
            ruleForm.nativePlaceProvince
              ? (ruleForm.nativePlaceProvince &&
                ruleForm.nativePlaceProvince.province) +
                "/" +
                (ruleForm.nativePlaceCity && ruleForm.nativePlaceCity.city)
              : ""
          }}
        </div>
      </el-form-item>
      <el-form-item label="户籍所在地:" prop="domicilePlace">
        <el-cascader
          v-if="param.handleType !== 'view'"
          ref="domicilePlace"
          v-model="ruleForm.domicilePlace"
          placeholder="请选择户籍所在地"
          :props="areaProps"
        />
        <div v-else class="value w-300">
          {{
            ruleForm.domicilePlaceProvince
              ? (ruleForm.domicilePlaceProvince &&
                ruleForm.domicilePlaceProvince.province) +
                "/" +
                (ruleForm.domicilePlaceCity &&
                  ruleForm.domicilePlaceCity.city) +
                "/" +
                (ruleForm.domicilePlaceArea && ruleForm.domicilePlaceArea.area)
              : ""
          }}
        </div>
      </el-form-item>
      <el-form-item label="身份证号:" prop="idNumber">
        <el-input
          v-if="param.handleType !== 'view'"
          v-model="ruleForm.idNumber"
          placeholder="请输入身份证号"
          maxlength="30"
          clearable
        />
        <div v-else class="value w-300">{{ ruleForm.idNumber }}</div>
      </el-form-item>
      <el-form-item label="健康状况:" prop="healthCondition">
        <el-select
          v-if="param.handleType !== 'view'"
          v-model="ruleForm.healthCondition"
          placeholder="请选择健康状况"
          clearable
        >
          <el-option
            v-for="c in healths"
            :key="c.id"
            :value="c.id"
            :label="c.name"
          />
        </el-select>
        <div v-else class="value w-300">
          {{ ruleForm.healthConditionLabel }}
        </div>
      </el-form-item>
      <el-form-item label="婚姻状况:" prop="marriageStatus">
        <el-select
          v-if="param.handleType !== 'view'"
          v-model="ruleForm.marriageStatus"
          placeholder="请选择婚姻状况"
          clearable
        >
          <el-option
            v-for="c in maritals"
            :key="c.id"
            :value="c.id"
            :label="c.name"
          />
        </el-select>
        <div v-else class="value w-300">{{ ruleForm.marriageStatusLabel }}</div>
      </el-form-item>
      <el-form-item label="职业:" prop="job">
        <el-cascader
          v-if="param.handleType !== 'view'"
          ref="job"
          v-model="ruleForm.job"
          placeholder="请选择职业"
          :props="professionProps"
        />
        <div v-else class="value w-300">
          {{ ruleForm.jobLabel && ruleForm.jobLabel.replace(/,/g, "/") }}
        </div>
      </el-form-item>
      <el-form-item label="职位:" prop="position">
        <el-cascader
          v-if="param.handleType !== 'view'"
          ref="position"
          v-model="ruleForm.position"
          placeholder="请选择职位"
          :props="positionProps"
        />
        <div v-else class="value w-300">
          {{
            ruleForm.positionLabel && ruleForm.positionLabel.replace(/,/g, "/")
          }}
        </div>
      </el-form-item>
      <el-form-item label="职位级别:" prop="positionLevel">
        <el-select
          v-if="param.handleType !== 'view'"
          v-model="ruleForm.positionLevel"
          placeholder="请选择职位级别"
          clearable
        >
          <el-option
            v-for="c in positionLevels"
            :key="c.id"
            :value="c.id"
            :label="c.name"
          />
        </el-select>
        <div v-else class="value w-300">{{ ruleForm.positionLevelLabel }}</div>
      </el-form-item>
      <el-form-item label="执业资格:" prop="mipa">
        <el-select
          v-if="param.handleType !== 'view'"
          v-model="ruleForm.mipa"
          placeholder="请选择执业资格"
          multiple
          collapse-tags
          clearable
        >
          <el-option
            v-for="c in qualifications"
            :key="c.id"
            :value="c.id"
            :label="c.name"
          />
        </el-select>
        <div v-else class="value w-300">{{ ruleForm.mipaLabel }}</div>
      </el-form-item>
      <el-form-item label="专业技术职务:" prop="professionalTechnicalPost">
        <el-cascader
          v-if="param.handleType !== 'view'"
          ref="professionalTechnicalPost"
          v-model="ruleForm.professionalTechnicalPost"
          placeholder="请选择专业技术职务"
          :props="technicalPositionProps"
        />
        <div v-else class="value w-300">
          {{
            ruleForm.professionalTechnicalPostLabel &&
              ruleForm.professionalTechnicalPostLabel.replace(/,/g, "/")
          }}
        </div>
      </el-form-item>
      <el-form-item label="专业技术岗位:" prop="professionalPosition">
        <el-cascader
          v-if="param.handleType !== 'view'"
          ref="professionalPosition"
          v-model="ruleForm.professionalPosition"
          placeholder="请选择专业技术岗位"
          :props="technicalStationProps"
        />
        <div v-else class="value w-300">
          {{
            ruleForm.professionalPositionLabel &&
              ruleForm.professionalPositionLabel.replace(/,/g, "/")
          }}
        </div>
      </el-form-item>
      <el-form-item label="专业类别:" prop="professionalCategory">
        <el-select
          v-if="param.handleType !== 'view'"
          v-model="ruleForm.professionalCategory"
          placeholder="请选择专业类别"
          clearable
        >
          <el-option
            v-for="c in categorys"
            :key="c.id"
            :value="c.id"
            :label="c.name"
          />
        </el-select>
        <div v-else class="value w-300">
          {{ ruleForm.professionalCategoryLabel }}
        </div>
      </el-form-item>
      <el-form-item label="人才属性:" prop="talentProperty">
        <el-select
          v-if="param.handleType !== 'view'"
          v-model="ruleForm.talentProperty"
          placeholder="请选择专业类别"
          clearable
        >
          <el-option
            v-for="c in categorys"
            :key="c.id"
            :value="c.id"
            :label="c.name"
          />
        </el-select>
        <div v-else class="value w-300">
          {{ ruleForm.talentPropertyLabel }}
        </div>
      </el-form-item>
      <el-form-item label="个人专业特长:" prop="personalMajor">
        <el-input
          v-if="param.handleType !== 'view'"
          v-model="ruleForm.personalMajor"
          placeholder="请输入个人专业特长"
          maxlength="100"
          clearable
        />
        <div v-else class="value w-300">{{ ruleForm.personalMajor }}</div>
      </el-form-item>
      <el-form-item label="个人爱好:" prop="personalPreference">
        <el-input
          v-if="param.handleType !== 'view'"
          v-model="ruleForm.personalPreference"
          placeholder="请输入个人爱好"
          maxlength="100"
          clearable
        />
        <div v-else class="value w-300">{{ ruleForm.personalPreference }}</div>
      </el-form-item>
      <el-form-item label="其他有效身份证件:" prop="otherIdentification">
        <el-select
          v-if="param.handleType !== 'view'"
          v-model="ruleForm.otherIdentification"
          placeholder="请选择有效身份证件"
          clearable
        >
          <el-option
            v-for="c in certificateTypes"
            :key="c.id"
            :value="c.id"
            :label="c.name"
          />
        </el-select>
        <div v-else class="value w-300">
          {{ ruleForm.otherIdentificationLabel }}
        </div>
      </el-form-item>
      <el-form-item label="证件号码:" prop="identificationNumber">
        <el-input
          v-if="param.handleType !== 'view'"
          v-model="ruleForm.identificationNumber"
          placeholder="请输入证件号码"
          maxlength="30"
          clearable
        />
        <div v-else class="value w-300">
          {{ ruleForm.identificationNumber }}
        </div>
      </el-form-item>
      <el-form-item label="用工形式:" prop="employmentForm">
        <el-select
          v-if="param.handleType !== 'view'"
          v-model="ruleForm.employmentForm"
          placeholder="请选择用工形式"
          clearable
        >
          <el-option
            v-for="c in employmentForms"
            :key="c.id"
            :value="c.id"
            :label="c.name"
          />
        </el-select>
        <div v-else class="value w-300">{{ ruleForm.employmentFormLabel }}</div>
      </el-form-item>
      <el-form-item label="邮政编码:" prop="postalCode">
        <el-input
          v-if="param.handleType !== 'view'"
          v-model="ruleForm.postalCode"
          placeholder="请输入邮政编码"
          maxlength="30"
          clearable
        />
        <div v-else class="value w-300">{{ ruleForm.postalCode }}</div>
      </el-form-item>
      <el-form-item label="移动电话:" prop="mobile">
        <el-input
          v-if="param.handleType !== 'view'"
          v-model="ruleForm.mobile"
          placeholder="请输入移动电话"
          maxlength="30"
          clearable
        />
        <div v-else class="value w-300">{{ ruleForm.mobile }}</div>
      </el-form-item>
      <el-form-item label="固定电话:" prop="telephone">
        <el-input
          v-if="param.handleType !== 'view'"
          v-model="ruleForm.telephone"
          placeholder="请输入固定电话"
          maxlength="30"
          clearable
        />
        <div v-else class="value w-300">{{ ruleForm.telephone }}</div>
      </el-form-item>
      <el-form-item label="电子信箱:" prop="email">
        <el-input
          v-if="param.handleType !== 'view'"
          v-model="ruleForm.email"
          placeholder="请输入电子信箱"
          maxlength="30"
          clearable
        />
        <div v-else class="value w-300">{{ ruleForm.email }}</div>
      </el-form-item>
      <el-form-item label="联系地址:" prop="areas">
        <div v-if="param.handleType !== 'view'">
          <el-cascader
            ref="areas"
            v-model="ruleForm.areas"
            placeholder="请选择省市区"
            :props="areaProps"
          />
          <div class="mt-10">
            <el-input
              v-model="ruleForm.contactAddress"
              type="textarea"
              class="textarea"
              rows="2"
              placeholder="请输入详细地址"
              clearable
            />
          </div>
        </div>
        <div v-else class="value textarea">
          {{ ruleForm.contactProvince && ruleForm.contactProvince.province
          }}{{ ruleForm.contactCity && ruleForm.contactCity.city
          }}{{ ruleForm.contactArea && ruleForm.contactArea.area
          }}{{ ruleForm.contactAddress }}
        </div>
      </el-form-item>
    </el-form>
  </div>
</template>
<script>
import UploadImage from '@/components/upload/ImageUploadOne.vue'
import * as downloadFile from '@/utils/UploadFile'
import * as talentApi from '@/api/talent'
import * as talentReviewApi from '@/api/talentReview'
export default {
  name: 'BasicInfo',
  components: {
    UploadImage
  },
  props: {
    active: {
      type: Number,
      default: 0
    },
    isReview: {
      type: Boolean,
      default: false
    }
  },
  data () {
    return {
      param: {},
      ruleForm: {
        name: '',
        sex: '',
        picture: '',
        nation: '',
        birthday: '',
        birthPlace: '',
        usedName: '',
        foreignName: '',
        nationality: '',
        nativePlace: [],
        domicilePlace: [],
        idNumber: '',
        healthCondition: '',
        marriageStatus: '',
        job: [],
        position: [],
        positionLevel: '',
        mipa: [],
        professionalTechnicalPost: [],
        professionalPosition: [],
        professionalCategory: '',
        talentProperty: '',
        personalMajor: '',
        personalPreference: '',
        otherIdentification: '',
        identificationNumber: '',
        employmentForm: '',
        postalCode: '',
        mobile: '',
        telephone: '',
        email: '',
        areas: [],
        contactAddress: ''
      }
    }
  },
  mounted () {
    this.param = this.$route.query
    this.initData()
  },
  methods: {
    download () {
      downloadFile.download(this.ruleForm.resumeFileInfo.filePath, this.ruleForm.resumeFileInfo.fileOriginName)
    },
    handleImgSuccess (data) {
      this.ruleForm.picture = data.fileUrl
    },
    initData () {
      if (this.param.talentApplyId) {
        if (this.isReview) {
          talentReviewApi
            .getBasicInfo({
              talentApplyId: this.param.talentApplyId
            })
            .then((res) => {
              this.ruleForm = res.data.data || {}
            })
        } else {
          talentApi
            .getBasicInfo({
              talentApplyId: this.param.talentApplyId
            })
            .then((res) => {
              this.ruleForm = res.data.data || {}
            })
        }
      }
    }
  }
}
</script>
<style lang="scss" scoped>
.basicInfo {
  .ruleForm {
    .w-300 {
      width: 300px;
    }
    .w-150 {
      width: 135px;
    }
    .d-flex {
      display: flex;
    }
    .img {
      width: 100px;
      height: 100px;
      display: block;
    }
    .perch {
      width: 400px;
    }
    .textarea {
      min-width: 400px;
      max-width: 1160px;
    }
  }
}
</style>
