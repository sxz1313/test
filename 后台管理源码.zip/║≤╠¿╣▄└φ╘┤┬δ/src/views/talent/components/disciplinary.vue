<template>
  <div class="disciplinary">
    <TableInput
      :head-list="headList"
      :table-list="tableList"
      :index-state="false"
      :is-edit="param.handleType !== 'view'"
      :is-show-operate="false"
    />
  </div>
</template>
<script>
import TableInput from '@/components/table/TableInput.vue'
import * as talentApi from '@/api/talent'
import * as talentReviewApi from '@/api/talentReview'
export default {
  name: 'Disciplinary',
  components: {
    TableInput
  },
  props: {
    active: {
      type: Number,
      default: 0
    },
    isReview: {
      type: Boolean,
      default: false
    }
  },
  data () {
    return {
      param: {},
      tableList: []
    }
  },
  computed: {
    headList: function () {
      var headList = []
      if (this.param.handleType !== 'view') {
        headList = [
          {
            prop: 'approvalDate',
            label: '惩戒(处分)批准日期',
            date: true
          },
          { prop: 'agencyName', label: '惩戒(处分)批准机关名称' },
          { prop: 'name', label: '惩戒(处分)名称' },
          { prop: 'reason', label: '惩戒(处分)原因' },
          {
            prop: 'cancelDate',
            label: '惩戒(处分)撤消日期',
            date: true
          }
        ]
      } else {
        headList = [
          {
            prop: 'approvalDate',
            label: '惩戒(处分)批准日期'
          },
          { prop: 'agencyName', label: '惩戒(处分)批准机关名称' },
          { prop: 'name', label: '惩戒(处分)名称' },
          { prop: 'reason', label: '惩戒(处分)原因' },
          {
            prop: 'cancelDate',
            label: '惩戒(处分)撤消日期'
          }
        ]
      }
      return headList
    }
  },
  mounted () {
    this.param = this.$route.query
    this.initData()
  },
  methods: {

    initData () {
      if (this.param.talentApplyId) {
        if (this.isReview) {
          talentReviewApi.getDisciplinaryInfo({
            talentApplyId: this.param.talentApplyId
          }).then(res => {
            this.tableList = res.data.data || []
          })
        } else {
          talentApi.getDisciplinaryInfo({
            talentApplyId: this.param.talentApplyId
          }).then(res => {
            this.tableList = res.data.data || []
          })
        }
      }
    }
  }
}
</script>
<style lang="scss" scoped>
.disciplinary{}
</style>
