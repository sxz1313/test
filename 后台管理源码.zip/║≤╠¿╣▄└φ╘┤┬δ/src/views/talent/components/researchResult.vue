<template>
  <div class="researchResult">
    <TableInput
      :head-list="headList"
      :table-list="tableList"
      :index-state="false"
      :is-edit="param.handleType !== 'view'"
      :is-show-operate="false"
    />
  </div>
</template>
<script>
import TableInput from '@/components/table/TableInput.vue'
import * as talentApi from '@/api/talent'
import * as talentReviewApi from '@/api/talentReview'
export default {
  name: 'ResearchResult',
  components: {
    TableInput
  },
  props: {
    active: {
      type: Number,
      default: 0
    },
    isReview: {
      type: Boolean,
      default: false
    }
  },
  data () {
    return {
      param: {},
      tableList: []
    }
  },
  computed: {
    headList: function () {
      var headList = []
      if (this.param.handleType !== 'view') {
        headList = [
          { prop: 'acquireDate', label: '取得成果日期', date: true },
          {
            prop: 'name',
            label: '成果名称'
          },
          { prop: 'achievementLevel', label: '成果等级' },
          {
            prop: 'playRole',
            label: '担任的角色'
          },
          {
            prop: 'evaluateUnit',
            label: '评定单位名称'
          }
        ]
      } else {
        headList = [
          { prop: 'acquireDate', label: '取得成果日期' },
          {
            prop: 'name',
            label: '成果名称'
          },
          { prop: 'achievementLevel', label: '成果等级' },
          {
            prop: 'playRole',
            label: '担任的角色'
          },
          {
            prop: 'evaluateUnit',
            label: '评定单位名称'
          }
        ]
      }
      return headList
    }
  },
  mounted () {
    this.param = this.$route.query
    this.initData()
  },
  methods: {
    initData () {
      if (this.param.talentApplyId) {
        if (this.isReview) {
          talentReviewApi.getResearchResultInfo({
            talentApplyId: this.param.talentApplyId
          }).then(res => {
            this.tableList = res.data.data || []
          })
        } else {
          talentApi.getResearchResultInfo({
            talentApplyId: this.param.talentApplyId
          }).then(res => {
            this.tableList = res.data.data || []
          })
        }
      }
    }
  }
}
</script>
<style lang="scss" scoped>
.researchResult {
}
</style>
