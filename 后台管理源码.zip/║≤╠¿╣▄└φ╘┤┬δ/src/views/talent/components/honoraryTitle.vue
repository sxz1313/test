<template>
  <div class="honoraryTitle">
    <TableInput
      :head-list="headList"
      :table-list="tableList"
      :index-state="false"
      :is-edit="param.handleType !== 'view'"
      :is-show-operate="false"
    />
  </div>
</template>
<script>
import TableInput from '@/components/table/TableInput.vue'
import * as talentApi from '@/api/talent'
import * as talentReviewApi from '@/api/talentReview'
export default {
  name: 'HonoraryTitle',
  components: {
    TableInput
  },
  props: {
    active: {
      type: Number,
      default: 0
    },
    isReview: {
      type: Boolean,
      default: false
    }
  },
  data () {
    return {
      param: {},
      tableList: []
    }
  },
  computed: {
    headList: function () {
      var headList = []
      if (this.param.handleType !== 'view') {
        headList = [
          {
            prop: 'grantDate',
            label: '授予日期',
            date: true
          },
          { prop: 'awardUnit', label: '荣誉称号(奖励)授予单位' },
          {
            prop: 'name',
            label: '荣誉称号(奖励)名称'
            // select: true,
            // selects: []
          },
          { prop: 'certificateNo', label: '证书编号' }
        ]
      } else {
        headList = [
          {
            prop: 'grantDate',
            label: '授予日期'
          },
          { prop: 'awardUnit', label: '荣誉称号(奖励)授予单位' },
          { prop: 'name', label: '荣誉称号(奖励)名称' },
          { prop: 'certificateNo', label: '证书编号' }
        ]
      }
      return headList
    }
  },
  mounted () {
    this.param = this.$route.query
    this.initData()
  },
  methods: {
    initData () {
      if (this.param.talentApplyId) {
        if (this.isReview) {
          talentReviewApi.getHonoraryTitleInfo({
            talentApplyId: this.param.talentApplyId
          }).then(res => {
            this.tableList = res.data.data || []
          })
        } else {
          talentApi.getHonoraryTitleInfo({
            talentApplyId: this.param.talentApplyId
          }).then(res => {
            this.tableList = res.data.data || []
          })
        }
      }
    }
  }
}
</script>
<style lang="scss" scoped>
.honoraryTitle {
}
</style>
