<template>
  <div class="languageAbility">
    <TableInput
      :head-list="headList"
      :table-list="tableList"
      :index-state="false"
      :is-edit="param.handleType !== 'view'"
      :is-show-operate="false"
    />
  </div>
</template>
<script>
import TableInput from '@/components/table/TableInput.vue'
import * as talentApi from '@/api/talent'
import * as talentReviewApi from '@/api/talentReview'
export default {
  name: 'LanguageAbility',
  components: {
    TableInput
  },
  props: {
    active: {
      type: Number,
      default: 0
    },
    isReview: {
      type: Boolean,
      default: false
    }
  },
  data () {
    return {
      param: {},
      tableList: []
    }
  },
  computed: {
    headList: function () {
      var headList = []
      if (this.param.handleType !== 'view') {
        headList = [
          {
            prop: 'language',
            label: '语种'
          },
          { prop: 'languageLevel', label: '掌握语种水平的级别' },
          {
            prop: 'speakProficiency',
            label: '口语熟练程度',
            select: true,
            selects: []
          }
        ]
      } else {
        headList = [
          {
            prop: 'language',
            label: '语种'
          },
          { prop: 'languageLevel', label: '掌握语种水平的级别' },
          {
            prop: 'speakProficiencyLabel',
            label: '口语熟练程度'
          }
        ]
      }
      return headList
    }
  },
  mounted () {
    this.param = this.$route.query
    this.initData()
  },
  methods: {
    initData () {
      if (this.param.talentApplyId) {
        if (this.isReview) {
          talentReviewApi.getLanguageAbility({
            talentApplyId: this.param.talentApplyId
          }).then(res => {
            this.tableList = res.data.data || []
          })
        } else {
          talentApi.getLanguageAbility({
            talentApplyId: this.param.talentApplyId
          }).then(res => {
            this.tableList = res.data.data || []
          })
        }
      }
    }
  }
}
</script>
<style lang="scss" scoped>
.languageAbility {
}
</style>
