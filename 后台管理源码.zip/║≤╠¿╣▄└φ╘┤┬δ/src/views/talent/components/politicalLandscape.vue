<template>
  <div class="politicalLandscape">
    <TableInput
      :head-list="headList"
      :table-list="tableList"
      :index-state="false"
      :is-edit="param.handleType !== 'view'"
      :is-show-operate="false"
    />
  </div>
</template>
<script>
import TableInput from '@/components/table/TableInput.vue'
import * as talentApi from '@/api/talent'
import * as talentReviewApi from '@/api/talentReview'
export default {
  name: 'PoliticalLandscape',
  components: {
    TableInput
  },
  props: {
    active: {
      type: Number,
      default: 0
    },
    isReview: {
      type: Boolean,
      default: false
    }
  },
  data () {
    return {
      param: {},
      tableList: []
    }
  },
  computed: {
    headList: function () {
      var headList = []
      if (this.param.handleType !== 'view') {
        headList = [
          {
            prop: 'name',
            label: '政治面貌(党派)'
          },
          {
            prop: 'joinDate',
            label: '参加组织日期',
            date: true
          },
          { prop: 'introducer', label: '介绍人' },
          {
            prop: 'positiveDate',
            label: '转正日期',
            date: true
          },
          {
            prop: 'exitDate',
            label: '退出(除名)时间',
            date: true
          },
          {
            prop: 'exitReason',
            label: '退出(除名)原因'
          }
        ]
      } else {
        headList = [
          { prop: 'name', label: '政治面貌(党派)' },
          { prop: 'joinDate', label: '参加组织日期' },
          { prop: 'introducer', label: '介绍人' },
          {
            prop: 'positiveDate',
            label: '转正日期'
          },
          {
            prop: 'exitDate',
            label: '退出(除名)时间'
          },
          {
            prop: 'exitReason',
            label: '退出(除名)原因'
          }
        ]
      }
      return headList
    }
  },
  mounted () {
    this.param = this.$route.query
    this.initData()
  },
  methods: {
    initData () {
      if (this.param.talentApplyId) {
        if (this.isReview) {
          talentReviewApi.getPoliticalLandscapeInfo({
            talentApplyId: this.param.talentApplyId
          }).then(res => {
            this.tableList = res.data.data || []
          })
        } else {
          talentApi.getPoliticalLandscapeInfo({
            talentApplyId: this.param.talentApplyId
          }).then(res => {
            this.tableList = res.data.data || []
          })
        }
      }
    }
  }
}
</script>
<style lang="scss" scoped>
.politicalLandscape{}
</style>
