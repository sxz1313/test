<template>
  <div class="expertTitle">
    <TableInput
      :head-list="headList"
      :table-list="tableList"
      :index-state="false"
      :is-edit="param.handleType !== 'view'"
      :is-show-operate="false"
    />
  </div>
</template>
<script>
import TableInput from '@/components/table/TableInput.vue'
import * as talentApi from '@/api/talent'
import * as talentReviewApi from '@/api/talentReview'
export default {
  name: 'ExpertTitle',
  components: {
    TableInput
  },
  props: {
    active: {
      type: Number,
      default: 0
    },
    isReview: {
      type: Boolean,
      default: false
    }
  },
  data () {
    return {
      param: {},
      tableList: []
    }
  },
  computed: {
    headList: function () {
      var headList = []
      if (this.param.handleType !== 'view') {
        headList = [
          {
            prop: 'grantDate',
            label: '授予年份',
            date: true,
            type: 'year',
            format: 'yyyy'
          },
          { prop: 'name', label: '专家称号名称(类别)' },
          { prop: 'awardUnit', label: '授予单位' },
          { prop: 'certificateNo', label: '证书编号' }
        ]
      } else {
        headList = [
          {
            prop: 'grantDate',
            label: '授予年份'
          },
          { prop: 'name', label: '专家称号名称(类别)' },
          { prop: 'awardUnit', label: '授予单位' },
          { prop: 'certificateNo', label: '证书编号' }
        ]
      }
      return headList
    }
  },
  mounted () {
    this.param = this.$route.query
    this.initData()
  },
  methods: {
    initData () {
      if (this.param.talentApplyId) {
        if (this.isReview) {
          talentReviewApi.getExpertTitleInfo({
            talentApplyId: this.param.talentApplyId
          }).then(res => {
            this.tableList = res.data.data || []
          })
        } else {
          talentApi.getExpertTitleInfo({
            talentApplyId: this.param.talentApplyId
          }).then(res => {
            this.tableList = res.data.data || []
          })
        }
      }
    }
  }
}
</script>
<style lang="scss" scoped>
.expertTitle{}
</style>
