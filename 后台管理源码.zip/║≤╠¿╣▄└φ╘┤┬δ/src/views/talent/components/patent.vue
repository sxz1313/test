<template>
  <div class="patent">
    <TableInput
      :head-list="headList"
      :table-list="tableList"
      :index-state="false"
      :is-edit="param.handleType !== 'view'"
      :is-show-operate="false"
    />
  </div>
</template>
<script>
import TableInput from '@/components/table/TableInput.vue'
import * as talentApi from '@/api/talent'
import * as talentReviewApi from '@/api/talentReview'
export default {
  name: 'Patent',
  components: {
    TableInput
  },
  props: {
    active: {
      type: Number,
      default: 0
    },
    isReview: {
      type: Boolean,
      default: false
    }
  },
  data () {
    return {
      param: {},
      tableList: []
    }
  },
  computed: {
    headList: function () {
      var headList = []
      if (this.param.handleType !== 'view') {
        headList = [
          {
            prop: 'acquireDate',
            label: '获得专利日期',
            date: true
          },
          {
            prop: 'name',
            label: '专利名称'
          },
          { prop: 'patentNumber', label: '专利号' },
          { prop: 'approvalUnit', label: '专利批准单位' }
        ]
      } else {
        headList = [
          {
            prop: 'acquireDate',
            label: '获得专利日期'
          },
          {
            prop: 'name',
            label: '专利名称'
          },
          { prop: 'patentNumber', label: '专利号' },
          { prop: 'approvalUnit', label: '专利批准单位' }
        ]
      }
      return headList
    }
  },
  mounted () {
    this.param = this.$route.query
    this.initData()
  },
  methods: {
    initData () {
      if (this.param.talentApplyId) {
        if (this.isReview) {
          talentReviewApi.getPatentInfo({
            talentApplyId: this.param.talentApplyId
          }).then(res => {
            this.tableList = res.data.data || []
          })
        } else {
          talentApi.getPatentInfo({
            talentApplyId: this.param.talentApplyId
          }).then(res => {
            this.tableList = res.data.data || []
          })
        }
      }
    }
  }
}
</script>
<style lang="scss" scoped>
.patent {
}
</style>
