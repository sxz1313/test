<template>
  <div class="education">
    <TableInput
      :head-list="headList"
      :table-list="tableList"
      :index-state="false"
      :is-edit="param.handleType !== 'view'"
      :is-show-operate="false"
    />
  </div>
</template>
<script>
import TableInput from '@/components/table/TableInput.vue'
import * as talentApi from '@/api/talent'
import * as talentReviewApi from '@/api/talentReview'
export default {
  name: 'Education',
  components: {
    TableInput
  },
  props: {
    active: {
      type: Number,
      default: 0
    },
    isReview: {
      type: Boolean,
      default: false
    }
  },
  data () {
    return {
      param: {},
      tableList: []
    }
  },
  computed: {
    headList: function () {
      var headList = []
      if (this.param.handleType !== 'view') {
        headList = [
          {
            prop: 'startDate',
            label: '开始日期',
            date: true,
            type: 'month',
            format: 'yyyy-MM'
          },
          {
            prop: 'endDate',
            label: '终止日期',
            date: true,
            type: 'month',
            format: 'yyyy-MM'
          },
          { prop: 'schoolName', label: '学校名称' },
          { prop: 'major', label: '所学专业' },
          {
            prop: 'educationLevel',
            label: '学历层次',
            select: true,
            selects: []
          },
          { prop: 'educationCertificateNo', label: '学历证书编号' },
          {
            prop: 'degree',
            label: '学位',
            select: true,
            selects: []
          },
          { prop: 'degreeCertificateNo', label: '学位证书编号' }
        ]
      } else {
        headList = [
          { prop: 'startDate', label: '开始日期' },
          { prop: 'endDate', label: '终止日期' },
          { prop: 'schoolName', label: '学校名称' },
          { prop: 'major', label: '所学专业' },
          { prop: 'educationLevelLabel', label: '学历层次' },
          { prop: 'educationCertificateNo', label: '学历证书编号' },
          { prop: 'degreeLabel', label: '学位' },
          { prop: 'degreeCertificateNo', label: '学位证书编号' }
        ]
      }
      return headList
    }
  },
  mounted () {
    this.param = this.$route.query
    this.initData()
  },
  methods: {
    initData () {
      if (this.param.talentApplyId) {
        if (this.isReview) {
          talentReviewApi.getEducationInfo({
            talentApplyId: this.param.talentApplyId
          }).then(res => {
            this.tableList = res.data.data || []
          })
        } else {
          talentApi.getEducationInfo({
            talentApplyId: this.param.talentApplyId
          }).then(res => {
            this.tableList = res.data.data || []
          })
        }
      }
    }
  }
}
</script>
<style lang="scss" scoped>
.education {
}
</style>
