<template>
  <div class="annualAssessment">
    <TableInput
      :head-list="headList"
      :table-list="tableList"
      :index-state="false"
      :is-edit="param.handleType !== 'view'"
      :is-show-operate="false"
    />
  </div>
</template>
<script>
import TableInput from '@/components/table/TableInput.vue'
import * as talentApi from '@/api/talent'
import * as talentReviewApi from '@/api/talentReview'
export default {
  name: 'AnnualAssessment',
  components: {
    TableInput
  },
  props: {
    active: {
      type: Number,
      default: 0
    },
    isReview: {
      type: Boolean,
      default: false
    }
  },
  data () {
    return {
      param: {},
      tableList: []
    }
  },
  computed: {
    headList: function () {
      var headList = []
      if (this.param.handleType !== 'view') {
        headList = [
          {
            prop: 'year',
            label: '年 度',
            date: true,
            type: 'year',
            format: 'yyyy'
          },
          { prop: 'grade', label: '等 次' }
        ]
      } else {
        headList = [
          {
            prop: 'year',
            label: '年 度'
          },
          { prop: 'grade', label: '等 次' }
        ]
      }
      return headList
    }
  },
  mounted () {
    this.param = this.$route.query
    this.initData()
  },
  methods: {
    initData () {
      if (this.param.talentApplyId) {
        if (this.isReview) {
          talentReviewApi.getAnnualAssessmentInfo({
            talentApplyId: this.param.talentApplyId
          }).then(res => {
            this.tableList = res.data.data || []
          })
        } else {
          talentApi.getAnnualAssessmentInfo({
            talentApplyId: this.param.talentApplyId
          }).then(res => {
            this.tableList = res.data.data || []
          })
        }
      }
    }
  }
}
</script>
<style lang="scss" scoped>
.annualAssessment{}
</style>
