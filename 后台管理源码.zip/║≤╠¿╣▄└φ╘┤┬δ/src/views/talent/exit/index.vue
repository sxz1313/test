<template>
  <div class="commonContainer">
    <div class="header">
      <el-form :inline="true" :model="formInline" class="list-filter-wrap">
        <el-form-item label="姓名：">
          <el-input
            v-model.trim="filter.name"
            placeholder="请输入姓名"
            maxlength="30"
            clearable
          />
        </el-form-item>
        <el-form-item label="手机号：">
          <el-input
            v-model.trim="filter.mobile"
            placeholder="请输入手机号"
            maxlength="11"
            clearable
          />
        </el-form-item>
        <el-form-item label="学历：">
          <el-select v-model="filter.educationLevel" clearable placeholder="请选择">
            <el-option
              v-for="item in educationLevels"
              :key="item.id"
              :label="item.name"
              :value="item.id"
            />
          </el-select>
        </el-form-item>
        <el-form-item label="性别：">
          <el-select v-model="filter.sex" clearable placeholder="请选择">
            <el-option
              v-for="item in sexs"
              :key="item.id"
              :label="item.name"
              :value="item.id"
            />
          </el-select>
        </el-form-item>
        <el-form-item label="单位：">
          <el-select
            ref="select"
            v-model="filter.companyId"
            filterable
            remote
            clearable
            placeholder="请输入"
            :remote-method="remoteMethod"
            :loading="loading"
            @change="selectChange"
            @focus="changeCom"
          >
            <el-option
              v-for="(item, index) in units"
              :key="index"
              :label="item.name"
              :value="item.id"
            />
          </el-select>
        </el-form-item>
        <el-form-item>
          <el-button type="primary" @click="search">查询</el-button>
          <el-button @click="reset">重置</el-button>
        </el-form-item>
      </el-form>
    </div>
    <div class="content list-content-wrap">
      <div class="mb-1">
        <el-button v-perm-code="'1527089428533673990'" type="primary" @click="download">导出</el-button>
      </div>
      <TableCommon
        :head-list="headList"
        :table-list="tableList"
        :filter="filter"
        auth-id="1527089428533673987"
      >
        <div slot="button" slot-scope="props">
          <el-button v-perm-code="'1527089428533673990'" type="text" @click="check(props.scope)">查看</el-button>
        </div>
      </TableCommon>
      <div class="pageStyle">
        <pagination :page-param="filter" @pageChange="pageChange" />
        <div v-show="filter.total > 0" class="total">人才总数：{{ filter.total }}人</div>
      </div>
    </div>
  </div>
</template>
<script>
import TableCommon from '@/components/table/TableCommon'
import pagination from '@/components/pagination/index'
import * as api from '@/api/company'
import * as common from '@/api/common'
import * as downloadFile from '@/utils/UploadFile'
export default {
  components: {
    TableCommon,
    pagination
  },
  data () {
    return {
      filter: {
        mobile: '',
        name: '',
        educationLevel: '',
        companyId: '',
        sex: '',
        pageSize: 10,
        pageNo: 1,
        total: 0
      },
      sexs: [],
      units: [],
      educationLevels: [],
      headList: [
        { prop: 'name', label: '姓名' },
        { prop: 'mobile', label: '手机号' },
        { prop: 'companyName', label: '单位名称' },
        { prop: 'statusLabel', label: '状态' },
        { prop: 'updateTime', label: '提交时间' }
      ],
      tableList: []
    }
  },
  created () {
    this.initList()
    common.queryByType({ type: 'sex' }).then(({ data }) => {
      this.sexs = data.data
    })
    common.queryByType({ type: 'educational_level' }).then(({ data }) => {
      this.educationLevels = data.data
    })
  },
  methods: {
    changeCom () {
      if (!this.filter.companyId) {
        this.units = []
      }
    },
    selectChange () {
      if (!this.filter.companyId) {
        this.filter.companyId = ''
        this.units = []
      }
    },
    remoteMethod (text) {
      if (text !== '') {
        this.loading = true
        api.queryByNameNoToken({
          name: text
        }).then(({ data }) => {
          this.loading = false
          this.units = data.data
        })
      } else {
        this.units = []
      }
    },
    download () {
      const param = {
        mobile: '',
        name: '',
        educationLevel: '',
        companyId: '',
        sex: ''
      }
      api.exportExitList(param).then((res) => {
        downloadFile.downloadBlob(res.data, '退会人才信息.xlsx')
      })
    },
    check (row) {
      this.$router.push({
        name: 'talentExitDetail',
        query: {
          handleType: 'view',
          talentApplyId: row.id
        }
      })
    },
    pageChange (pageNo) {
      this.filter.pageNo = Number(pageNo)
      this.initList()
    },
    initList () {
      api.exitClubList(this.filter).then(({ data }) => {
        this.tableList = (data.data.rows || []).map((item) => {
          if (item.company) {
            item.companyName = item.company.name
          } else {
            item.companyName = ''
          }
          return item
        })
        this.filter.total = Number(data.data.totalRows)
      })
    },
    search () {
      this.pageChange(1)
    },
    // 重置
    reset () {
      this.filter.mobile = ''
      this.filter.name = ''
      this.filter.sex = ''
      this.filter.educationLevel = ''
      this.filter.companyId = ''
      this.pageChange(1)
    }
  }
}
</script>
<style lang="scss" scoped>
  .pageStyle /deep/ {
    position: relative;
    .total {
      position: absolute;
      padding: 10px 0;
      line-height: 28px;
      right: 10px;
      top: 0;
    }
  }
</style>
