<template>
  <div class="operationModal">
    <el-form
      ref="ruleForm"
      :model="ruleForm"
      :rules="handleType !== 'view' ? rules : {}"
      label-width="120px"
      class="demo-ruleForm"
    >
      <el-form-item label="账号:" prop="account">
        <el-input
          v-model="ruleForm.account"
          placeholder="请输入"
          class="w-300"
        />
      </el-form-item>
      <el-form-item label="员工姓名:" prop="name">
        <el-input v-model="ruleForm.name" placeholder="请输入" class="w-300" />
      </el-form-item>
      <el-form-item label="手机号码:" prop="phone">
        <el-input
          v-model="ruleForm.phone"
          type="tel"
          maxlength="11"
          placeholder="请输入"
          class="w-300"
        />
      </el-form-item>
      <el-form-item label="角色:" prop="roleId">
        <el-select
          v-model="ruleForm.roleId"
          class="w-300"
          placeholder="请选择"
          filterable
          clearable
        >
          <el-option
            v-for="c in roles"
            :key="c.id"
            :value="c.id"
            :label="c.name"
          />
        </el-select>
      </el-form-item>
      <el-form-item>
        <div class="flo-r">
          <el-button
            size="small"
            @click="resetForm('ruleForm')"
          >取消</el-button>
          <el-button
            size="small"
            type="primary"
            @click="submitForm('ruleForm')"
          >确认</el-button>
        </div>
      </el-form-item>
    </el-form>
  </div>
</template>
<script>
import * as elmFormValidators from '@/utils/elmFormValidators'
import * as systemApi from '@/api/system'
export default {
  name: 'OperationModal',
  props: {
    params: {
      type: Object,
      default: () => {}
    },
    modalType: {
      type: String,
      default: ''
    }
  },
  data () {
    return {
      ruleForm: {
        account: '',
        name: '',
        phone: '',
        roleId: ''
      },
      roles: []
    }
  },
  computed: {
    rules () {
      var rules = {}
      rules = {
        account: [{ required: true, message: '请输入账号', trigger: 'blur' },
          { validator: elmFormValidators.code, trigger: 'blur' }
        ],
        name: [
          { required: true, message: '请输入员工姓名', trigger: 'blur' },
          { validator: elmFormValidators.name, trigger: 'blur' }
        ],
        phone: [
          { required: true, message: '请输入手机号码', trigger: 'blur' },
          { validator: elmFormValidators.phone, trigger: 'blur' }
        ],
        roleId: [{ required: true, message: '请选择角色', trigger: 'change' }]
      }
      return rules
    }
  },
  mounted () {
    this.initData()
  },
  methods: {
    submitForm (formName) {
      this.$refs[formName].validate((valid) => {
        if (valid) {
          var ruleForm = {
            id: this.ruleForm.id,
            account: this.ruleForm.account,
            name: this.ruleForm.name,
            phone: this.ruleForm.phone,
            roleId: this.ruleForm.roleId
          }
          this.$emit('operationSubmit', ruleForm)
        } else {
          return false
        }
      })
    },
    resetForm (formName) {
      this.$refs[formName].resetFields()
      this.$emit('operationCancel')
    },
    initData () {
      systemApi.getRoleDownList().then(res => {
        this.ruleForm.roleId = res.data.data && res.data.data.length && res.data.data[0].id
        this.roles = res.data.data
      })
      if (this.modalType === 'edit') {
        systemApi.getUserDetail({
          id: this.params.id
        }).then(res => {
          this.ruleForm = res.data.data
        })
      }
    }
  }
}
</script>
