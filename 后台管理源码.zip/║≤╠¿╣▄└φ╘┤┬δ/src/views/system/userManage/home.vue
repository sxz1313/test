<template>
  <div class="commonContainer">
    <div class="top">
      <div
        class="btn"
        :class="[type === '1' ? 'choose' : '']"
        @click="type = '1'"
      >
        用户管理
      </div>
      <div
        v-perm-code="'1506105220587827202'"
        class="btn"
        :class="[type === '2' ? 'choose' : '']"
        @click="type = '2'"
      >
        角色管理
      </div>
    </div>
    <div>
      <component :is="type === '1' ? 'userManage' : 'roleManage'" />
    </div>
  </div>
</template>
<script>
import userManage from './index.vue'
import roleManage from '../roleManage/index.vue'
export default {
  name: 'UseManageHome',
  components: {
    userManage,
    roleManage
  },
  data () {
    return {
      type: '1'
    }
  },
  mounted () {},
  methods: {}
}
</script>
<style lang="scss" scoped>
.top {
  background: #fff;
  display: flex;
  justify-content: flex-end;
  padding-right: 60px;
  padding-bottom: 20px;
  .btn {
    background: #d7d7d7;
    height: 45px;
    line-height: 45px;
    width: 150px;
    border-radius: 5px;
    text-align: center;
    margin-right: 20px;
    cursor: pointer;
  }
  .choose {
    background: #3d81fd;
    color: #fff;
  }
}
</style>
