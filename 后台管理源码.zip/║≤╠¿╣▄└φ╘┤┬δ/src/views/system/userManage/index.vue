<template>
  <div class="commonContainer">
    <div class="header">
      <el-form :inline="true" :model="formInline" class="list-filter-wrap">
        <!-- <el-form-item label="员工姓名">
          <el-input
            v-model.trim="filter.name"
            placeholder="请输入员工姓名"
            maxlength="30"
            clearable
          />
        </el-form-item> -->
        <el-form-item label="手机号">
          <el-input
            v-model.trim="filter.phone"
            placeholder="请输入手机号"
            maxlength="11"
            clearable
          />
        </el-form-item>
        <el-form-item>
          <el-button type="primary" @click="search">查询</el-button>
          <el-button @click="reset">重置</el-button>
        </el-form-item>
      </el-form>
    </div>
    <div class="content list-content-wrap">
      <el-button
        v-perm-code="'1506105219941904386'"
        type="primary"
        icon="el-icon-plus"
        class="mb-20"
        @click="handleAdd"
      >添加账号</el-button>
      <TableCommon
        ref="parentTable"
        :filter="filter"
        :head-list="headList"
        :table-list="tableList"
        auth-id="1506105220063539202,1506105220189368322,1506105220503941121,1506105220403277825,1506105220281643009"
      >
        <div slot="button" slot-scope="props">
          <div v-perm-code="'1506105220063539202'">
            <el-button
              v-if="!props.scope.isSuperAdmin"
              type="text"
              class="pd-55"
              @click="handleEdit(props.scope)"
            >编辑</el-button>
          </div>
          <div class="" v-perm-code="'1506105220189368322'">
            <el-button
              type="text"
              class="pd-55"
              @click="handleReset(props.scope)"
            >重置密码</el-button>
          </div>
          <div class="pd-55" v-perm-code="'1506105220503941121'">
            <el-button
              v-if="!props.scope.isSuperAdmin"
              type="text"
              class="red"
              @click="handleDel(props.scope)"
            >删除</el-button>
          </div>
          <template>
            <div class="pd-55" v-perm-code="'1506105220403277825'">
              <el-button
                v-if="props.scope.status === 1 && !props.scope.isSuperAdmin"
                type="text"
                @click="handleEnable(props.scope)"
              >启用</el-button>
            </div>
          </template>
          <template>
            <div class="pd-55" v-perm-code="'1506105220281643009'">
              <el-button
                v-if="props.scope.status === 0 && !props.scope.isSuperAdmin"
                type="text"
                @click="handleDisable(props.scope)"
              >停用</el-button>
            </div>
          </template>
        </div>
      </TableCommon>
      <pagination :page-param="filter" @pageChange="pageChange" />
    </div>

    <!-- 模态框 -->
    <el-dialog
      v-if="visible"
      :title="dialogTitle"
      width="532px"
      :close-on-click-modal="false"
      :visible.sync="visible"
    >
      <OperationModal
        v-if="modalType === 'add' || modalType === 'edit'"
        :modal-type="modalType"
        :params="modalParam"
        @operationSubmit="operationSubmit"
        @operationCancel="operationCancel"
      />
    </el-dialog>
  </div>
</template>
<script>
import TableCommon from '@/components/table/TableCommon.vue'
import pagination from '@/components/pagination/index'
import OperationModal from './components/operationModal.vue'
import * as systemApi from '@/api/system'
export default {
  name: 'UserManage',
  components: {
    TableCommon,
    pagination,
    OperationModal
  },
  data () {
    return {
      filter: {
        name: '',
        phone: '',
        pageSize: 10,
        pageNo: 1,
        total: 0
      },
      headList: [
        { prop: 'account', label: '账号' },
        { prop: 'name', label: '员工姓名' },
        { prop: 'roleStr', label: '角色' },
        { prop: 'phone', label: '手机号码' },
        { prop: 'statusText', label: '状态' }
      ],
      tableList: [],
      dialogTitle: '',
      visible: false,
      modalParam: {},
      modalType: ''
    }
  },
  created () {
    this.reset()
  },
  activated () {
    this.reset()
  },
  methods: {
    search () {
      this.filter.pageNo = 1
      this.initList()
    },
    // 重置
    reset () {
      this.filter = {
        name: '',
        phone: '',
        pageSize: 10,
        pageNo: 1,
        total: 0
      }
      this.initList()
    },
    // 新增人员
    handleAdd () {
      this.dialogTitle = '添加账号'
      this.visible = true
      this.modalType = 'add'
    },
    operationSubmit (param) {
      systemApi[this.modalType === 'add' ? 'addUser' : 'editUser'](param).then(
        (res) => {
          this.$message({
            message: this.modalType === 'add' ? '新增成功' : '编辑成功',
            type: 'success',
            center: true,
            duration: 1000
          })
          this.operationCancel()
          this.initList()
        }
      )
    },
    operationCancel () {
      this.visible = false
    },
    // 人员编辑
    handleEdit (ele) {
      this.modalParam = ele
      this.dialogTitle = '编辑账号'
      this.visible = true
      this.modalType = 'edit'
    },
    handleReset (ele) {
      this.$confirm(
        `确定要重置  <b class="red">${ele.name}</b> 账号吗，初始密码123456?`,
        '提示',
        {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning',
          dangerouslyUseHTMLString: true
        }
      )
        .then(() => {
          systemApi
            .resetPassword({
              id: ele.id
            })
            .then(({ data }) => {
              this.$message({
                message: `重置密码成功`,
                type: 'success',
                center: true,
                duration: 1000
              })
              this.initList()
            })
        })
        .catch(() => {})
    },
    // table删除
    handleDel (ele) {
      this.$confirm(`确定删除 <b class="red">${ele.name}</b> 用户吗?`, '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning',
        dangerouslyUseHTMLString: true
      })
        .then(() => {
          systemApi
            .delUser({
              id: ele.id
            })
            .then(({ data }) => {
              this.$message({
                message: `删除成功`,
                type: 'success',
                center: true,
                duration: 1000
              })
              this.initList()
            })
        })
        .catch(() => {})
    },
    handleEnable (ele) {
      this.$confirm(`确定启用 <b class="red">${ele.name}</b> 用户吗?`, '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning',
        dangerouslyUseHTMLString: true
      })
        .then(() => {
          systemApi
            .changeUserStatus({
              id: ele.id,
              status: '0'
            })
            .then(({ data }) => {
              this.$message({
                message: `启用成功`,
                type: 'success',
                center: true,
                duration: 1000
              })
              this.initList()
            })
        })
        .catch(() => {})
    },
    handleDisable (ele) {
      this.$confirm(`确定停用 <b class="red">${ele.name}</b> 用户吗?`, '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning',
        dangerouslyUseHTMLString: true
      })
        .then(() => {
          systemApi
            .changeUserStatus({
              id: ele.id,
              status: '1'
            })
            .then(({ data }) => {
              this.$message({
                message: `停用成功`,
                type: 'success',
                center: true,
                duration: 1000
              })
              this.initList()
            })
        })
        .catch(() => {})
    },
    // 分页改变触发
    pageChange (pageNo) {
      this.filter.pageNo = Number(pageNo)
      this.initList()
    },
    // table数据初始
    initList () {
      systemApi.getUserPage(this.filter).then(({ data }) => {
        this.tableList = (data.data.rows || []).map((item) => {
          item.statusText = item.status === 0 ? '正常' : '停用'
          return item
        })
        this.filter.total = Number(data.data.totalRows)
      })
    }
  }
}
</script>
<style lang="scss" scoped>
.commonContainer {
  .header {
    .list-filter-wrap {
      padding-top: 10px;
      padding-bottom: 0px;
    }
  }
}
</style>
