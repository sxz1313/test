<template>
  <div class="edit-role detail-content-wrap">
    <el-form
      ref="ruleForm"
      :inline="true"
      :model="ruleForm"
      :rules="rules"
    >
      <el-form-item label="角色名称" prop="name">
        <el-input
          v-model.trim="ruleForm.name"
          placeholder="请输入角色名称"
          maxlength="30"
          clearable
          :disabled="param.handleType === 'view'"
        />
      </el-form-item>
      <el-form-item label="角色描述" prop="remark">
        <el-input
          v-model.trim="ruleForm.remark"
          placeholder="请输入角色描述"
          maxlength="30"
          clearable
          :disabled="param.handleType === 'view'"
        />
      </el-form-item>
    </el-form>
    <el-table
      ref="refTable"
      :data="tableList"
      :row-key="
        (row) => {
          return row.id;
        }
      "
      border
      style="width: 100%"
      :tree-props="{ children: 'children', hasChildren: 'hasChildren' }"
      default-expand-all
    >
      <el-table-column
        prop="title"
        align="center"
        label="资源菜单"
        width="300px"
      >
        <template slot-scope="scope">
          <el-checkbox
            v-model="pageChecked"
            :label="scope.row.id"
            :disabled="param.handleType === 'view'"
            @change="pageChange(scope.row)"
          >
            {{ scope.row.title }}
          </el-checkbox>
        </template>
      </el-table-column>
      <el-table-column
        prop="btns"
        align="center"
        label="操作权限"
        show-overflow-tooltip
      >
        <template slot-scope="scope">
          <el-checkbox-group
            v-model="pageChecked"
            class="d_f_x"
            @change="btnChange(scope.row, $event)"
          >
            <el-checkbox
              v-for="(item, index) in scope.row.btns"
              :key="index"
              :label="item.id"
              :disabled="param.handleType === 'view'"
            >
              {{ item.title }}
            </el-checkbox>
          </el-checkbox-group>
        </template>
      </el-table-column>
    </el-table>
    <div class="tc mt">
      <el-button @click="onCancel">返回</el-button>
      <el-button
        v-show="param.handleType !== 'view'"
        type="primary"
        @click="onSubmit('ruleForm')"
      >确认</el-button>
    </div>
  </div>
</template>
<script>
import * as systemApi from '@/api/system'

export default {
  name: 'EditRole',
  data () {
    return {
      ruleForm: {
        name: '',
        remark: ''
      },
      tableList: [],
      param: {
        id: '',
        handleType: ''
      },
      pageChecked: [],
      rules: {
        name: [
          { required: true, message: '请输入角色名称', trigger: 'blur' }
        ]
      }
    }
  },
  created () {
    this.param = this.$route.query
    this.initData()
    this.initList()
  },
  methods: {
    // 获取权限tree数据
    initList () {
      systemApi.getRoleGrantTree().then(({ data }) => {
        this.tableList = data.data || []
        this.tableList.forEach(ele => {
          ele.level = 1
          ele.isSelect = false;
          (ele.children || []).forEach((item) => {
            item.level = 2
            item.parentId = ele.id
            item.isSelect = false
            item.btns = JSON.parse(JSON.stringify(item.children));
            (item.btns || []).forEach(e => {
              e.parentId = item.id
              e.isSelect = false
              e.grandParentId = ele.id
            })
            delete item.children
          })
        })
      })
    },
    // 页面权限设置触发
    pageChange (row) {
      if (row.level === 1) {
        row.isSelect = !row.isSelect
        if (row.isSelect) {
          this.pageChecked.push(row.id);
          (row.children || []).forEach((item) => {
            this.pageChecked.push(item.id)
            item.isSelect = true;
            (item.btns || []).forEach((e) => {
              this.pageChecked.push(e.id)
            })
          })
        } else {
          this.pageChecked = this.pageChecked.filter((ele) => ele !== row.id);
          (row.children || []).forEach((item) => {
            this.pageChecked = this.pageChecked.filter(
              (ele) => ele !== item.id
            )
            item.isSelect = false;
            (item.btns || []).forEach((e) => {
              this.pageChecked = this.pageChecked.filter((ele) => ele !== e.id)
            })
          })
        }
      }
      if (row.level === 2) {
        row.isSelect = !row.isSelect
        if (row.isSelect) {
          this.pageChecked.push(row.id)
          this.pageChecked.push(row.parentId);
          (row.btns || []).forEach((e) => {
            this.pageChecked.push(e.id)
          })
          this.parenTree()
        } else {
          this.pageChecked = this.pageChecked.filter((ele) => ele !== row.id)
          row.isSelect = false;
          (row.btns || []).forEach((e) => {
            this.pageChecked = this.pageChecked.filter((ele) => ele !== e.id)
          })
          // 联动一级菜单权限
          let secondFlag = false
          this.tableList.forEach((ele) => {
            if (ele.id === row.parentId) {
              secondFlag = (ele.children || []).some((e) => e.isSelect)
              if (!secondFlag) {
                ele.isSelect = false
              }
            }
          })
          if (!secondFlag) {
            this.pageChecked = this.pageChecked.filter(
              (ele) => ele !== row.parentId
            )
          }
        }
      }
    },
    btnChange (row, e) {
      (row.btns || []).forEach((ele) => {
        ele.isSelect = false
        if (e.includes(ele.id)) {
          ele.isSelect = true
          this.pageChecked.push(ele.parentId)
          this.pageChecked.push(ele.grandParentId)
          this.parenTree()
        }
      })
      this.pageChecked = [...new Set(this.pageChecked)]
    },
    // 确定操作
    onSubmit (formName) {
      this.$refs[formName].validate((valid) => {
        if (valid) {
          const resourceIds = [...new Set(this.pageChecked)]
          const param = {
            name: this.ruleForm.name,
            remark: this.ruleForm.remark,
            id: this.ruleForm.id,
            grantMenuIdList: resourceIds
          }
          if (this.param.handleType === 'add') {
            this.addSave(param)
          } else if (this.param.handleType === 'edit') {
            Object.assign(param, {
              roleId: this.param.id
            })
            this.editSave(param)
          }
        } else {
          return false
        }
      })
    },
    // 新增保存
    addSave (param) {
      systemApi.addRole(param).then(({ data }) => {
        this.$message({
          message: '新增成功',
          type: 'success',
          center: true,
          duration: 1000
        })
        this.$router.back()
      })
    },
    // 编辑保存
    editSave (param) {
      systemApi.editRole(param).then(({ data }) => {
        this.$message({
          message: '编辑成功',
          type: 'success',
          center: true,
          duration: 1000
        })
        this.$router.back()
      })
    },
    // 取消操作
    onCancel () {
      this.$router.back()
    },
    // 循环获取上层节点是否选择标志位
    parenTree () {
      (this.tableList || []).forEach((ele) => {
        if (this.pageChecked.includes(ele.id)) {
          ele.isSelect = true
        }
        (ele.children || []).forEach((item) => {
          if (this.pageChecked.includes(item.id)) {
            ele.isSelect = true
            item.isSelect = true
          }
          (item.btns || []).forEach((e) => {
            if (this.pageChecked.includes(e.id)) {
              e.isSelect = true
              ele.isSelect = true
              item.isSelect = true
            }
          })
        })
      })
    },
    initData () {
      if (this.param.handleType === 'edit') {
        systemApi.getRoleDetail({ id: this.param.id }).then(res => {
          this.ruleForm = res.data.data
          this.pageChecked = res.data.data.grantMenuIdList
          this.parenTree()
        })
      }
    }
  }
}
</script>
<style lang="scss" scoped>
.d_f_x {
  display: flex;
  flex-wrap: wrap;
  .el-checkbox {
    width: 125px;
    text-align: left;
  }
}
.edit-role {
  overflow: auto;
  max-height: calc(100vh - 90px);
}
.btns {
  margin: 0px 0px 20px 80px;
}
</style>
