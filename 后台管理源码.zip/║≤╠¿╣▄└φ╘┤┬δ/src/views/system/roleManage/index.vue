<template>
  <div class="commonContainer">
    <div class="header">
      <el-form :inline="true" :model="formInline" class="list-filter-wrap">
        <el-form-item label="角色名称">
          <el-input
            v-model.trim="filter.name"
            placeholder="请输入角色名称"
            maxlength="30"
            clearable
          />
        </el-form-item>
        <el-form-item>
          <el-button type="primary" @click="search">查询</el-button>
          <el-button @click="reset">重置</el-button>
        </el-form-item>
      </el-form>
    </div>
    <div class="content list-content-wrap">
      <el-button
        v-perm-code="'1506105220772376577'"
        type="primary"
        icon="el-icon-plus"
        class="mb-20"
        @click="addNew"
      >新建</el-button>
      <tableCommon
        :head-list="headList"
        :table-list="tableList"
        :filter="filter"
        auth-id="1506105220881428481,1506105220772376578"
      >
        <div slot="button" slot-scope="props" class="d-flx-s">
          <div class="pd-55" v-perm-code="'1506105220881428481'">
            <el-button v-if="props.scope.adminType !== 1" type="text" @click="handleEdit(props.scope)">编辑</el-button>
          </div>
          <!-- <el-button v-perm-code="'1407170055662592005'" type="text" @click="handlePreview(props.scope)">查看</el-button> -->
          <div v-perm-code="'1506105220772376578'">
            <el-button
              v-if="!Number(props.scope.userCount)"
              type="text"
              class="red pd-55"
              @click="handleDel(props.scope)"
            >删除</el-button>
          </div>
        </div>
      </tableCommon>
    </div>
  </div>
</template>
<script>
import tableCommon from '@/components/table/TableCommon'
// import pagination from '@/components/pagination/index'
import * as systemApi from '@/api/system'

export default {
  name: 'RoleManage',
  components: {
    tableCommon
    // pagination
  },
  data () {
    return {
      headList: [
        { prop: 'name', label: '角色名称' },
        { prop: 'remark', label: '角色描述' },
        { prop: 'userCount', label: '关联账号' }
      ],
      tableList: [],
      filter: {
        name: '',
        pageSize: 10,
        pageNo: 1,
        total: 0
      },
      editParam: {}
    }
  },
  created () {
    this.initList()
  },
  activated () {
    this.initList()
  },
  methods: {
    search () {
      this.filter.pageNo = 1
      this.initList()
    },
    // 重置
    reset () {
      this.filter = {
        name: '',
        pageSize: 10,
        pageNo: 1,
        total: 0
      }
      this.initList()
    },
    // table新增
    addNew () {
      this.$router.push({
        name: 'addRole',
        query: { handleType: 'add' }
      })
    },
    // table编辑
    handleEdit (ele) {
      this.$router.push({
        name: 'addRole',
        query: { id: ele.id, handleType: 'edit' }
      })
    },
    // table查看
    handlePreview (ele) {
      this.$router.push({
        name: 'addRole',
        query: { id: ele.id, handleType: 'view' }
      })
    },
    // table删除
    handleDel (ele) {
      this.$confirm(`确定删除 <b class="red">${ele.name}</b> 角色吗?`, '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning',
        dangerouslyUseHTMLString: true
      }).then(() => {
        systemApi.delRole({
          id: ele.id,
          loginPortType: '1'
        }).then(({ data }) => {
          this.$message({
            message: '删除成功',
            type: 'success',
            center: true,
            duration: 1000
          })
          this.initList()
        })
      })
    },
    // 分页改变触发
    // pageChange (pageNo) {
    //   this.filter.pageNo = Number(pageNo)
    //   this.initList()
    // },
    // table数据初始
    initList () {
      systemApi.getRolePage(this.filter).then(({ data }) => {
        this.tableList = data.data || []
        // this.filter.total = Number(data.data.totalRows)
      })
    }
  }
}
</script>
<style lang="scss" scoped>
.commonContainer {
  .header {
    .list-filter-wrap {
      padding-top: 10px;
      padding-bottom: 0px;
    }
  }
}
</style>
