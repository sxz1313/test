<template>
  <div class="commonContainer">
    <div class="header">
      <el-form :inline="true" :model="formInline" class="list-filter-wrap">
        <el-form-item label="字典名称">
          <el-input
            v-model.trim="filter.dictType"
            placeholder="请输入字典名称"
            maxlength="30"
            clearable
          />
        </el-form-item>
        <el-form-item>
          <el-button type="primary" @click="search">查询</el-button>
          <el-button @click="reset">重置</el-button>
        </el-form-item>
      </el-form>
    </div>
    <div class="content list-content-wrap">
      <div class="mb-1">
        <el-button type="primary" @click="add">新建</el-button>
      </div>
      <table_common
        :head-list="headList"
        :table-list="tableList"
        :filter="filter"
        :operateWidth="160"
      >
        <div slot="button" slot-scope="props">
          <el-button type="text" @click="edit(props.scope)">编辑</el-button>
          <el-button type="text" @click="handleEdit(props.scope)">编辑条目</el-button>
          <el-button type="text" @click="handlePreview(props.scope)">查看</el-button>
        </div>
      </table_common>
      <pagination :page-param="filter" @pageChange="pageChange" />
    </div>
    <el-dialog
      v-if="addVisible"
      :title="addTitle"
      width="40%"
      :close-on-click-modal="false"
      :visible.sync="addVisible"
    >
      <add
        :editId="editId"
        :name="name"
        :code="code"
        @submit="onSubmit"
        @cancel="onCancel"
      />
    </el-dialog>
    <!-- 编辑/查看模态框 -->
    <el-dialog
      v-if="editVisible"
      :title="editTitle"
      width="632px"
      :close-on-click-modal="false"
      :visible.sync="editVisible"
    >
      <edit-dict-modal
        :edit-param="editParam"
        :record-head-list="recordHeadList"
        @submit="onSubmit"
        @cancel="onCancel"
      />
    </el-dialog>
  </div>
</template>
<script>
import * as api from '@/api/system'
import table_common from '@/components/table/TableCommon'
import pagination from '@/components/pagination/index'
import editDictModal from './components/EditDictModal'
import add from './components/add'
export default {
  name: 'DictManage',
  components: {
    table_common,
    pagination,
    editDictModal,
    add
  },
  data () {
    return {
      headList: [
        { prop: 'dictTypeName', label: '字典名称' },
        { prop: 'dictDataItem', label: '字典条目' },
        { prop: 'createTime', label: '创建时间' }
      ],
      tableList: [],
      filter: {
        dictType: '',
        pageSize: 10,
        pageNo: 1,
        total: 0
      },
      editId: '',
      name: '',
      code: '',
      addTitle: '新增字典',
      editVisible: false,
      addVisible: false,
      editTitle: '编辑字典',
      editParam: {},
      recordHeadList: [
        { prop: 'name', label: '原专业' },
        { prop: 'childs', label: '新专业及班级' },
        { prop: 'time', label: '备注' },
        { prop: 'time', label: '操作人' },
        { prop: 'time', label: '调换时间' }
      ]
    }
  },
  created () {
    this.initList()
  },
  activated () {
    this.initList()
  },
  methods: {
    // table数据初始
    initList () {
      const param = {
        dictType: this.filter.dictType,
        pageNo: this.filter.pageNo,
        pageSize: this.filter.pageSize
      }
      api.dictDataList(param).then(({ data }) => {
        this.tableList = (data.data.records || []).map((item) => {
          item.dictDataItem = (item.dictData && item.dictData.length > 0) ? item.dictData.join(',') : ''
          return item
        })
        this.filter.total = Number(data.data.total)
      })
    },
    // 查询操作
    search () {
      this.filter.pageNo = 1
      this.initList()
    },
    // 重置
    reset () {
      this.filter.dictType = ''
      this.initList()
    },
    // table编辑
    handleEdit (ele) {
      this.editTitle = '编辑字典'
      this.editParam = Object.assign(ele, {
        edit: true
      })
      this.editVisible = true
    },
    // table查看
    handlePreview (ele) {
      this.editTitle = '查看字典'
      this.editParam = Object.assign(ele, {
        edit: false
      })
      this.editVisible = true
    },
    // 分页改变触发
    pageChange (pageNo) {
      this.filter.pageNo = Number(pageNo)
      this.initList()
    },
    add () {
      this.addVisible = true
      this.addTitle = '新增字典'
    },
    edit (row) {
      this.addTitle = '编辑字典'
      this.addVisible = true
      this.editId = row.dictTypeId
      this.name = row.dictTypeName
      this.code = row.code
    },
    // 模态框确认操作
    onSubmit () {
      this.editVisible = false
      this.addVisible = false
      this.initList()
    },
    // 模态框取消操作
    onCancel () {
      this.editVisible = false
      this.addVisible = false
    }
  }
}
</script>
<style lang="scss" scoped>

</style>
