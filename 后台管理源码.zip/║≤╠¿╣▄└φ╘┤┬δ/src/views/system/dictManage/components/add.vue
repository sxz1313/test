<template>
  <el-form
    ref="ruleForm"
    :model="ruleForm"
    :rules="rules"
    label-width="130px"
  >
    <el-form-item label="字典名称：" prop="name">
      <el-input v-model="ruleForm.name" class="w-240" />
    </el-form-item>
    <el-form-item label="code：" prop="code">
      <el-input v-model="ruleForm.code" class="w-240" />
    </el-form-item>
    <el-form-item>
      <el-button @click="back">返回</el-button>
      <el-button type="primary" @click="submitForm('ruleForm')">确定</el-button>
    </el-form-item>
  </el-form>
</template>
<script>
import * as api from '@/api/system'
export default {
  props: {
    editId: {
      type: String,
      default: ''
    },
    name: {
      type: String,
      default: ''
    },
    code: {
      type: String,
      default: ''
    }
  },
  data () {
    return {
      ruleForm: {
        name: '',
        code: ''
      },
      rules: {
        name: [{ required: true, message: '请输入字典名称', trigger: 'blur' }],
        code: [{ required: true, message: '请输入code', trigger: 'blur' }]
      }
    }
  },
  created () {
    if (this.editId) {
      this.ruleForm.name = this.name
      this.ruleForm.code = this.code
      this.ruleForm.id = this.editId
    }
  },
  methods: {
    submitForm (formName) {
      this.$refs[formName].validate((valid) => {
        if (valid) {
          if (this.editId) {
            api.dictTypeSave(this.ruleForm).then(({ data }) => {
              this.$message.success('编辑成功')
              this.$emit('submit')
            })
          } else {
            api.dictTypeSave(this.ruleForm).then(({ data }) => {
              this.$message.success('编辑成功')
              this.$emit('submit')
            })
          }
        }
      })
    },
    back () {
      this.$emit('cancel')
    }
  }
}
</script>
