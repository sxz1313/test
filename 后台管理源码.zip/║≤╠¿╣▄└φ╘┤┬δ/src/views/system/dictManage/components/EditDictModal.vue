<template>
  <div class="EditDict">
    <div class="head">
      <p>{{ editParam.name }}</p>
      <el-button v-show="editParam.edit" type="text" @click="addItem">添加条目</el-button>
    </div>
    <div class="content">
      <table_input
        :head-list="headList"
        :table-list="tableList"
        :is-edit="editParam.edit"
        @on-input="onInput"
      >
        <div slot="button" slot-scope="props">
          <el-button type="text" @click="handleDel(props.scope)">删除</el-button>
        </div>
      </table_input>
    </div>
    <div class="tc mt">
      <el-button @click="onCancel">{{ editParam.edit ? '取消' : '关闭' }}</el-button>
      <el-button
        v-show="editParam.edit"
        type="primary"
        @click="onSubmit"
      >保存</el-button>
    </div>
  </div>
</template>
<script>
import * as api from '@/api/system'
import table_input from '@/components/table/TableInput'
export default {
  name: 'EditDict',
  components: {
    table_input
  },
  props: {
    editParam: {
      type: Object,
      default: () => {}
    }
  },
  data () {
    return {
      headList: [
        { prop: 'code', label: 'ID', isNum: true },
        { prop: 'value', label: '字典目录' },
        { prop: 'sort', label: '排序', isNum: true }
      ],
      tableList: []
    }
  },
  created () {
    this.initList()
  },
  methods: {
    // table数据初始
    initList () {
      api.dictDataById(this.editParam.dictTypeId).then(({ data }) => {
        this.tableList = data.data || []
      })
    },
    // 文本框变化触发
    onInput (ele, scope) {
      (this.tableList || []).forEach((element, index) => {
        if (element.code === ele.code && scope.$index === index) {
          element.value = ele.value
          element.sort = ele.sort
        }
      })
    },
    // 添加条目
    addItem () {
      this.tableList.push({
        code: +new Date(),
        value: '',
        sort: ''
      })
    },
    // 删除条目
    handleDel (ele) {
      this.tableList.splice(ele.$index, 1)
    },
    // 确定操作
    onSubmit () {
      let isFlag = true
      this.tableList.forEach((ele) => {
        if ((!ele.value || !ele.sort) && ele.sort !== 0) {
          isFlag = false
          return
        }
      })
      const dictSubName = (this.tableList || []).map((item) => item.value)
      const dictSubCode = (this.tableList || []).map((item) => item.code)
      if ([...new Set(dictSubName)].length !== this.tableList.length) {
        this.$message({
          message: '存在重复的字典目录',
          type: 'warning',
          center: true,
          duration: 2000
        })
        isFlag = false
        return
      }
      if ([...new Set(dictSubCode)].length !== this.tableList.length) {
        this.$message({
          message: '存在重复的字典ID',
          type: 'warning',
          center: true,
          duration: 2000
        })
        isFlag = false
        return
      }
      if (isFlag) {
        api.saveDictData(this.editParam.dictTypeId, this.tableList).then(({ data }) => {
          this.$message({
            message: '编辑成功',
            type: 'success',
            center: true,
            duration: 1000
          })
          this.$emit('submit')
        })
      } else {
        this.$message({
          message: '请填写完整信息',
          type: 'warning',
          center: true,
          duration: 1000
        })
      }
    },
    // 取消操作
    onCancel () {
      this.$emit('cancel')
    }
  }
}
</script>
<style lang="scss" scoped>
.EditDict{
  .head{
    display: flex;
    justify-content: space-between;
  }
}
</style>
