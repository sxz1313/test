<template>
  <keep-alive
    :include="cachePages"
    :max="1"
  >
    <router-view />
  </keep-alive>
</template>

<script type="text/ecmascript-6">
export default {
  data () {
    return {
      cachePages: ['RoleManage', 'UserManage', 'UseManageHome']
    }
  }
}
</script>
