<template>
  <common-login>
    <p>忘记密码</p>
    <el-input
      v-model.trim="phone"
      class="loginInput"
      placeholder="请输入手机号"
      maxlength="11"
      @keyup.enter="submit"
    >
      <i slot="prefix" class="el-input__icon el-icon-user" />
    </el-input>
    <div class="loginInput">
      <el-input
        v-model.trim="verCode"
        class="innerInput"
        placeholder="请输入验证码"
        maxlength="20"
        @keyup.enter="submit"
      />
      <el-button
        v-if="isShowGetCode"
        type="primary"
        @click="sendCode"
      >发送验证码</el-button>
      <span
        v-else
        class="identiCode cancel-pointer"
      >{{ countdown }}s后可重试</span>
    </div>
    <el-input
      v-model.trim="password"
      class="loginInput"
      type="password"
      placeholder="请输入重置密码"
      maxlength="20"
      @keyup.enter="submit"
    >
      <i slot="prefix" class="el-input__icon el-icon-lock" />
    </el-input>
    <el-button
      class="submitBtn"
      type="primary"
      :disabled="!phone || !password || !verCode"
      @click="submit"
    >确认</el-button>
    <div class="operate" style="justify-content: flex-end;">
      <el-button type="text" @click="goToLogin">返回登录</el-button>
    </div>
  </common-login>
</template>
<script>
// import * as api from '@/api/meeting/system'
import commonLogin from '@/components/commonLogin/index'
export default {
  name: 'Register',
  components: { commonLogin },
  data () {
    return {
      phone: '',
      password: '',
      verCode: '',
      countdown: 60,
      timer: '',
      isShowGetCode: true
    }
  },
  created () {},
  beforeDestroy () {
    clearInterval(this.timer)
    this.countdown = 60
    this.isShowGetCode = true
  },
  methods: {
    // 发送验证码
    sendCode () {
      // const param = {
      //   phone: this.phone,
      //   type: 1
      // }
      // api.sendMessage(param).then(({ data }) => {
      //   this.countDown()
      //   this.isShowGetCode = false
      // })
    },
    countDown () {
      const self = this
      this.timer = setInterval(() => {
        self.countdown--
        if (self.countdown === 0) {
          clearInterval(self.timer)
          self.countdown = 60
          self.isShowGetCode = true
        }
      }, 1000)
    },

    // 确认提交
    submit () {
      // const param = {
      //   code: this.verCode,
      //   newPassword: this.password,
      //   phone: this.phone
      // }
      // api.forgetPwd(param).then(({ data }) => {
      //   this.$message({
      //     message: '密码设置成功',
      //     type: 'success',
      //     center: true,
      //     duration: 1000
      //   })
      //   this.$router.replace({ path: '/login' })
      // })
    },
    // 返回登录
    goToLogin () {
      this.$router.push({
        name: 'login'
      })
    }
  }
}
</script>

<style lang="scss" scoped>
.identiCode {
	color: #1abc9c;
	line-height: 32px;
}
</style>
