<template>
  <div class="commonContainer">
    <el-form
      ref="ruleForm"
      :model="ruleForm"
      :rules="rules"
      label-width="160px"
    >
      <el-form-item label="单位名称：">
        <el-col :span="12">
          <el-form-item>{{ruleForm.name}}</el-form-item>
        </el-col>
        <el-col :span="12">
          <el-form-item label="统一社会信用代码：">{{ruleForm.socialCreditCode}}</el-form-item>
        </el-col>
      </el-form-item>
      <el-form-item label="营业执照：">
        <img style="width: 80%;display: inline-block" :src="ruleForm.businessLicenseFileUrl" alt="">
      </el-form-item>
      <el-form-item label="联系人姓名：">
        <el-col :span="12">
          <el-form-item>{{ruleForm.contactUser}}</el-form-item>
        </el-col>
        <el-col :span="12">
          <el-form-item label="联系方式：">{{ruleForm.contactPhone}}</el-form-item>
        </el-col>
      </el-form-item>
    </el-form>
    <div class="dis-flex-c">
      <el-button @click="back">返回</el-button>
    </div>
  </div>
</template>
<script>
import * as api from '@/api/company'
export default {
  data () {
    return {
      id: this.$route.query.id,
      ruleForm: {},
      rules: {}
    }
  },
  created () {
    api.companyDetail(this.id).then(({ data }) => {
      this.ruleForm = data.data
    })
  },
  methods: {
    back () {
      this.$router.back()
    }
  }
}
</script>
<style lang="scss" scoped>
  .commonContainer /deep/ {
    background: #fff;
    min-height: calc(100vh - 186px);
    padding: 0 20px 20px;
    .el-col{
      .el-form-item--mini.el-form-item, .el-form-item--small.el-form-item{
        margin-bottom: 0;
      }
    }
  }
</style>
