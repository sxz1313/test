<template>
  <div class="commonContainer">
    <el-form
      ref="ruleForm"
      :model="ruleForm"
      :rules="rules"
      label-width="160px"
    >
      <el-form-item label="基本信息" class="tl" />
      <el-form-item label="单位名称：" prop="name">
        <el-input v-model="ruleForm.name" class="w-240" />
      </el-form-item>
      <el-form-item label="统一社会信用代码：" prop="socialCreditCode">
        <el-input v-model="ruleForm.socialCreditCode" class="w-240" />
      </el-form-item>
      <el-form-item label="营业执照：" prop="photo">
        <div class="w-300">
          <UploadImage
            :upState="true"
            :img-url="ruleForm.photo"
            @handleImgSuccess="handleImgSuccess"
          />
        </div>
      </el-form-item>
      <el-form-item label="联系人：" class="tl" />
      <el-form-item label="联系人姓名：">
        <el-col :span="12">
          <el-form-item>
            <el-input v-model="ruleForm.contactUser" class="w-240" />
          </el-form-item>
        </el-col>
        <el-col :span="12">
          <el-form-item label="联系方式">
            <el-input
              v-model="ruleForm.contactPhone"
              class="w-240"
              onkeyup="this.value=this.value.replace(/[^\d.]/g,'')"
              maxlength="11"
            />
          </el-form-item>
        </el-col>
      </el-form-item>
    </el-form>
    <div class="dis-flex-c">
      <el-button type="primary" @click="submitForm('ruleForm')">提交</el-button>
      <el-button @click="back">取消</el-button>
    </div>
  </div>
</template>
<script>
import UploadImage from '@/components/upload/ImageUploadOne.vue'
import * as api from '@/api/company'
export default {
  components: {
    UploadImage
  },
  data () {
    return {
      id: this.$route.query.id,
      ruleForm: {
        source: 1,
        name: '',
        socialCreditCode: '',
        contactUser: '',
        contactPhone: '',
        photo: ''
      },
      rules: {
        name: [{ required: true, message: '请输入单位名称', trigger: 'blur' }],
        socialCreditCode: [{ required: false, message: '请输入统一社会信用代码', trigger: 'blur' }],
        photo: [
          { required: false, message: '请上传营业执照', trigger: 'change' }
        ]
      }
    }
  },
  created () {
    if (this.id) {
      api.companyDetail(this.id).then(({ data }) => {
        data.data.photo = data.data.businessLicenseFileUrl
        this.ruleForm = data.data
      })
    }
  },
  methods: {
    handleImgSuccess (data) {
      this.ruleForm.businessLicenseFileId = data.fileId
      this.ruleForm.photo = data.fileUrl
    },
    submitForm (formName) {
      this.$refs[formName].validate((valid) => {
        if (valid) {
          if (this.ruleForm.contactPhone && this.ruleForm.contactPhone.length !== 11) {
            this.$message.warning('联系方式必须11位')
            return
          }
          if (this.id) {
            api.companyEdit(this.ruleForm).then(({ data }) => {
              this.$message.success('编辑成功')
              this.back()
            })
          } else {
            api.companyAdd(this.ruleForm).then(({ data }) => {
              this.$message.success('新增成功')
              this.back()
            })
          }
        }
      })
    },
    back () {
      this.$router.back()
    }
  }
}
</script>
<style lang="scss" scoped>
  .commonContainer /deep/ {
    background: #fff;
    min-height: calc(100vh - 186px);
    padding: 0 20px 20px;
    .tl{
      font-size: 16px;
      border-top: 1px solid #91d5ff;
      border-bottom: 1px solid #91d5ff;
      background: #e6f7ff;
      .el-form-item__label{
        line-height: 32px;
        height: 32px;
        padding: 0 0 0 24px;
        text-align: left;
      }
    }
  }
</style>
