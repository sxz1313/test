<template>
  <div class="commonContainer">
    <div class="header">
      <el-form :inline="true" :model="formInline" class="list-filter-wrap">
        <el-form-item label="单位名称：">
          <el-input
            v-model.trim="filter.name"
            placeholder="请输入单位姓名"
            maxlength="30"
            clearable
          />
        </el-form-item>
        <el-form-item label="联系人：">
          <el-input
            v-model.trim="filter.contactUser"
            placeholder="请输入联系人"
            maxlength="30"
            clearable
          />
        </el-form-item>
        <el-form-item>
          <el-button type="primary" @click="search">查询</el-button>
          <el-button @click="reset">重置</el-button>
        </el-form-item>
      </el-form>
    </div>
    <div class="content list-content-wrap">
      <div class="mb-1">
        <el-button v-perm-code="'1527089428533676990'" type="primary" @click="add">新增</el-button>
      </div>
      <TableCommon
        :head-list="headList"
        :table-list="tableList"
        :filter="filter"
        auth-id="1527089428533676991,1527089428533676992,1527089428533676993"
      >
        <div slot="button" slot-scope="props">
          <el-button v-perm-code="'1527089428533676991'" type="text" @click="check(props.scope)">查看</el-button>
          <el-button v-perm-code="'1527089428533676992'" type="text" @click="edit(props.scope)">编辑</el-button>
          <el-button v-perm-code="'1527089428533676993'" type="text" @click="del(props.scope)">删除</el-button>
        </div>
      </TableCommon>
      <pagination :page-param="filter" @pageChange="pageChange" />
    </div>
  </div>
</template>
<script>
import TableCommon from '@/components/table/TableCommon'
import pagination from '@/components/pagination/index'
import * as api from '@/api/company'
export default {
  components: {
    TableCommon,
    pagination
  },
  data () {
    return {
      filter: {
        qType: 2,
        name: '',
        contactUser: '',
        pageSize: 10,
        pageNo: 1,
        total: 0
      },
      headList: [
        { prop: 'name', label: '单位名称' },
        { prop: 'contactUser', label: '联系人' },
        { prop: 'socialCreditCode', label: '统一社会信用代码' }
      ],
      tableList: []
    }
  },
  created () {
    this.initList()
  },
  methods: {
    initList () {
      api.companyList(this.filter).then(({ data }) => {
        this.tableList = (data.data.rows || []).map((item) => {
          if (item.contactPhone && item.contactUser) {
            item.contactUser = item.contactUser + '（' + item.contactPhone + '）'
          }
          return item
        })
        this.filter.total = Number(data.data.totalRows)
      })
    },
    add () {
      this.$router.push({
        name: 'enterpriseAccountAddEdit'
      })
    },
    edit (row) {
      this.$router.push({
        name: 'enterpriseAccountAddEdit',
        query: {
          id: row.id
        }
      })
    },
    del (row) {
      this.$confirm('确认删除?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        api.companyDel(row.id).then(({ data }) => {
          this.$message({
            type: 'success',
            message: '删除成功!'
          })
          this.reset(1)
        })
      }).catch(() => {
        this.$message({
          type: 'info',
          message: '已取消删除'
        })
      })
    },
    check (row) {
      this.$router.push({
        name: 'enterpriseAccountCheck',
        query: {
          id: row.id
        }
      })
    },
    pageChange (pageNo) {
      this.filter.pageNo = Number(pageNo)
      this.initList()
    },
    search () {
      this.filter.pageNo = 1
      this.initList()
    },
    // 重置
    reset () {
      this.filter.name = ''
      this.filter.contactUser = ''
      this.pageChange(1)
    }
  }
}
</script>
