<template>
  <div class="commonContainer">
    <div class="header">
      <el-form :inline="true" :model="formInline" class="list-filter-wrap">
        <el-form-item label="单位名称：">
          <el-input
            v-model.trim="filter.name"
            placeholder="请输入单位姓名"
            maxlength="30"
            clearable
          />
        </el-form-item>
        <el-form-item label="联系人：">
          <el-input
            v-model.trim="filter.contactUser"
            placeholder="请输入联系人"
            maxlength="30"
            clearable
          />
        </el-form-item>
        <el-form-item>
          <el-button type="primary" @click="search">查询</el-button>
          <el-button @click="reset">重置</el-button>
        </el-form-item>
      </el-form>
    </div>
    <div class="content list-content-wrap">
      <TableCommon
        :head-list="headList"
        :table-list="tableList"
        auth-id="1527089428533675992"
        :filter="filter"
      >
        <div slot="button" slot-scope="props">
          <el-button v-perm-code="'1527089428533675992'" type="text" @click="review(props.scope)">审核</el-button>
        </div>
      </TableCommon>
      <pagination :page-param="filter" @pageChange="pageChange" />
    </div>
    <el-dialog
      v-if="reViewVisible"
      title="单位审核"
      width="50%"
      :close-on-click-modal="false"
      :visible.sync="reViewVisible"
    >
      <el-form
        ref="ruleForm"
        :model="ruleForm"
        :rules="rules"
        label-width="140px"
      >
        <el-form-item label="审核日期：">
          <el-col :span="12">
            <el-form-item>{{ruleForm.date}}</el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="统一社会信用代码：">{{ruleForm.socialCreditCode}}</el-form-item>
          </el-col>
        </el-form-item>
        <el-form-item label="单位名称：">
          <el-col :span="12">
            <el-form-item>{{ruleForm.name}}</el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="联系人：">{{ruleForm.contactUser}}</el-form-item>
          </el-col>
        </el-form-item>
        <el-form-item label="营业执照：">
          <img style="width: 80%;display: inline-block" :src="ruleForm.businessLicenseFileUrl" alt="">
        </el-form-item>
        <el-form-item>
          <el-button @click="submitForm('ruleForm', 2)">不通过</el-button>
          <el-button type="primary" @click="submitForm('ruleForm', 1)">审核通过</el-button>
        </el-form-item>
      </el-form>
    </el-dialog>
  </div>
</template>
<script>
import TableCommon from '@/components/table/TableCommon'
import pagination from '@/components/pagination/index'
import * as api from '@/api/company'
export default {
  components: {
    TableCommon,
    pagination
  },
  data () {
    return {
      reViewVisible: false,
      ruleForm: {
        date: this.$format(new Date(), 'yyyy-MM-dd'),
        num: '123'
      },
      rules: {},
      filter: {
        qType: 1,
        name: '',
        contactUser: '',
        pageSize: 10,
        pageNo: 1,
        total: 0
      },
      examineId: '',
      headList: [
        { prop: 'name', label: '单位名称' },
        { prop: 'contactUser', label: '联系人' },
        { prop: 'socialCreditCode', label: '统一社会信用代码' }
      ],
      tableList: []
    }
  },
  created () {
    this.initList()
  },
  methods: {
    initList () {
      api.companyList(this.filter).then(({ data }) => {
        this.tableList = data.data.rows
        this.filter.total = Number(data.data.totalRows)
      })
    },
    submitForm (formName, status) {
      this.$refs[formName].validate((valid) => {
        if (valid) {
          const param = {
            id: this.examineId,
            status: status
          }
          api.companyExamine(param).then(({ data }) => {
            this.reViewVisible = false
            this.$message.success('审核成功')
            this.pageChange(1)
          })
        }
      })
    },
    review (row) {
      this.reViewVisible = true
      this.examineId = row.id
      api.companyDetail(row.id).then(({ data }) => {
        this.ruleForm = data.data
        this.ruleForm.date = this.$format(new Date(), 'yyyy-MM-dd')
      })
    },
    pageChange (pageNo) {
      this.filter.pageNo = Number(pageNo)
      this.initList()
    },
    search () {
      this.filter.pageNo = 1
      this.initList()
    },
    // 重置
    reset () {
      this.filter.name = ''
      this.filter.contactUser = ''
      this.pageChange(1)
    }
  }
}
</script>
<style lang="scss" scoped>
  .commonContainer /deep/ {
    .el-col{
      .el-form-item--mini.el-form-item, .el-form-item--small.el-form-item{
        margin-bottom: 0;
      }
    }
  }
</style>
