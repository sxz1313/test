<template>
  <div>
    <common-login>
      <p>统一身份认证</p>
      <el-input
        v-model.trim="account"
        class="loginInput"
        placeholder="请输入账号"
        maxlength="20"
        @keyup.native.enter="login"
      >
        <i slot="prefix" class="el-input__icon el-icon-user" />
      </el-input>
      <el-input
        v-model.trim="password"
        class="loginInput"
        type="password"
        placeholder="请输入密码"
        maxlength="20"
        @keyup.native.enter="login"
      >
        <i slot="prefix" class="el-input__icon el-icon-lock" />
      </el-input>
      <!-- <div class="loginInput">
        <el-input
          v-model.trim="verCode"
          class="innerInput"
          placeholder="请输入验证码"
          maxlength="20"
          @keyup.native.enter="login"
        />
        <img :src="codeImg" class="verCode" @click="verCodeBtn">
      </div> -->
      <el-button
        :disabled="!account || !password"
        class="submitBtn"
        type="primary"
        @click="login"
      >立即登录</el-button>
      <div class="operate">
        <el-checkbox v-model="checked">记住密码</el-checkbox>
        <!-- <el-button type="text" @click="forget">忘记密码</el-button> -->
      </div>
    </common-login>
    <!-- 添加教室模态框 -->
    <el-dialog
      v-if="resetVisible"
      title="修改密码"
      width="532px"
      :close-on-click-modal="false"
      :visible.sync="resetVisible"
      @close="onCancel"
    >
      <reset-password @submit="onSubmit" @cancel="onCancel" />
    </el-dialog>
  </div>
</template>
<script>
import * as loginApi from '@/api/login'
import User from '@/controller/User'
import commonLogin from '@/components/commonLogin/index'
import cookies from '@/utils/cookies'
import resetPassword from '@/components/resetPassword/index'
import { JSEncrypt } from 'jsencrypt'
export default {
  name: 'Login',
  components: { commonLogin, resetPassword },
  data () {
    return {
      account: '',
      password: '',
      verCode: '',
      isBtn: true,
      codeImg: '',
      uuid: '',
      checked: false,
      resetVisible: false,
      publicKey: ''
    }
  },
  created () {
    this.account = cookies.get('username')
    this.password = cookies.get('password')
    if (this.account && this.password) {
      this.checked = true
    }
    this.getVerCode()
  },
  methods: {
    // 加密公钥
    setEncrypt (msg) {
      const jsencrypt = new JSEncrypt()
      jsencrypt.setPublicKey(this.publicKey)
      return jsencrypt.encrypt(msg)
    },
    // 解密
    decrypt (msg) {
      const decrypt = new JSEncrypt()
      decrypt.setPrivateKey(this.publicKey)
      return decrypt.decrypt(msg)
    },
    // // 初始化获取验证码
    // async getVerCode () {
    //   loginApi.generateCode().then(({ data }) => {
    //     this.codeImg = data.data.base64Code || ''
    //     this.uuid = data.data.uuid || ''
    //   })
    // },
    // // 点击验证码更新验证码
    // verCodeBtn () {
    //   this.getVerCode()
    // },
    async getKey () {
      await loginApi.getKey().then(({ data }) => {
        this.publicKey = data.data
      })
    },
    // 登录
    async login () {
      await this.getKey()
      const param = {
        loginPortType: '1',
        account: this.account,
        password: this.setEncrypt(this.password),
        uuid: '',
        code: ''
      }
      await loginApi.login(param).then(({ data }) => {
        if (this.checked) {
          cookies.set('username', this.account)
          cookies.set('password', this.password)
        } else {
          cookies.set('username', '')
          cookies.set('password', '')
        }
        User.setObject({
          token: data.data.token,
          ids: JSON.stringify(data.data.permissionIds),
          name: data.data.name,
          phone: data.data.phone,
          userId: data.data.id,
          deptId: data.data.deptId
        })
        this.$router.replace({ path: '/' })
      }).catch(() => {
        // this.getVerCode()
      })
    },
    onSubmit () {
      this.resetVisible = false
      this.$router.replace({ path: '/' })
    },
    onCancel () {
      // this.getVerCode()
      // this.verCode = ''
      this.resetVisible = false
    },
    // 忘记密码
    forget () {
      this.$router.push({
        name: 'register'
      })
    }
  }
}
</script>

<style lang="scss" scoped></style>
