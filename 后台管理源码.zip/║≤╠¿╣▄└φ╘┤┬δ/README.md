### talent-web-admin

### 人才协会信息录入系统

##### 需求原型

- [地址](https://www.zptq.com/s/2457/15790/f3151c92493811ed86d00017fa002dc2/start.html#id=cjbhxm&p=%E4%BA%BA%E6%89%8D%E5%AE%A1%E6%A0%B8&g=1)

##### 蓝湖 ui

- [url]()

##### swagger

- [url]()
