module.exports = {
  sourceType: 'unambiguous',
  presets: [
    '@vue/app'
  ]
}
