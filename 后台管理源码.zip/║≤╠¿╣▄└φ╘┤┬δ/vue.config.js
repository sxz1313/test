const MiniCssExtractPlugin = require('mini-css-extract-plugin')
const Timestamp = new Date().getTime()
const path = require('path')
function resolve (dir) {
  return path.join(__dirname, dir)
}
module.exports = {
  publicPath: './',
  assetsDir: './static',
  transpileDependencies: ['@antv/g6'],
  chainWebpack: config => {
    config.resolve.alias
      .set('@', resolve('src'))
      .set('assets', resolve('src/assets'))
      .set('components', resolve('src/components'))
  },
  configureWebpack: {
    plugins: [
      new MiniCssExtractPlugin({
        filename: `static/css/[name].${Timestamp}.css`,
        chunkFilename: `static/css/[name].${Timestamp}.css`
      })
    ],
    output: { // 输出重构  打包编译后的 文件名称  【模块名称.时间戳】
      filename: `static/js/[name].${Timestamp}.js`,
      chunkFilename: `static/js/[name].${Timestamp}.js`
    },
    externals: {
      'vue': 'Vue',
      'element-ui': 'ELEMENT'
    },
    optimization: {
      splitChunks: {
        cacheGroups: {
          commons: {
            test: /[\\/]node_modules[\\/]/,
            name: 'vendor',
            chunks: 'all'
          }
        }
      },
      runtimeChunk: {
        name: 'manifest'
      }
    },
    devtool: false
  }
}
